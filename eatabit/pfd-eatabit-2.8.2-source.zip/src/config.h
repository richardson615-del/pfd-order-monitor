// Settings, kept in flash (NVS). Defaults are the Eatabit 112-P01 Rev A
// board as traced on 2026-11-01, so a freshly flashed unit only needs WiFi
// and a device key.
#pragma once
#include <Arduino.h>
#include <Preferences.h>

#define FW_VERSION "pfd-eatabit 2.8.2"
static const char* DEFAULT_URL = "https://pfd-order-monitor.vercel.app/api/print/epson";

struct Config {
  // --- network / identity ---
  String ssid, pass, key, url, adminPw;
  int pollSec = 5;
  bool insecure = false;   // skip TLS verification (debug only)
  bool announce = false;   // print a PRINTER ONLINE slip at the next good poll

  // --- printer (EP-300 on UART2) ---
  int dots = 576, baud = 19200, tx = 22, rx = -1;
  bool cutter = false;     // the Eatabit head has a tear bar
  bool tallText = true;    // every line at least double height
  bool compact = true;     // no blank lines, thin rules, tight spacing

  // --- screen (1.8" ST7735, SPI). RESET runs through R4/Q5 from rstDrive:
  // the screen only wakes while that pin is LOW. -1 = not yet found.
  int tftSck = 17, tftSda = 16, tftCs = 0, tftDc = 2;
  bool rstHigh = false;  // false: screen runs with the driver LOW (Rev A as traced); true: runs with it HIGH
  int rstDrive = 15;  // Rev A: GPIO 15 (traced 2026-11-01); the wizard can still find another

  // --- LED ring (three colour channels through Q1-Q3) and the PRINT button lamp ---
  int ledR = 25, ledG = 26, ledB = 12;
  int ledPrint = -1;   // not found yet (15 turned out to be the screen reset)
  bool ledActiveLow = false;
  String ledStyle = "pulse";   // how a new order flashes: pulse | blink | rainbow
  String ledMode = "flash";    // flash: off until a new order | solid: always on | off
  uint32_t ledColor = 0x00FF00;
  int ledBright = 80;
  int flashSec = 10;

  // --- front buttons (pressed = LOW, pulled up on the board) ---
  int btnUp = -1, btnDown = -1, btnMenu = -1, btnPrint = -1;
  int btnPressedLevel = 0;  // 0: pressed reads LOW, 1: pressed reads HIGH, 2: touch pads
  // Resistor-ladder keypad: all four buttons on one analog pin, each pulling
  // it to its own voltage. btnAdc = pin, btnMv[] = learned reading per button.
  int btnAdc = -1;
  // Board B front panel: a TCA9534 I2C input chip (addr 0x20) on SDA/SCL,
  // buttons active-low on kpBit[] (UP, DOWN, MENU, PRINT). -1 = not used.
  int kpSda = -1, kpScl = -1;
  // Board B ring: addressable LEDs on one data pin (-1 = board A RGB lines).
  int pixPin = -1, pixCount = 30;
  int kpBit[4] = {3, 2, 1, 7};
  int btnMv[4] = {-1, -1, -1, -1};

  // --- kitchen ---
  int prepDefault = 15;  // minutes offered first on the prep-time screen
};

inline Config cfg;
inline Preferences prefs;

inline void saveConfig();
inline void loadConfig() {
  prefs.begin("pfd", true);
  cfg.ssid = prefs.getString("ssid", "");
  cfg.pass = prefs.getString("pass", "");
  cfg.key = prefs.getString("key", "");
  cfg.url = prefs.getString("url", DEFAULT_URL);
  cfg.adminPw = prefs.getString("admin", "");
  cfg.pollSec = prefs.getInt("poll", 5);
  cfg.insecure = prefs.getBool("insecure", false);
  cfg.announce = prefs.getBool("announce", false);

  cfg.dots = prefs.getInt("dots", 576);
  cfg.baud = prefs.getInt("baud", 19200);
  cfg.tx = prefs.getInt("tx", 22);
  cfg.rx = prefs.getInt("rx", -1);
  cfg.cutter = prefs.getBool("cutter", false);
  cfg.tallText = prefs.getBool("tall", true);
  cfg.compact = prefs.getBool("compact", true);

  cfg.tftSck = prefs.getInt("tsck", 17);
  cfg.tftSda = prefs.getInt("tsda", 16);
  cfg.tftCs = prefs.getInt("tcs", 0);
  cfg.tftDc = prefs.getInt("tdc", 2);
  cfg.rstDrive = prefs.getInt("rstDrive", 15);
  cfg.rstHigh = prefs.getBool("rstHigh", false);

  cfg.ledR = prefs.getInt("ledR", 25);
  cfg.ledG = prefs.getInt("ledG", 26);
  cfg.ledB = prefs.getInt("ledB", 12);
  cfg.ledPrint = prefs.getInt("ledPrint", -1);
  if (cfg.ledPrint == cfg.rstDrive) cfg.ledPrint = -1;
  cfg.ledActiveLow = prefs.getBool("ledLow", false);
  cfg.ledMode = prefs.getString("ledMode2", "flash");
  cfg.ledStyle = prefs.getString("ledStyle", "pulse");
  cfg.ledColor = prefs.getUInt("ledColor", 0x00FF00);
  cfg.ledBright = prefs.getInt("ledBright", 80);
  cfg.flashSec = prefs.getInt("flashSec", 10);

  cfg.btnUp = prefs.getInt("btnUp", -1);
  cfg.btnDown = prefs.getInt("btnDown", -1);
  cfg.btnMenu = prefs.getInt("btnMenu", -1);
  cfg.btnPrint = prefs.getInt("btnPrint", -1);
  cfg.btnPressedLevel = prefs.getInt("btnLevel", 0);
  cfg.btnAdc = prefs.getInt("btnAdc", -1);
  cfg.kpSda = prefs.getInt("kpSda", -1);
  cfg.pixPin = prefs.getInt("pixPin", -1);
  cfg.kpScl = prefs.getInt("kpScl", -1);
  for (int i = 0; i < 4; i++) cfg.kpBit[i] = prefs.getInt((String("kpb") + i).c_str(), cfg.kpBit[i]);
  for (int i = 0; i < 4; i++) cfg.btnMv[i] = prefs.getInt((String("bmv") + i).c_str(), -1);
  cfg.prepDefault = prefs.getInt("prep", 15);
  // Eatabit Rev A front panel: four plain buttons to ground on GPIO 14/33/27/32
  // (up/down/menu/print). Older firmware guessed a resistor ladder or touch
  // pads; replace those guesses once with the known wiring.
  if (!prefs.getBool("btnRevA", false)) {
    cfg.btnUp = 14; cfg.btnDown = 33; cfg.btnMenu = 27; cfg.btnPrint = 32;
    cfg.btnPressedLevel = 0;
    cfg.btnAdc = -1;
    for (int i = 0; i < 4; i++) cfg.btnMv[i] = -1;
    prefs.end();
    saveConfig();
    prefs.begin("pfd", false);
    prefs.putBool("btnRevA", true);
  }
  prefs.end();
}

inline void saveConfig() {
  prefs.begin("pfd", false);
  prefs.putString("ssid", cfg.ssid);
  prefs.putString("pass", cfg.pass);
  prefs.putString("key", cfg.key);
  prefs.putString("url", cfg.url);
  prefs.putString("admin", cfg.adminPw);
  prefs.putInt("poll", cfg.pollSec);
  prefs.putBool("insecure", cfg.insecure);
  prefs.putBool("announce", cfg.announce);

  prefs.putInt("dots", cfg.dots);
  prefs.putInt("baud", cfg.baud);
  prefs.putInt("tx", cfg.tx);
  prefs.putInt("rx", cfg.rx);
  prefs.putBool("cutter", cfg.cutter);
  prefs.putBool("tall", cfg.tallText);
  prefs.putBool("compact", cfg.compact);

  prefs.putInt("tsck", cfg.tftSck);
  prefs.putInt("tsda", cfg.tftSda);
  prefs.putInt("tcs", cfg.tftCs);
  prefs.putInt("tdc", cfg.tftDc);
  prefs.putInt("rstDrive", cfg.rstDrive);
  prefs.putBool("rstHigh", cfg.rstHigh);

  prefs.putInt("ledR", cfg.ledR);
  prefs.putInt("ledG", cfg.ledG);
  prefs.putInt("ledB", cfg.ledB);
  prefs.putInt("ledPrint", cfg.ledPrint);
  prefs.putBool("ledLow", cfg.ledActiveLow);
  prefs.putString("ledMode2", cfg.ledMode);
  prefs.putString("ledStyle", cfg.ledStyle);
  prefs.putUInt("ledColor", cfg.ledColor);
  prefs.putInt("ledBright", cfg.ledBright);
  prefs.putInt("flashSec", cfg.flashSec);

  prefs.putInt("btnUp", cfg.btnUp);
  prefs.putInt("btnDown", cfg.btnDown);
  prefs.putInt("btnMenu", cfg.btnMenu);
  prefs.putInt("btnPrint", cfg.btnPrint);
  prefs.putInt("btnLevel", cfg.btnPressedLevel);
  prefs.putInt("btnAdc", cfg.btnAdc);
  prefs.putInt("kpSda", cfg.kpSda);
  prefs.putInt("pixPin", cfg.pixPin);
  prefs.putInt("kpScl", cfg.kpScl);
  for (int i = 0; i < 4; i++) prefs.putInt((String("kpb") + i).c_str(), cfg.kpBit[i]);
  for (int i = 0; i < 4; i++) prefs.putInt((String("bmv") + i).c_str(), cfg.btnMv[i]);
  prefs.putInt("prep", cfg.prepDefault);
  prefs.end();
}

// Every GPIO this firmware may drive or read, apart from the printer UART.
static const int ALL_GPIO[] = {0, 2, 4, 5, 12, 13, 14, 15, 16, 17, 18, 19, 21, 22, 23, 25, 26, 27, 32, 33};
// Input-only pins (no internal pull-up; the board pulls the buttons up itself).
static const int INPUT_ONLY[] = {34, 35, 36, 39};

inline bool isReserved(int p) {
  return p == cfg.tx || p == cfg.rx || p == cfg.tftSck || p == cfg.tftSda || p == cfg.tftCs || p == cfg.tftDc ||
         p == cfg.ledR || p == cfg.ledG || p == cfg.ledB || p == cfg.ledPrint || p == cfg.rstDrive ||
         p == cfg.btnUp || p == cfg.btnDown || p == cfg.btnMenu || p == cfg.btnPrint || p == cfg.btnAdc || p == cfg.kpSda || p == cfg.kpScl || p == cfg.pixPin || p == 1 || p == 3;
}

// Spare pins idle LOW: the screen's reset driver is among them (until found)
// and must stay LOW, and LOW keeps every unknown lamp off.
inline void parkSparePins() {
  for (int p : ALL_GPIO) {
    if (isReserved(p)) continue;
    pinMode(p, OUTPUT);
    digitalWrite(p, LOW);
  }
  if (cfg.rstDrive >= 0) { pinMode(cfg.rstDrive, OUTPUT); digitalWrite(cfg.rstDrive, cfg.rstHigh ? HIGH : LOW); }
}
