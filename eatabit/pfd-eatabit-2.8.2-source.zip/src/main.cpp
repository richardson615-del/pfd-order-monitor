#include <Preferences.h>
#include <Wire.h>
// PFD firmware for Eatabit cloud printers (ESP32-WROOM-32D + EP-300 head).
//
// The box behaves like one of PFD's Epson Server Direct Print printers: it
// polls the order-monitor with its device key, translates the ePOS-Print XML
// it receives into ESC/POS, prints, and reports the result. On top of that
// it drives the Eatabit's own front panel: the colour screen, the four
// buttons, the LED ring and the PRINT button lamp.
//
//   tickets print on their own as orders arrive
//   screen   ONLINE / PROBLEM, orders today, last order; new order = green screen
//   buttons  UP/DOWN scroll today's orders, PRINT reprints, MENU sets a prep time
//   ring     flashes on a new order, solid red on a problem, otherwise off
//
// First boot: opens WiFi "PFD-Printer-XXXX" (last 4 of the MAC); join it and a setup page opens.
// Later: http://pfd-printer-xxxx.local or the address on the screen.
#include <Arduino.h>
#include <WiFi.h>
#include <ESPmDNS.h>
#include <esp_system.h>
#include <esp_mac.h>

// The cloud poll holds the ePOS translator (~3 KB of buffers) while a TLS
// request streams into it; the default 8 KB loop stack overflowed the moment
// a real ticket arrived (2.5.0, reset reason 4). 16 KB leaves room.
SET_LOOP_TASK_STACK_SIZE(16 * 1024);
#include "config.h"
#include "printer.h"
#include "orders.h"
#include "leds.h"
#include "tft.h"
#include "ui.h"
#include "net.h"
#include "web.h"

// ---------------------------------------------------------- self tests
void printTest() {
  if (!printerReady) return;
  const uint8_t init[] = {0x1B, 0x40, 0x1B, 0x61, 0x01, 0x1D, 0x21, 0x11};
  printBytes(init, sizeof init);
  printRaw("PFD PRINTER\n");
  const uint8_t norm[] = {0x1D, 0x21, 0x00, 0x1B, 0x61, 0x00};
  printBytes(norm, sizeof norm);
  String host = apName; host.toLowerCase();
  String s;
  s += "Firmware: " FW_VERSION "\n";
  s += "Device key: " + keyHint() + "\n";
  s += "WiFi: " + (WiFi.isConnected() ? cfg.ssid + " (" + String(WiFi.RSSI()) + " dBm)" : String("not connected")) + "\n";
  s += "Settings: http://" + (WiFi.isConnected() ? WiFi.localIP().toString() : WiFi.softAPIP().toString()) + "/\n";
  s += "      or: http://" + host + ".local/\n";
  s += "Printer: pin " + String(cfg.tx) + " @ " + String(cfg.baud) + ", " + (cfg.dots == 576 ? "80mm" : "58mm") + "\n";
  s += "Buttons: " + String(buttonsReady() ? "set up" : "NOT SET UP") + "   Screen: " + String(screenReady ? "ok" : "off") + "\n";
  s += "Last poll: " + lastPollResult + "\n";
  printRaw(s.c_str());
  String x = "<epos-print><text align=\"center\"/><symbol type=\"qrcode_model_2\" level=\"level_m\" width=\"5\">http://";
  x += WiFi.isConnected() ? WiFi.localIP().toString() : WiFi.softAPIP().toString();
  x += "/</symbol><feed line=\"1\"/><text align=\"center\">Scan for printer settings&#10;</text><feed line=\"2\"/><cut type=\"feed\"/></epos-print>";
  printEposXml(x.c_str(), x.length());
}

void printSample() {
  if (!printerReady) return;
  ChunkSink buf;
  EposTranslator tr(buf, eposOptions());
  const size_t n = strlen_P(SAMPLE_TICKET);
  char chunk[256];
  for (size_t i = 0; i < n; i += sizeof chunk) {
    size_t k = min(sizeof chunk, n - i);
    memcpy_P(chunk, SAMPLE_TICKET + i, k);
    tr.feed(chunk, k);
  }
  tr.finish();
  SerialSink out;
  buf.writeTo(out);
  PrinterSerial.flush();
  ordersAdd(buf);
  uiNewOrder();
  logf("printed sample ticket");
}

// Prints "PIN x BAUD y" on every spare GPIO at every common baud; only the
// pin wired to the head produces paper, and only the right baud is readable.
void pinFinder() {
  logf("pin finder starting");
  Serial.flush();
  Serial.end();
  if (printerReady) { PrinterSerial.end(); printerReady = false; }
  HardwareSerial probe(1);
  int cand[24]; int n = 0;
  for (int p : ALL_GPIO) if (p != cfg.tftSck && p != cfg.tftSda && p != cfg.tftCs && p != cfg.tftDc && p != cfg.rstDrive) cand[n++] = p;
  for (int pass = 0; pass < 2; pass++)
    for (int i = 0; i < n; i++) for (int b : BAUDS) {
      probe.begin(b, SERIAL_8N1, -1, cand[i]);
      if (pass == 0) { char line[40]; snprintf(line, sizeof line, "\x1b@PIN %d BAUD %d\n", cand[i], b); probe.print(line); }
      else probe.print("\n\n\n");
      probe.flush();
      delay(pass == 0 ? 30 : 5);
      probe.end();
      pinMode(cand[i], OUTPUT); digitalWrite(cand[i], LOW);
    }
  if (cfg.tx != 1 && cfg.rx != 3) Serial.begin(115200);
  printerBegin();
  parkSparePins();
  buttonsBegin();
  logf("pin finder done");
}

// ------------------------------------------------------------------ main
// Two Eatabit board revisions exist. Board B (black, "112-P01" with a TCA9534
// keypad chip by the buzzer) wires the screen and buttons differently from
// board A (red, Rev A). Probe once on first boot and save the right map.
static void detectBoard() {
  Preferences pr; pr.begin("pfd", false);
  bool done = pr.getBool("boardDet", false);
  if (!done) {
    Wire.begin(14, 27, 100000); Wire.setTimeOut(5);
    Wire.beginTransmission(0x20); Wire.write(0x00);
    bool b = Wire.endTransmission(false) == 0 && Wire.requestFrom(0x20, 1) == 1;
    if (b) Wire.read();
    Wire.end();
    pr.putBool("boardDet", true);
    pr.end();
    if (b) {
      cfg.kpSda = 14; cfg.kpScl = 27;
      cfg.btnUp = cfg.btnDown = cfg.btnMenu = cfg.btnPrint = -1; cfg.btnAdc = -1;
      cfg.tftSck = 15; cfg.tftSda = 23; cfg.tftCs = 4; cfg.tftDc = 2;
      cfg.rstDrive = 0; cfg.rstHigh = true;
      cfg.pixPin = 12; cfg.ledR = cfg.ledG = cfg.ledB = -1;
      saveConfig();
      logf("board B detected (keypad chip at 0x20): screen and buttons mapped");
    } else {
      logf("board A (no keypad chip): Rev A map");
    }
    return;
  }
  pr.end();
}

void setup() {
  loadConfig();
  detectBoard();
  if (cfg.tx != 1 && cfg.rx != 3) Serial.begin(115200);
  delay(50);
  uint8_t mac[6];
  esp_read_mac(mac, ESP_MAC_WIFI_STA);
  char nm[32];
  snprintf(nm, sizeof nm, "PFD-Printer-%02X%02X", mac[4], mac[5]);
  apName = nm;
  char did[32];
  snprintf(did, sizeof did, "pfd-eatabit-%02x%02x%02x%02x%02x%02x", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  deviceId = did;
  logf("%s booting, reset reason %d%s", FW_VERSION, (int)esp_reset_reason(), esp_reset_reason() == ESP_RST_PANIC ? " (CRASHED)" : "");

  parkSparePins();
  printerBegin();
  ledsBegin();
  buttonsBegin();
  if (cfg.btnAdc >= 0)
    logf("keypad GPIO %d: rest %d, up %d down %d menu %d print %d mV", cfg.btnAdc, ladderIdle, cfg.btnMv[0], cfg.btnMv[1], cfg.btnMv[2], cfg.btnMv[3]);
  delay(50);
  screenBegin();
  bigMessage("PFD", "starting up", C_NAVY);
  ordersBegin();

  WiFi.persistent(false);
  WiFi.setAutoReconnect(true);
  WiFi.setHostname(apName.c_str());
  if (cfg.ssid.isEmpty()) {
    startAP();
  } else {
    WiFi.mode(WIFI_STA);
    WiFi.begin(cfg.ssid.c_str(), cfg.pass.c_str());
  }
  netBegin();
  webBegin();

  // A brand new board: find the printer pin and, once the screen is up, the
  // buttons, so the first thing a person does is press what it asks for.
  prefs.begin("pfd", false);
  if (!prefs.getBool("finderRan", false) && cfg.tx < 0) { prefs.putBool("finderRan", true); pendingFinder = true; }
  prefs.end();
  if (screenReady && !buttonsReady()) pendingButtons = true;
}

void loop() {
  if (apOn) dns.processNextRequest();
  web.handleClient();

  if (pendingReboot) { delay(500); ESP.restart(); }
  if (pendingFinder) { pendingFinder = false; pinFinder(); }
  if (pendingTest) { pendingTest = false; printTest(); }
  if (pendingSample) { pendingSample = false; printSample(); }
  if (pendingReprint >= 0) { int i = pendingReprint; pendingReprint = -1; if (ordersReprint(i)) uiNote("REPRINTING", "#" + orders[i].number, C_NAVY); }
  if (pendingResetFind) { pendingResetFind = false; findResetPin(); }
  if (pendingButtons) {
    pendingButtons = false;
    if (cfg.rstDrive < 0) findResetPin();
    if (cfg.rstDrive >= 0) findButtons();
    else { bigMessage("BUTTONS LATER", "reset pin still unknown", C_RED); delay(2000); uiDirty = true; }
  }
  if (pinTestGpio >= 0 && (long)(millis() - pinTestUntil) >= 0) { digitalWrite(pinTestGpio, LOW); pinTestGpio = -1; uiDirty = true; }

  static bool mdnsUp = false;
  if (!mdnsUp && WiFi.isConnected()) {
    String host = apName; host.toLowerCase();
    mdnsUp = MDNS.begin(host.c_str());
    if (mdnsUp) { MDNS.addService("http", "tcp", 80); logf("also at http://%s.local/", host.c_str()); }
  }
  static unsigned long wifiDownSince = 0;
  if (!cfg.ssid.isEmpty()) {
    if (WiFi.isConnected()) { wifiDownSince = 0; if (apOn && millis() > 120000 && (long)(millis() - apKeepUntil) >= 0) stopAP(); }
    else {
      if (!wifiDownSince) wifiDownSince = millis();
      if (millis() - wifiDownSince > 60000) startAP();  // let someone on site fix the WiFi
    }
  }

  netTick();
  uiTick();
  ledsTick();
  delay(5);
}
