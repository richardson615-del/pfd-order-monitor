// ePOS-Print XML -> ESC/POS translator.
//
// The PFD print queue speaks Epson Server Direct Print: it hands a printer a
// <PrintRequestInfo> document containing ePOS-Print XML. Epson printers
// render that natively. The Eatabit's EP-300 module only understands raw
// ESC/POS over TTL serial, so this class reads the XML and writes the
// equivalent ESC/POS bytes. No Arduino dependencies, so it is unit tested on
// a PC against tickets produced by the real server renderer.
//
// Elements handled (everything the queue emits today):
//   <text align em reverse width height ul>content</text>  (also self-closing)
//   <feed line="n"/> <feed unit="n"/> <feed/>
//   <cut type="..."/>
//   <symbol type="qrcode_model_2" level width>data</symbol>
//   <image width height>base64 mono raster</image>   (scaled to paper width)
// Everything else (<Parameter>, <devid>, <timeout>, wrappers) is skipped, and
// its text content is never printed.
#pragma once
#include <stddef.h>
#include <stdint.h>
#include <string.h>

class ByteSink {
 public:
  virtual void put(const uint8_t* data, size_t len) = 0;
  // Called after each raster band so a slow print head can catch up.
  virtual void pause(int ms) { (void)ms; }
  // Called with each text line as laid out by the server (before any
  // narrowing), so a listener can read the order number, name and total.
  virtual void line(const char* text, int len) { (void)text; (void)len; }
  virtual ~ByteSink() {}
};

struct EposOptions {
  int paperDots = 576;     // 576 = 80mm head, 384 = 58mm head
  bool hasCutter = true;   // false: feed instead of cutting
  bool fontBOnNarrow = true;  // 58mm: use Font B so more columns fit
  bool tallText = false;      // print every line at least double height
  bool compact = false;       // drop blank lines, thin rules, tight spacing
};

class EposTranslator {
 public:
  EposTranslator(ByteSink& out, const EposOptions& opt) : out_(out), opt_(opt) {}

  void feed(const char* buf, size_t n) {
    for (size_t i = 0; i < n; i++) step(buf[i]);
  }
  void finish() { flushText(); }

  // What the response must echo back (empty with PrintRequestInfo 1.00).
  const char* printJobId() const { return jobId_; }
  int documents() const { return docs_; }
  int elementsPrinted() const { return printed_; }

 private:
  enum Ctx { NONE, TEXT, SYMBOL, IMAGE, JOBID };

  ByteSink& out_;
  EposOptions opt_;

  bool inTag_ = false;
  char tag_[600];
  size_t tagLen_ = 0;
  bool tagOverflow_ = false;

  Ctx ctx_ = NONE;
  char ent_[12];
  int entLen_ = -1;  // -1: not inside an entity

  // UTF-8 decoding state for text content
  uint32_t cp_ = 0;
  int cpLeft_ = 0;

  char sym_[700];
  size_t symLen_ = 0;
  int symLevel_ = 49;  // 'M'
  int symSize_ = 5;

  char jobId_[64] = {0};
  size_t jobLen_ = 0;

  int docs_ = 0;
  int printed_ = 0;

  // ---- image state ----
  int imgW_ = 0, imgH_ = 0, srcRowBytes_ = 0, outW_ = 0, outH_ = 0, outRowBytes_ = 0;
  uint8_t srcRow_[128];
  int srcCol_ = 0;   // byte index inside current source row
  int srcY_ = 0;
  uint8_t b64q_[4];
  int b64n_ = 0;
  static const int BAND = 8;  // small bands: a hiccup can only smear 8 rows
  uint8_t band_[BAND * 128];
  int bandRows_ = 0;
  int curOutY_ = -1;
  uint8_t outRow_[128];

  void put(const void* p, size_t n) { out_.put((const uint8_t*)p, n); }
  void put1(uint8_t b) { out_.put(&b, 1); }

  // ------------------------------------------------------------------ parse
  void step(char c) {
    if (inTag_) {
      if (c == '>') {
        tag_[tagLen_] = 0;
        inTag_ = false;
        handleTag();
      } else if (tagLen_ < sizeof(tag_) - 1) {
        tag_[tagLen_++] = c;
      } else {
        tagOverflow_ = true;
      }
      return;
    }
    if (c == '<') {
      inTag_ = true;
      tagLen_ = 0;
      tagOverflow_ = false;
      return;
    }
    content(c);
  }

  void content(char c) {
    if (ctx_ == NONE) return;
    if (ctx_ == IMAGE) { b64(c); return; }
    // entity decoding for text-like contexts
    if (entLen_ >= 0) {
      if (c == ';') {
        ent_[entLen_] = 0;
        entLen_ = -1;
        uint32_t v = decodeEntity(ent_);
        if (v) emitCodepoint(v);
        return;
      }
      if (entLen_ < (int)sizeof(ent_) - 1) ent_[entLen_++] = c;
      return;
    }
    if (c == '&') { entLen_ = 0; return; }
    uint8_t b = (uint8_t)c;
    if (b < 0x80) { cpLeft_ = 0; emitCodepoint(b); return; }
    if ((b & 0xC0) == 0x80) {
      if (cpLeft_ > 0) {
        cp_ = (cp_ << 6) | (b & 0x3F);
        if (--cpLeft_ == 0) emitCodepoint(cp_);
      }
      return;
    }
    if ((b & 0xE0) == 0xC0) { cp_ = b & 0x1F; cpLeft_ = 1; }
    else if ((b & 0xF0) == 0xE0) { cp_ = b & 0x0F; cpLeft_ = 2; }
    else { cp_ = b & 0x07; cpLeft_ = 3; }
  }

  static uint32_t decodeEntity(const char* e) {
    if (!strcmp(e, "amp")) return '&';
    if (!strcmp(e, "lt")) return '<';
    if (!strcmp(e, "gt")) return '>';
    if (!strcmp(e, "quot")) return '"';
    if (!strcmp(e, "apos")) return '\'';
    if (e[0] == '#') {
      uint32_t v = 0;
      if (e[1] == 'x' || e[1] == 'X') {
        for (const char* p = e + 2; *p; p++) {
          char ch = *p;
          v = v * 16 + (ch >= 'a' ? ch - 'a' + 10 : ch >= 'A' ? ch - 'A' + 10 : ch - '0');
        }
      } else {
        for (const char* p = e + 1; *p; p++) v = v * 10 + (*p - '0');
      }
      return v;
    }
    return '?';
  }

  // Map a Unicode code point to a byte the printer's default code page
  // (PC437) can print. Kitchen tickets are ASCII in practice; the common
  // typographic characters a menu might contain are folded to ASCII.
  void emitCodepoint(uint32_t cp) {
    char c;
    if (cp == '\r') return;
    if (cp < 0x80) c = (char)cp;
    else switch (cp) {
      case 0x2018: case 0x2019: case 0x00B4: c = '\''; break;
      case 0x201C: case 0x201D: c = '"'; break;
      case 0x2013: case 0x2014: case 0x2212: c = '-'; break;
      case 0x2022: case 0x00B7: c = '*'; break;
      case 0x2026: emitText("..."); return;
      case 0x00A0: c = ' '; break;
      case 0x00BD: emitText("1/2"); return;
      case 0x00B0: c = (char)0xF8; break;  // PC437 degree
      default:
        if (cp >= 0xC0 && cp <= 0xFF) {
          // Latin-1 letters folded to their base letter (CREME BRULEE).
          static const char fold[] =
              "AAAAAAACEEEEIIIIDNOOOOOxOUUUUYTs"
              "aaaaaaaceeeeiiiidnooooo/ouuuuyty";
          c = fold[cp - 0xC0];
        } else {
          c = '?';
        }
    }
    if (ctx_ == TEXT) { textChar(c); }
    else if (ctx_ == SYMBOL) { if (symLen_ < sizeof(sym_) - 1) sym_[symLen_++] = c; }
    else if (ctx_ == JOBID) { if (jobLen_ < sizeof(jobId_) - 1) { jobId_[jobLen_++] = c; jobId_[jobLen_] = 0; } }
  }
  void emitText(const char* s) { while (*s) emitCodepoint((uint8_t)*s++); }
  // ---- line fitting ----
  // The queue lays tickets out for 48 columns (80mm, Font A). On a narrower
  // head a 48-char line wraps and the price lands on a line of its own. So a
  // line is held until its newline and, if too wide, the padding between
  // columns is squeezed until it fits; a rule of dashes is cut to width.
  char line_[256];
  size_t lineLen_ = 0;
  int curWidthMul_ = 1;
  uint8_t curSize_ = 0;

  int cols() const {
    int base = opt_.paperDots >= 500 ? opt_.paperDots / 12 : (opt_.fontBOnNarrow ? opt_.paperDots / 9 : opt_.paperDots / 12);
    return base / (curWidthMul_ < 1 ? 1 : curWidthMul_);
  }

  void textChar(char c) {
    if (c == '\n') { fitAndEmit(true); return; }
    if (lineLen_ < sizeof(line_) - 1) line_[lineLen_++] = c;
    else fitAndEmit(false);
  }

  void flushText() { if (lineLen_) fitAndEmit(false); }

  void fitAndEmit(bool newline) {
    int width = cols();
    int len = (int)lineLen_;
    out_.line(line_, len);
    // a rule: every char the same punctuation
    bool rule = len > 8;
    for (int i = 1; i < len && rule; i++) if (line_[i] != line_[0]) rule = false;
    bool isRule = rule && (line_[0] == '-' || line_[0] == '=' || line_[0] == '_' || line_[0] == '*' || line_[0] == '.');
    if (opt_.compact) {
      bool blank = true;
      for (int i = 0; i < len && blank; i++) if (line_[i] != ' ') blank = false;
      if (blank) { lineLen_ = 0; return; }  // spacing lines waste paper
    }
    if (isRule) {
      if (len > width) len = width;
      if (opt_.compact) {
        // A rule only separates; print it at normal size, then restore.
        uint8_t n[] = {0x1D, 0x21, 0x00}; put(n, 3);
        int base = opt_.paperDots >= 500 ? opt_.paperDots / 12 : (opt_.fontBOnNarrow ? opt_.paperDots / 9 : opt_.paperDots / 12);
        if (len > base) len = base;
        put(line_, len); put1('\n');
        uint8_t r[] = {0x1D, 0x21, curSize_}; put(r, 3);
        lineLen_ = 0;
        return;
      }
    } else {
      // squeeze the widest interior space run, one space at a time
      while (len > width) {
        int lead = 0;
        while (lead < len && line_[lead] == ' ') lead++;
        int bestStart = -1, bestLen = 1;
        for (int i = lead; i < len;) {
          if (line_[i] == ' ') {
            int j = i;
            while (j < len && line_[j] == ' ') j++;
            if (j < len && j - i > bestLen) { bestLen = j - i; bestStart = i; }
            i = j;
          } else i++;
        }
        if (bestStart < 0) {
          // no padding left: drop leading indent beyond 1, then give up (wrap)
          if (lead > 1) { memmove(line_, line_ + 1, len - 1); len--; continue; }
          break;
        }
        memmove(line_ + bestStart, line_ + bestStart + 1, len - bestStart - 1);
        len--;
      }
    }
    if (len) { put(line_, len); printed_++; }
    if (newline) put1('\n');
    lineLen_ = 0;
  }

  // ------------------------------------------------------------- attributes
  // Finds name="value" inside the current tag; returns false if absent.
  bool attr(const char* name, char* val, size_t cap) {
    size_t nl = strlen(name);
    const char* p = tag_;
    while ((p = strstr(p, name)) != nullptr) {
      bool boundary = (p == tag_) || p[-1] == ' ' || p[-1] == '\t' || p[-1] == '\n';
      const char* q = p + nl;
      while (*q == ' ') q++;
      if (boundary && *q == '=') {
        q++;
        while (*q == ' ') q++;
        char quote = *q;
        if (quote != '"' && quote != '\'') return false;
        q++;
        size_t i = 0;
        while (*q && *q != quote && i < cap - 1) val[i++] = *q++;
        val[i] = 0;
        return true;
      }
      p += nl;
    }
    return false;
  }
  int attrInt(const char* name, int dflt) {
    char v[16];
    if (!attr(name, v, sizeof v)) return dflt;
    int n = 0, sign = 1; const char* p = v;
    if (*p == '-') { sign = -1; p++; }
    if (*p < '0' || *p > '9') return dflt;
    while (*p >= '0' && *p <= '9') n = n * 10 + (*p++ - '0');
    return n * sign;
  }
  int attrBool(const char* name) {  // -1 absent, 0 false, 1 true
    char v[8];
    if (!attr(name, v, sizeof v)) return -1;
    return strcmp(v, "true") == 0 ? 1 : 0;
  }

  // Tag name into buf; returns pointer just past it. Sets closing/selfClose.
  void tagName(char* buf, size_t cap, bool& closing, bool& selfClose) {
    const char* p = tag_;
    closing = false;
    if (*p == '/') { closing = true; p++; }
    size_t i = 0;
    while (*p && *p != ' ' && *p != '/' && *p != '\t' && *p != '\n' && i < cap - 1) buf[i++] = *p++;
    buf[i] = 0;
    size_t L = tagLen_;
    while (L > 0 && (tag_[L - 1] == ' ' || tag_[L - 1] == '\n')) L--;
    selfClose = L > 0 && tag_[L - 1] == '/';
    // Strip any namespace prefix (ePOS docs never use one, but be safe).
    char* colon = strchr(buf, ':');
    if (colon) memmove(buf, colon + 1, strlen(colon + 1) + 1);
  }

  // ------------------------------------------------------------------- tags
  void handleTag() {
    if (tag_[0] == '?' || tag_[0] == '!') return;  // <?xml ?> / comments
    char name[32];
    bool closing, selfClose;
    tagName(name, sizeof name, closing, selfClose);

    if (closing) {
      if (!strcmp(name, "text") && ctx_ == TEXT) { flushText(); ctx_ = NONE; }
      else if (!strcmp(name, "symbol") && ctx_ == SYMBOL) { printQr(); ctx_ = NONE; }
      else if (!strcmp(name, "image") && ctx_ == IMAGE) { endImage(); ctx_ = NONE; }
      else if (!strcmp(name, "printjobid") && ctx_ == JOBID) ctx_ = NONE;
      return;
    }

    if (!strcmp(name, "epos-print")) {
      docs_++;
      static const uint8_t init[] = {0x1B, 0x40,        // ESC @ reset
                                     0x1B, 0x74, 0x00,  // ESC t 0: PC437
                                     0x1B, 0x32};       // ESC 2: default line spacing
      put(init, sizeof init);
      if (opt_.paperDots < 500 && opt_.fontBOnNarrow) { uint8_t f[] = {0x1B, 0x4D, 0x01}; put(f, 3); }
      if (opt_.compact) { uint8_t ls[] = {0x1B, 0x33, 0x06}; put(ls, 3); }  // tight line spacing
      return;
    }
    if (!strcmp(name, "text")) { flushText(); textAttrs(); if (!selfClose) ctx_ = TEXT; return; }
    if (!strcmp(name, "feed")) { doFeed(); return; }
    if (!strcmp(name, "cut")) { doCut(); return; }
    if (!strcmp(name, "symbol")) {
      char lv[16] = "level_m";
      attr("level", lv, sizeof lv);
      char L = lv[strlen(lv) - 1];
      symLevel_ = L == 'l' ? 48 : L == 'q' ? 50 : L == 'h' ? 51 : 49;
      symSize_ = attrInt("width", 5);
      symLen_ = 0;
      if (!selfClose) ctx_ = SYMBOL;
      return;
    }
    if (!strcmp(name, "image")) { beginImage(); if (!selfClose) ctx_ = IMAGE; return; }
    if (!strcmp(name, "printjobid")) { jobLen_ = 0; jobId_[0] = 0; if (!selfClose) ctx_ = JOBID; return; }
  }

  void textAttrs() {
    char v[16];
    if (attr("align", v, sizeof v)) {
      uint8_t n = !strcmp(v, "center") ? 1 : !strcmp(v, "right") ? 2 : 0;
      uint8_t c[] = {0x1B, 0x61, n}; put(c, 3);
    }
    int em = attrBool("em");
    if (em >= 0) { uint8_t c[] = {0x1B, 0x45, (uint8_t)em}; put(c, 3); }
    int rv = attrBool("reverse");
    if (rv >= 0) { uint8_t c[] = {0x1D, 0x42, (uint8_t)rv}; put(c, 3); }
    int ul = attrBool("ul");
    if (ul >= 0) { uint8_t c[] = {0x1B, 0x2D, (uint8_t)ul}; put(c, 3); }
    int w = attrInt("width", -1), h = attrInt("height", -1);
    if (w > 0 || h > 0) {
      if (w < 1) w = 1; if (w > 8) w = 8;
      if (h < 1) h = 1; if (h > 8) h = 8;
      if (opt_.tallText && h < 2) h = 2;
      curWidthMul_ = w;
      curSize_ = (uint8_t)(((w - 1) << 4) | (h - 1));
      uint8_t c[] = {0x1D, 0x21, curSize_}; put(c, 3);
    }
  }

  void doFeed() {
    int lines = attrInt("line", -1);
    int unit = attrInt("unit", -1);
    if (opt_.compact && lines > 1) lines = 1;
    if (lines > 0) {
      while (lines > 0) { uint8_t n = lines > 255 ? 255 : lines; uint8_t c[] = {0x1B, 0x64, n}; put(c, 3); lines -= n; }
    } else if (unit > 0) {
      while (unit > 0) { uint8_t n = unit > 255 ? 255 : unit; uint8_t c[] = {0x1B, 0x4A, n}; put(c, 3); unit -= n; }
    } else if (!opt_.compact) {
      put1('\n');
    }
  }

  void doCut() {
    // Reset styles so a stuck reverse/double-size can never leak to the
    // next ticket, then feed past the head and cut.
    static const uint8_t reset[] = {0x1B, 0x45, 0, 0x1D, 0x42, 0, 0x1D, 0x21, 0, 0x1B, 0x61, 0};
    put(reset, sizeof reset);
    if (opt_.hasCutter) {
      static const uint8_t c[] = {0x1D, 0x56, 0x42, 0x00};  // GS V 66 0: feed + partial cut
      put(c, sizeof c);
    } else {
      static const uint8_t c[] = {0x1B, 0x32, 0x1B, 0x64, 0x04};  // default spacing, 4 lines past the tear bar
      put(c, sizeof c);
    }
    printed_++;
  }

  void printQr() {
    if (symLen_ == 0) return;
    int size = symSize_;
    if (opt_.paperDots < 500 && size > 4) size = 4;
    if (size < 1) size = 1; if (size > 16) size = 16;
    uint8_t model[] = {0x1D, 0x28, 0x6B, 4, 0, 0x31, 0x41, 0x32, 0x00};
    uint8_t sz[] = {0x1D, 0x28, 0x6B, 3, 0, 0x31, 0x43, (uint8_t)size};
    uint8_t ec[] = {0x1D, 0x28, 0x6B, 3, 0, 0x31, 0x45, (uint8_t)symLevel_};
    size_t n = symLen_ + 3;
    uint8_t store[] = {0x1D, 0x28, 0x6B, (uint8_t)(n & 0xFF), (uint8_t)(n >> 8), 0x31, 0x50, 0x30};
    uint8_t prt[] = {0x1D, 0x28, 0x6B, 3, 0, 0x31, 0x51, 0x30};
    put(model, sizeof model);
    put(sz, sizeof sz);
    put(ec, sizeof ec);
    put(store, sizeof store);
    put(sym_, symLen_);
    put(prt, sizeof prt);
    printed_++;
  }

  // ------------------------------------------------------------------ image
  void beginImage() {
    imgW_ = attrInt("width", 0);
    imgH_ = attrInt("height", 0);
    srcRowBytes_ = (imgW_ + 7) / 8;
    if (srcRowBytes_ > (int)sizeof(srcRow_)) { imgW_ = 0; }
    outW_ = imgW_ > opt_.paperDots ? opt_.paperDots : imgW_;
    outH_ = imgW_ > 0 ? (int)((long)imgH_ * outW_ / imgW_) : 0;
    outRowBytes_ = (outW_ + 7) / 8;
    srcCol_ = 0; srcY_ = 0; b64n_ = 0; bandRows_ = 0; curOutY_ = -1;
    memset(srcRow_, 0, sizeof srcRow_);
    memset(outRow_, 0, sizeof outRow_);
    // Images are centred by the queue's renderer at full width; centre a
    // narrower one the same way.
    uint8_t c[] = {0x1B, 0x61, 0x01}; put(c, 3);
  }

  static int b64val(char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '+') return 62;
    if (c == '/') return 63;
    return -1;
  }

  void b64(char c) {
    if (imgW_ <= 0) return;
    if (c == '=') { flushB64Partial(); return; }
    int v = b64val(c);
    if (v < 0) return;  // whitespace / newlines
    b64q_[b64n_++] = (uint8_t)v;
    if (b64n_ == 4) {
      imgByte((b64q_[0] << 2) | (b64q_[1] >> 4));
      imgByte(((b64q_[1] & 0x0F) << 4) | (b64q_[2] >> 2));
      imgByte(((b64q_[2] & 0x03) << 6) | b64q_[3]);
      b64n_ = 0;
    }
  }
  void flushB64Partial() {
    if (b64n_ >= 2) imgByte((b64q_[0] << 2) | (b64q_[1] >> 4));
    if (b64n_ >= 3) imgByte(((b64q_[1] & 0x0F) << 4) | (b64q_[2] >> 2));
    b64n_ = 0;
  }

  void imgByte(uint8_t b) {
    if (srcY_ >= imgH_) return;
    srcRow_[srcCol_++] = b;
    if (srcCol_ == srcRowBytes_) {
      srcRowDone();
      srcCol_ = 0;
      srcY_++;
    }
  }

  static bool pixelAt(const uint8_t* row, int x) { return row[x >> 3] & (0x80 >> (x & 7)); }

  // Scale a finished source row into the output raster. Downscaling ORs the
  // source pixels that land on one output pixel, so thin strokes in a logo
  // or the QR survive at 58mm instead of vanishing.
  void srcRowDone() {
    int oy = (int)((long)srcY_ * outH_ / imgH_);
    if (oy != curOutY_) {
      if (curOutY_ >= 0) commitOutRow();
      curOutY_ = oy;
      memset(outRow_, 0, outRowBytes_);
    }
    if (outW_ == imgW_) {
      for (int i = 0; i < outRowBytes_; i++) outRow_[i] |= srcRow_[i];
    } else {
      for (int x = 0; x < imgW_; x++) {
        if (pixelAt(srcRow_, x)) {
          int ox = (int)((long)x * outW_ / imgW_);
          outRow_[ox >> 3] |= (0x80 >> (ox & 7));
        }
      }
    }
    if (srcY_ == imgH_ - 1) { commitOutRow(); curOutY_ = -1; }
  }

  void commitOutRow() {
    memcpy(band_ + bandRows_ * outRowBytes_, outRow_, outRowBytes_);
    if (++bandRows_ == BAND) flushBand();
  }

  void flushBand() {
    if (bandRows_ == 0) return;
    // GS v 0: print raster bit image, one band at a time so the buffer stays small.
    uint8_t h[] = {0x1D, 0x76, 0x30, 0x00,
                   (uint8_t)(outRowBytes_ & 0xFF), (uint8_t)(outRowBytes_ >> 8),
                   (uint8_t)(bandRows_ & 0xFF), (uint8_t)(bandRows_ >> 8)};
    put(h, sizeof h);
    put(band_, (size_t)bandRows_ * outRowBytes_);
    out_.pause(bandRows_ * 6);
    bandRows_ = 0;
  }

  void endImage() {
    if (imgW_ <= 0) return;
    flushB64Partial();
    if (curOutY_ >= 0) { commitOutRow(); curOutY_ = -1; }
    flushBand();
    uint8_t c[] = {0x1B, 0x61, 0x00}; put(c, 3);
    printed_++;
  }
};
