// LED ring and PRINT button lamp.
//
//   new order   ring flashes green (the chosen colour) for flashSec, PRINT lamp on
//   error       ring solid red until it clears (no PFD, no WiFi, paper out)
//   otherwise   off (mode "flash"), always on (mode "solid"), or off entirely
#pragma once
#include <Arduino.h>
#include "config.h"
#include "pixels.h"

inline bool ledsReady = false;
inline bool printLampReady = false;
inline unsigned long flashUntil = 0;
inline unsigned long printLampUntil = 0;
inline bool printLampHold = false;   // on while the orders list is open
inline String errorText;             // "" when all is well
inline unsigned long previewUntil = 0;  // settings menu shows the colour briefly

inline void ledPin(int pin, uint8_t v) {
  if (pin < 0) return;
  uint32_t duty = (uint32_t)v * cfg.ledBright / 100;
  if (cfg.ledActiveLow) duty = 255 - duty;
  ledcWrite(pin, duty);
}

inline void ledsBegin() {
  if (cfg.pixPin >= 0) {
    pinMode(cfg.pixPin, OUTPUT); digitalWrite(cfg.pixPin, LOW);
    ledsReady = true;
    pixelsFill(cfg.pixPin, cfg.pixCount, 0);
    if (cfg.ledPrint >= 0) { pinMode(cfg.ledPrint, OUTPUT); digitalWrite(cfg.ledPrint, LOW); printLampReady = true; }
    return;
  }
  for (int p : {cfg.ledR, cfg.ledG, cfg.ledB})
    if (p >= 0 && p != cfg.tx && p != cfg.rx) ledcAttach(p, 5000, 8);
  ledsReady = cfg.ledR >= 0 || cfg.ledG >= 0 || cfg.ledB >= 0;
  if (cfg.ledPrint >= 0) { pinMode(cfg.ledPrint, OUTPUT); digitalWrite(cfg.ledPrint, LOW); printLampReady = true; }
}

inline void ledShow(uint32_t c) {
  if (!ledsReady) return;
  if (cfg.pixPin >= 0) {
    // Only send when the colour changes; the LEDs hold their state.
    static uint32_t last = 0xFFFFFFFF;
    uint32_t d = ((((c >> 16) & 0xFF) * cfg.ledBright / 100) << 16) | ((((c >> 8) & 0xFF) * cfg.ledBright / 100) << 8) | ((c & 0xFF) * cfg.ledBright / 100);
    if (d != last) { pixelsFill(cfg.pixPin, cfg.pixCount, d); last = d; }
    return;
  }
  ledPin(cfg.ledR, (c >> 16) & 0xFF);
  ledPin(cfg.ledG, (c >> 8) & 0xFF);
  ledPin(cfg.ledB, c & 0xFF);
}

// Scales a colour by 0..255.
inline uint32_t dim(uint32_t c, int k) {
  return ((((c >> 16) & 0xFF) * k / 255) << 16) | ((((c >> 8) & 0xFF) * k / 255) << 8) | ((c & 0xFF) * k / 255);
}

// One frame of the new-order flash. The ring's LEDs all share the same
// red/green/blue lines, so the motion is in time: a smooth swell for pulse,
// a hard on/off for blink, a sweep through every colour for rainbow.
inline uint32_t flashFrame(unsigned long now) {
  if (cfg.ledStyle == "blink") return ((now / 200) % 2) ? cfg.ledColor : 0;
  if (cfg.ledStyle == "rainbow") {
    int h = (now / 4) % 768;  // full colour wheel every ~3 s
    int r = h < 256 ? 255 - h : h < 512 ? 0 : h - 512;
    int g = h < 256 ? h : h < 512 ? 511 - h : 0;
    int b = h < 256 ? 0 : h < 512 ? h - 256 : 767 - h;
    return ((uint32_t)r << 16) | ((uint32_t)g << 8) | (uint32_t)b;
  }
  // pulse: about 1.2 s per swell, never fully dark so it reads as a wave
  float ph = (now % 1200) / 1200.0f * 6.2832f;
  int k = 30 + (int)(225 * (0.5f - 0.5f * cosf(ph)));
  return dim(cfg.ledColor, k);
}

inline void printLamp(bool on) { if (printLampReady) digitalWrite(cfg.ledPrint, on ? HIGH : LOW); }

inline void ledsNewOrder() {
  flashUntil = millis() + (unsigned long)cfg.flashSec * 1000;
  printLampUntil = flashUntil;
}

inline void ledsPreview(unsigned long ms = 2500) { previewUntil = millis() + ms; }

inline void setError(const String& e) { errorText = e; }

inline void ledsTick() {
  unsigned long now = millis();
  bool flashing = (long)(now - flashUntil) < 0;
  printLamp(printLampHold || (long)(now - printLampUntil) < 0);
  if (!ledsReady) return;
  if (flashing) { ledShow(flashFrame(now)); return; }
  if ((long)(now - previewUntil) < 0) { ledShow(cfg.ledColor); return; }
  if (cfg.ledMode == "off") { ledShow(0); return; }
  if (errorText.length()) { ledShow(0xFF0000); return; }
  ledShow(cfg.ledMode == "solid" ? cfg.ledColor : 0);
}

inline uint32_t parseColor(const String& hex) {
  String h = hex;
  if (h.startsWith("#")) h = h.substring(1);
  return (uint32_t)strtoul(h.c_str(), nullptr, 16) & 0xFFFFFF;
}

inline String colorHex(uint32_t c) {
  char b[8];
  snprintf(b, sizeof b, "#%06X", (unsigned)(c & 0xFFFFFF));
  return b;
}
