// Talking to PFD: Server Direct Print polling, result reports, prep times.
#pragma once
#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <HTTPClient.h>
#include "config.h"
#include "certs.h"
#include "printer.h"
#include "orders.h"
#include "leds.h"
#include "ui.h"

inline WiFiClientSecure tls;
inline unsigned long nextPollAt = 0;
inline unsigned long lastPollOkAt = 0;
inline String lastPollResult = "not yet";
inline uint32_t ticketsPrinted = 0;

inline bool pollingHealthy() {
  if (!WiFi.isConnected()) return false;
  if (cfg.key.isEmpty()) return true;
  return lastPollOkAt && millis() - lastPollOkAt < 60000;
}

inline String urlEncode(const String& s) {
  String o;
  o.reserve(s.length() * 3);
  const char* hex = "0123456789ABCDEF";
  for (size_t i = 0; i < s.length(); i++) {
    char c = s[i];
    if (isalnum((unsigned char)c) || c == '-' || c == '_' || c == '.' || c == '~') o += c;
    else { o += '%'; o += hex[(uint8_t)c >> 4]; o += hex[(uint8_t)c & 15]; }
  }
  return o;
}

inline void netBegin() {
  if (cfg.insecure) tls.setInsecure(); else tls.setCACert(ROOT_CAS);
  tls.setHandshakeTimeout(20);
  // Central time, with daylight saving, for the screen and the order list.
  configTzTime("CST6CDT,M3.2.0,M11.1.0", "pool.ntp.org", "time.google.com");
}

// POSTs a form to the print server; streams the reply into `tr` when given.
inline bool postTo(const String& url, const String& body, EposTranslator* tr, int& httpCode, String* reply = nullptr) {
  HTTPClient http;
  http.setReuse(true);
  http.setTimeout(20000);
  http.setUserAgent(FW_VERSION);
  if (!http.begin(tls, url)) { httpCode = -1; return false; }
  http.addHeader("Content-Type", "application/x-www-form-urlencoded");
  httpCode = http.POST(body);
  bool ok = httpCode == 200;
  if (ok && tr) {
    TranslatorStream ts(*tr);
    if (http.writeToStream(&ts) < 0) ok = false;
    tr->finish();
  } else if (ok && reply) {
    *reply = http.getString();
  }
  http.end();
  return ok;
}

inline bool post(const String& body, EposTranslator* tr, int& httpCode, String* reply = nullptr) {
  return postTo(cfg.url, body, tr, httpCode, reply);
}

// ------------------------------------------------------------- pairing
// No device key yet: ask PFD for a six-digit code, show it on the screen,
// and poll until somebody in the office pairs it to a restaurant. Then the
// key arrives here and the printer starts printing. Nobody types a key.
inline String deviceId;                 // "pfd-eatabit-<mac>", stable per board
inline unsigned long pairExpiresAt = 0;  // millis when the shown code lapses
inline unsigned long nextPairAt = 0;

inline String linkUrl() {
  String u = cfg.url;
  if (u.endsWith("/epson")) return u.substring(0, u.length() - 6) + "/link";
  int slash = u.lastIndexOf('/');
  return slash > 8 ? u.substring(0, slash) + "/link" : u;
}

inline String field(const String& reply, const char* name) {
  String key = String(name) + "=";
  int at = reply.startsWith(key) ? 0 : reply.indexOf("\n" + key);
  if (at < 0) return "";
  if (at > 0) at += 1;
  int end = reply.indexOf('\n', at);
  String v = reply.substring(at + key.length(), end < 0 ? reply.length() : end);
  v.trim();
  return v;
}

inline void pairTick() {
  if ((long)(millis() - nextPairAt) < 0) return;
  nextPairAt = millis() + 5000;
  int c; String reply;
  bool haveCode = pairCode.length() == 6 && (long)(millis() - pairExpiresAt) < 0;
  if (!haveCode) {
    if (!postTo(linkUrl(), "Action=Code&Device=" + urlEncode(deviceId), nullptr, c, &reply)) {
      if (lastPollResult != "pair: http " + String(c)) logf("pair code request failed (http %d)", c);
      lastPollResult = "pair: http " + String(c);
      nextPairAt = millis() + 15000;
      return;
    }
    String code = field(reply, "code");
    if (code.length() != 6) { nextPairAt = millis() + 15000; return; }
    if (code != pairCode) { pairCode = code; uiDirty = true; logf("pair code %s", code.c_str()); }
    pairExpiresAt = millis() + 29UL * 60 * 1000;
    lastPollResult = "waiting to be paired";
    return;
  }
  bool ok = postTo(linkUrl(), "Action=Status&Device=" + urlEncode(deviceId) + "&Code=" + pairCode, nullptr, c, &reply);
  if (!ok) {
    if (c == 404) { pairCode = ""; uiDirty = true; }  // gone: ask for a new one
    return;
  }
  String st = field(reply, "status");
  if (st == "expired" || st == "consumed") { pairCode = ""; uiDirty = true; nextPairAt = millis(); return; }
  if (st != "linked") return;
  String key = field(reply, "key");
  if (key.length() < 8) return;
  String where = field(reply, "restaurant");
  cfg.key = key;
  cfg.announce = true;
  saveConfig();
  pairCode = "";
  logf("paired to %s", where.length() ? where.c_str() : "a restaurant");
  uiNote("PAIRED", where.length() ? where : String("Orders print here now"), C_GREEN, 4000);
  nextPollAt = millis() + 1000;
}

inline void sendResult(bool success, const char* code, const char* jobId) {
  String xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><PrintResponseInfo Version=\"1.00\"><ePOSPrint><Parameter><devid>local_printer</devid><printjobid>";
  xml += jobId;
  xml += "</printjobid></Parameter><PrintResponse><response success=\"";
  xml += success ? "true" : "false";
  xml += "\" code=\"";
  xml += code;
  xml += "\" status=\"0\" battery=\"0\"/></PrintResponse></ePOSPrint></PrintResponseInfo>";
  String body = "ConnectionType=SetResponse&ID=" + urlEncode(cfg.key) + "&ResponseFile=" + urlEncode(xml);
  int c;
  for (int attempt = 0; attempt < 3; attempt++) {
    if (post(body, nullptr, c)) return;
    delay(1000);
  }
  logf("result report failed (http %d) - server will re-offer the job", c);
}

// Tells PFD the kitchen's prep time for an order. The server treats it like
// the tablet's Accept-with-minutes, so dispatch and the driver see the clock.
inline bool sendPrepTime(const String& orderNumber, int minutes) {
  if (cfg.key.isEmpty() || !WiFi.isConnected()) return false;
  String body = "ConnectionType=SetReadyTime&ID=" + urlEncode(cfg.key) + "&OrderNumber=" + urlEncode(orderNumber) + "&Minutes=" + String(minutes);
  int c;
  String reply;
  bool ok = post(body, nullptr, c, &reply);
  logf("prep time #%s = %d min: %s", orderNumber.c_str(), minutes, ok ? (reply.length() ? reply.c_str() : "sent") : "failed");
  return ok;
}

inline void printAnnounce() {
  if (!printerReady) return;
  const uint8_t init[] = {0x1B, 0x40, 0x1B, 0x61, 0x01, 0x1B, 0x45, 0x01, 0x1D, 0x21, 0x11};
  printBytes(init, sizeof init);
  printRaw("PFD PRINTER ONLINE\n");
  const uint8_t n[] = {0x1D, 0x21, 0x00, 0x1B, 0x45, 0x00};
  printBytes(n, sizeof n);
  String s = "Connected to PFD. Orders print here.\nKey " + keyHint() + "\n";
  printRaw(s.c_str());
  printFeedAndCut();
}

inline void poll() {
  if (cfg.key.isEmpty()) return;
  ChunkSink buf;
  EposTranslator tr(buf, eposOptions());
  int httpCode;
  String body = "ConnectionType=GetRequest&ID=" + urlEncode(cfg.key);
  if (!post(body, &tr, httpCode)) {
    lastPollResult = "error http " + String(httpCode);
    logf("poll failed: http %d (%s)", httpCode, HTTPClient::errorToString(httpCode).c_str());
    if (millis() - lastPollOkAt > 60000) setError(WiFi.isConnected() ? "Cannot reach PFD" : "No WiFi");
    return;
  }
  lastPollOkAt = millis();
  if (errorText == "Cannot reach PFD" || errorText == "No WiFi") setError("");
  if (cfg.announce) { cfg.announce = false; saveConfig(); printAnnounce(); }
  if (tr.documents() == 0) { lastPollResult = "ok, nothing queued"; return; }

  if (buf.overflow) {
    logf("ticket too large for memory (%u bytes) - reporting failure", (unsigned)buf.total);
    sendResult(false, "EPTR_UNRECOVERABLE", tr.printJobId());
    lastPollResult = "ticket too large";
    return;
  }
  const char* status = printerStatusCode();
  if (*status) {
    logf("printer reports %s - job held", status);
    sendResult(false, status, tr.printJobId());
    lastPollResult = String("held: ") + status;
    setError("Out of paper");
    return;
  }
  if (errorText == "Out of paper") setError("");
  SerialSink out;
  buf.writeTo(out);
  PrinterSerial.flush();
  ticketsPrinted++;
  ordersAdd(buf);
  uiNewOrder();
  logf("printed #%s (%u bytes, stack free %u)", buf.summary.number.c_str(), (unsigned)buf.total, (unsigned)uxTaskGetStackHighWaterMark(nullptr));
  sendResult(true, "", tr.printJobId());
  lastPollResult = "printed #" + buf.summary.number;
  nextPollAt = millis() + 500;  // drain a queue quickly
}

inline void netTick() {
  static unsigned long wifiLostAt = 1;
  static bool mdnsUp = false;
  if (cfg.ssid.isEmpty()) return;
  if (WiFi.isConnected()) {
    if (wifiLostAt) {
      logf("WiFi connected, %s", WiFi.localIP().toString().c_str());
      wifiLostAt = 0;
      if (errorText == "No WiFi") setError("");
      uiDirty = true;
    }
    if (cfg.key.isEmpty()) pairTick();
    else if ((long)(millis() - nextPollAt) >= 0) {
      nextPollAt = millis() + (unsigned long)cfg.pollSec * 1000;
      poll();
    }
  } else {
    if (!wifiLostAt) { wifiLostAt = millis(); logf("WiFi lost"); }
    if (millis() - wifiLostAt > 30000) setError("No WiFi");
  }
  (void)mdnsUp;
}
