// Today's orders, kept on the board so the screen can list them and the
// PRINT button can reprint one without asking the server. Each order is a
// file in flash: one header line, then the ESC/POS bytes exactly as printed.
#pragma once
#include <Arduino.h>
#include <LittleFS.h>
#include <time.h>
#include "config.h"
#include "printer.h"

struct OrderEntry {
  uint32_t seq = 0;      // file name and order of arrival
  time_t at = 0;         // when it printed (epoch; 0 if the clock was not set)
  String number, name, total, type;
};

static const int MAX_ORDERS = 60;
inline OrderEntry orders[MAX_ORDERS];
inline int orderCount = 0;      // newest last
inline uint32_t orderSeq = 0;
inline bool fsReady = false;

inline String orderPath(uint32_t seq) { return "/o/" + String(seq) + ".bin"; }

inline bool sameLocalDay(time_t a, time_t b) {
  struct tm ta, tb;
  localtime_r(&a, &ta);
  localtime_r(&b, &tb);
  return ta.tm_year == tb.tm_year && ta.tm_yday == tb.tm_yday;
}

inline String clockText(time_t t) {
  if (t < 1600000000) return "";
  struct tm tm;
  localtime_r(&t, &tm);
  char b[12];
  int h = tm.tm_hour % 12; if (h == 0) h = 12;
  snprintf(b, sizeof b, "%d:%02d%s", h, tm.tm_min, tm.tm_hour < 12 ? "a" : "p");
  return b;
}

inline time_t nowEpoch() { time_t t = time(nullptr); return t < 1600000000 ? 0 : t; }

inline void ordersDrop(int idx) {
  if (idx < 0 || idx >= orderCount) return;
  LittleFS.remove(orderPath(orders[idx].seq));
  for (int i = idx; i < orderCount - 1; i++) orders[i] = orders[i + 1];
  orderCount--;
}

// Forget anything not from today, so the list is today's orders only.
inline void ordersRollover() {
  time_t now = nowEpoch();
  if (!now) return;
  for (int i = 0; i < orderCount;) {
    if (orders[i].at && !sameLocalDay(orders[i].at, now)) ordersDrop(i); else i++;
  }
}

inline void ordersBegin() {
  fsReady = LittleFS.begin(true);
  if (!fsReady) { logf("order store: flash filesystem failed"); return; }
  LittleFS.mkdir("/o");
  File dir = LittleFS.open("/o");
  File f;
  while (dir && (f = dir.openNextFile())) {
    String nm = f.name();
    uint32_t seq = (uint32_t)atol(nm.c_str());
    String head = f.readStringUntil('\n');
    f.close();
    // head: at|number|name|total|type
    OrderEntry e;
    e.seq = seq;
    int a = head.indexOf('|'), b = head.indexOf('|', a + 1), c = head.indexOf('|', b + 1), d = head.indexOf('|', c + 1);
    if (a < 0 || b < 0 || c < 0 || d < 0) { LittleFS.remove("/o/" + nm); continue; }
    e.at = (time_t)atol(head.substring(0, a).c_str());
    e.number = head.substring(a + 1, b);
    e.name = head.substring(b + 1, c);
    e.total = head.substring(c + 1, d);
    e.type = head.substring(d + 1);
    if (seq > orderSeq) orderSeq = seq;
    // insert sorted by seq
    int pos = orderCount;
    while (pos > 0 && orders[pos - 1].seq > seq) pos--;
    if (orderCount == MAX_ORDERS) continue;
    for (int i = orderCount; i > pos; i--) orders[i] = orders[i - 1];
    orders[pos] = e;
    orderCount++;
  }
  logf("order store: %d orders on file", orderCount);
}

// Saves a just-printed ticket. Returns its index in `orders`.
inline int ordersAdd(ChunkSink& ticket) {
  ordersRollover();
  if (!fsReady) return -1;
  while (orderCount >= MAX_ORDERS) ordersDrop(0);
  OrderEntry e;
  e.seq = ++orderSeq;
  e.at = nowEpoch();
  e.number = ticket.summary.number.length() ? ticket.summary.number : String("?");
  e.name = ticket.summary.name;
  e.total = ticket.summary.total;
  e.type = ticket.summary.type;
  String sanitized;
  for (char c : e.name) sanitized += (c == '|' || c == '\n') ? ' ' : c;
  e.name = sanitized;
  File f = LittleFS.open(orderPath(e.seq), "w");
  if (!f) { logf("order store: could not save #%s", e.number.c_str()); return -1; }
  f.printf("%ld|%s|%s|%s|%s\n", (long)e.at, e.number.c_str(), e.name.c_str(), e.total.c_str(), e.type.c_str());
  ticket.forEachBlock([&](const uint8_t* b, size_t n) { f.write(b, n); });
  f.close();
  orders[orderCount++] = e;
  return orderCount - 1;
}

// Prints a stored ticket again, with a REPRINT line above it.
inline bool ordersReprint(int idx) {
  if (idx < 0 || idx >= orderCount || !printerReady) return false;
  File f = LittleFS.open(orderPath(orders[idx].seq), "r");
  if (!f) return false;
  f.readStringUntil('\n');
  static const uint8_t head[] = {0x1B, 0x40, 0x1B, 0x61, 0x01, 0x1D, 0x42, 0x01, 0x1D, 0x21, 0x11};
  printBytes(head, sizeof head);
  printRaw("  REPRINT  \n");
  static const uint8_t norm[] = {0x1D, 0x42, 0x00, 0x1D, 0x21, 0x00};
  printBytes(norm, sizeof norm);
  uint8_t buf[512];
  while (f.available()) {
    size_t n = f.read(buf, sizeof buf);
    PrinterSerial.write(buf, n);
    // The live print paced raster bands with pauses that are not in the
    // stored bytes, so pace here too: harmless for text, needed for logos.
    PrinterSerial.flush();
    delay(40);
  }
  f.close();
  PrinterSerial.flush();
  logf("reprinted #%s", orders[idx].number.c_str());
  return true;
}

inline int ordersToday() {
  ordersRollover();
  return orderCount;
}
