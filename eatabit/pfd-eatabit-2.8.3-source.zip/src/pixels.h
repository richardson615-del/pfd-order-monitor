// Addressable RGB LEDs (WS2812-style, GRB) on board B, driven with RMT.
#pragma once
#include <Arduino.h>

inline int pixPinInit = -1;

// Sets all n LEDs on `pin` to one colour (0xRRGGBB, already dimmed).
inline void pixelsFill(int pin, int n, uint32_t rgb) {
  if (pin < 0 || n <= 0) return;
  if (pixPinInit != pin) {
    if (!rmtInit(pin, RMT_TX_MODE, RMT_MEM_NUM_BLOCKS_1, 10000000)) return;
    pixPinInit = pin;
  }
  static rmt_data_t buf[24 * 64];
  if (n > 64) n = 64;
  uint8_t g = (rgb >> 8) & 0xFF, r = (rgb >> 16) & 0xFF, b = rgb & 0xFF;
  uint8_t bytes[3] = {g, r, b};
  int k = 0;
  for (int led = 0; led < n; led++)
    for (int c = 0; c < 3; c++)
      for (int bit = 7; bit >= 0; bit--) {
        bool one = bytes[c] & (1 << bit);
        buf[k].level0 = 1; buf[k].duration0 = one ? 8 : 4;
        buf[k].level1 = 0; buf[k].duration1 = one ? 4 : 8;
        k++;
      }
  rmtWrite(pin, buf, k, 100);
}

inline void pixelsRelease() {
  if (pixPinInit >= 0) { rmtDeinit(pixPinInit); pixPinInit = -1; }
}
