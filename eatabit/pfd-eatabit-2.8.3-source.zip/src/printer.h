// The EP-300 print head on UART2, the sinks that feed it, and the ticket
// summary the firmware reads off each job for the screen's order list.
#pragma once
#include <Arduino.h>
#include "config.h"
#include "epos.h"

// ------------------------------------------------------------------- log
static String logLines[30];
static int logHead = 0;
inline void logf(const char* fmt, ...) {
  char buf[160];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(buf, sizeof buf, fmt, ap);
  va_end(ap);
  char line[180];
  snprintf(line, sizeof line, "[%lus] %s", millis() / 1000, buf);
  logLines[logHead] = line;
  logHead = (logHead + 1) % 30;
  if (cfg.tx != 1 && cfg.rx != 3) Serial.println(line);
}

// --------------------------------------------------------------- printer
inline HardwareSerial PrinterSerial(2);
inline bool printerReady = false;

inline void printerBegin() {
  if (printerReady) { PrinterSerial.end(); printerReady = false; }
  if (cfg.tx < 0) return;
  PrinterSerial.setTxBufferSize(1024);
  PrinterSerial.begin(cfg.baud, SERIAL_8N1, cfg.rx, cfg.tx);
  printerReady = true;
}

inline EposOptions eposOptions() {
  EposOptions o;
  o.paperDots = cfg.dots;
  o.hasCutter = cfg.cutter;
  o.tallText = cfg.tallText;
  o.compact = cfg.compact;
  return o;
}

class SerialSink : public ByteSink {
 public:
  void put(const uint8_t* d, size_t n) override { if (printerReady) PrinterSerial.write(d, n); }
  // The EP-300 has a small buffer and slows on dark graphics; without a
  // pause it drops bytes mid-image and prints the rest of the band as junk.
  void pause(int ms) override { if (printerReady) { PrinterSerial.flush(); delay(ms); } }
};

// Paper-out check, only possible when the head's TX is wired to rx.
inline const char* printerStatusCode() {
  if (!printerReady || cfg.rx < 0) return "";
  while (PrinterSerial.available()) PrinterSerial.read();
  const uint8_t q[] = {0x10, 0x04, 0x04};  // DLE EOT 4: paper sensor
  PrinterSerial.write(q, 3);
  PrinterSerial.flush();
  unsigned long t = millis();
  while (!PrinterSerial.available() && millis() - t < 300) delay(5);
  if (!PrinterSerial.available()) return "";
  uint8_t s = PrinterSerial.read();
  if ((s & 0x93) != 0x12) return "";
  if (s & 0x60) return "EPTR_REC_EMPTY";
  return "";
}

// What the screen shows for an order: read off the ticket's own lines.
struct TicketSummary {
  String number, name, total, type;
  void feed(const char* t, int n) {
    String s(t, n);
    s.trim();
    if (!s.length()) return;
    if (s.startsWith("ORDER #")) {
      int sp = s.indexOf(' ', 7);
      number = sp > 0 ? s.substring(7, sp) : s.substring(7);
      stage = 1;
      return;
    }
    if (s.startsWith("TOTAL")) { int d = s.lastIndexOf('$'); if (d >= 0) total = s.substring(d); return; }
    if (type.isEmpty()) {
      String packed; for (char c : s) if (c != ' ') packed += c;
      if (packed == "DELIVERY" || packed == "PICKUP") { type = packed; return; }
    }
    bool rule = true;
    for (char c : s) if (c != '-' && c != '=') { rule = false; break; }
    if (rule) { if (stage == 1) stage = 2; return; }
    if (stage == 2) { name = s; stage = 3; }
  }
 private:
  int stage = 0;
};

// Holds a fully translated ticket in small blocks (no large contiguous
// allocation), so nothing reaches paper unless the whole job arrived.
class ChunkSink : public ByteSink {
 public:
  static const size_t BLOCK = 4096;
  static const int MAXBLOCKS = 40;  // 160 KB ceiling
  uint8_t* blocks[MAXBLOCKS];
  int n = 0;
  size_t used = 0;
  bool overflow = false;
  size_t total = 0;
  TicketSummary summary;
  ~ChunkSink() { clear(); }
  void clear() {
    for (int i = 0; i < n; i++) free(blocks[i]);
    n = 0; used = 0; total = 0; overflow = false;
  }
  void put(const uint8_t* d, size_t len) override {
    while (len && !overflow) {
      if (n == 0 || used == BLOCK) {
        if (n == MAXBLOCKS) { overflow = true; return; }
        uint8_t* b = (uint8_t*)malloc(BLOCK);
        if (!b) { overflow = true; return; }
        blocks[n++] = b;
        used = 0;
      }
      size_t take = min(len, BLOCK - used);
      memcpy(blocks[n - 1] + used, d, take);
      used += take; d += take; len -= take; total += take;
    }
  }
  void line(const char* t, int len) override { summary.feed(t, len); }
  void writeTo(ByteSink& out) {
    for (int i = 0; i < n; i++) out.put(blocks[i], i == n - 1 ? used : BLOCK);
  }
  template <typename F> void forEachBlock(F f) {
    for (int i = 0; i < n; i++) f(blocks[i], i == n - 1 ? used : BLOCK);
  }
};

// Adapts the HTTP body stream into the translator.
class TranslatorStream : public Stream {
 public:
  EposTranslator& t;
  explicit TranslatorStream(EposTranslator& tr) : t(tr) {}
  size_t write(uint8_t c) override { t.feed((const char*)&c, 1); return 1; }
  size_t write(const uint8_t* b, size_t n) override { t.feed((const char*)b, n); return n; }
  int available() override { return 0; }
  int read() override { return -1; }
  int peek() override { return -1; }
  void flush() override {}
};

inline void printRaw(const char* s) { if (printerReady) PrinterSerial.print(s); }
inline void printBytes(const uint8_t* b, size_t n) { if (printerReady) PrinterSerial.write(b, n); }

inline void printFeedAndCut() {
  if (!printerReady) return;
  static const uint8_t reset[] = {0x1B, 0x45, 0, 0x1D, 0x42, 0, 0x1D, 0x21, 0, 0x1B, 0x61, 0, 0x1B, 0x32};
  printBytes(reset, sizeof reset);
  if (cfg.cutter) { static const uint8_t c[] = {0x1D, 0x56, 0x42, 0x00}; printBytes(c, 4); }
  else { static const uint8_t f[] = {0x1B, 0x64, 0x04}; printBytes(f, 3); }
  PrinterSerial.flush();
}

// Runs ePOS XML straight to paper through the same translator real tickets use.
inline void printEposXml(const char* xml, size_t len, TicketSummary* summary = nullptr) {
  if (!printerReady) return;
  SerialSink out;
  EposTranslator tr(out, eposOptions());
  tr.feed(xml, len);
  tr.finish();
  PrinterSerial.flush();
  (void)summary;
}
