// Front-panel screen: 1.8" ST7735 TFT, 128x160, SPI, used in landscape.
// Its RESET line is not on a GPIO: it runs through R4/Q5 and is released
// while the driving pin (cfg.rstDrive, found once per board) is LOW.
#pragma once
#include <Arduino.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7735.h>
#include <SPI.h>
#include "config.h"

inline Adafruit_ST7735* tft = nullptr;
inline bool screenReady = false;

static const int SW = 160, SH = 128;
static const uint16_t C_BLACK = 0x0000, C_WHITE = 0xFFFF, C_GREEN = 0x07E0, C_RED = 0xF800,
                      C_AMBER = 0xFD20, C_BLUE = 0x001F, C_GREY = 0x8410, C_DIM = 0x4208, C_NAVY = 0x0010;

inline void screenBegin() {
  if (cfg.tftSck < 0) return;
  // Hardware SPI routed to the screen's pins: a full redraw takes ~15 ms
  // instead of the visible wipe the bit-banged driver gave.
  static SPIClass tftSpi(HSPI);
  if (tft) delete tft;
  tftSpi.end();
  tftSpi.begin(cfg.tftSck, -1, cfg.tftSda, -1);
  tft = new Adafruit_ST7735(&tftSpi, cfg.tftCs, cfg.tftDc, -1);
  // Proper hardware reset through R4/Q5: driver HIGH holds the panel in
  // reset, LOW releases it, and the ST7735 wants ~120 ms before commands.
  // Relying on power-up timing left some units with a white screen.
  if (cfg.rstDrive >= 0) {
    pinMode(cfg.rstDrive, OUTPUT);
    digitalWrite(cfg.rstDrive, cfg.rstHigh ? LOW : HIGH);   // assert reset
    delay(20);
    digitalWrite(cfg.rstDrive, cfg.rstHigh ? HIGH : LOW);   // release
    delay(150);
  }
  tft->initR(INITR_BLACKTAB);
  tft->setSPISpeed(26000000);
  tft->setRotation(1);
  tft->fillScreen(C_BLACK);
  screenReady = true;
}

inline void textAt(int x, int y, const String& s, uint16_t color, int size = 1) {
  tft->setTextSize(size);
  tft->setTextColor(color);
  tft->setCursor(x, y);
  tft->print(s);
}

inline void centerText(int y, const String& s, uint16_t color, int size = 1) {
  tft->setTextSize(size);
  int w = s.length() * 6 * size;
  textAt(max(0, (SW - w) / 2), y, s, color, size);
}

// Keeps a line inside the width at a given text size.
inline String fitText(const String& s, int size, int width = SW) {
  int maxChars = width / (6 * size);
  if ((int)s.length() <= maxChars) return s;
  return s.substring(0, maxChars);
}

inline void bigMessage(const String& big, const String& small, uint16_t bg, uint16_t fg = C_WHITE) {
  if (!screenReady) return;
  tft->fillScreen(bg);
  centerText(44, fitText(big, 2), fg, 2);
  centerText(80, fitText(small, 1), fg, 1);
}
