#include <Wire.h>
// Front panel: the four buttons and what the screen shows.
//
//   HOME     status band, orders today, last order; UP/DOWN opens the list, MENU shows info
//   LIST     today's orders; UP/DOWN scroll, PRINT reprints, MENU sets a prep time
//   PREP     minutes for the chosen order; UP/DOWN +/- 5, PRINT sends it, MENU backs out
//   NEWORDER green screen for flashSec after a ticket prints; any button clears it
//   INFO     firmware, WiFi, key, printer pin
#pragma once
#include <Arduino.h>
#include <WiFi.h>
#include "config.h"
#include "tft.h"
#include "orders.h"
#include "leds.h"
#include "printer.h"
#include "logo.h"

// Setup hotspot (started in web.h): its name and whether it is open.
inline bool apOn = false;
inline String apName;
inline unsigned long apKeepUntil = 0;  // opened from the screen: stay open this long
inline void startAP();
inline String pairCode;  // six digits from PFD while unpaired (net.h)

// --------------------------------------------------------------- buttons
enum Btn { B_NONE = -1, B_UP = 0, B_DOWN = 1, B_MENU = 2, B_PRINT = 3 };
static const char* BTN_NAMES[] = {"UP arrow", "DOWN arrow", "MENU (three lines)", "PRINT"};

inline int btnPin(int b) { return b == B_UP ? cfg.btnUp : b == B_DOWN ? cfg.btnDown : b == B_MENU ? cfg.btnMenu : cfg.btnPrint; }
inline bool ladderReady() { return cfg.btnAdc >= 0 && cfg.btnMv[0] >= 0 && cfg.btnMv[1] >= 0 && cfg.btnMv[2] >= 0 && cfg.btnMv[3] >= 0; }
inline bool keypadReady() { return cfg.kpSda >= 0 && cfg.kpScl >= 0; }
// Board B: read the TCA9534 input register; -1 on bus error.
inline int keypadReadAt(int addr) {
  Wire.beginTransmission(addr); Wire.write(0x00);
  if (Wire.endTransmission(false) != 0) return -1;
  if (Wire.requestFrom(addr, 1) != 1) return -1;
  return Wire.read();
}
inline int keypadRead() { return keypadReadAt(cfg.kpAddr); }
// Probe the keypad expander on SDA 14 / SCL 27 at every address a TCA9534 /
// PCA9534 (0x20-0x27) or TCA9534A (0x38-0x3F) can sit on. Returns the
// address, or -1. Leaves Wire running on 14/27 when found.
inline int keypadProbe() {
  Wire.end(); Wire.begin(14, 27, 100000); Wire.setTimeOut(5);
  for (int a = 0x20; a <= 0x3F; a++) {
    if (a == 0x28) a = 0x38;
    if (keypadReadAt(a) >= 0) return a;
  }
  Wire.end();
  return -1;
}
inline bool buttonsReady() { return keypadReady() || ladderReady() || (cfg.btnUp >= 0 && cfg.btnDown >= 0 && cfg.btnMenu >= 0 && cfg.btnPrint >= 0); }

// Resting voltage of the ladder line, measured at boot (no button held).
inline int ladderIdle = 3300;

// Which ladder level a reading is nearest: -1 = idle, 0..3 = a button.
// A reading only counts as a button when it sits clearly closer to that
// button than to the idle level or any other button.
inline int ladderButton(int mv) {
  int levels[5] = {ladderIdle, cfg.btnMv[0], cfg.btnMv[1], cfg.btnMv[2], cfg.btnMv[3]};
  int best = 0, bestD = 1 << 30, second = 1 << 30;
  for (int i = 0; i < 5; i++) {
    int d = abs(mv - levels[i]);
    if (d < bestD) { second = bestD; bestD = d; best = i; }
    else if (d < second) second = d;
  }
  if (best == 0) return -1;
  // must be well inside its own band and well away from idle
  if (bestD > 150 || second - bestD < 80 || abs(mv - ladderIdle) < 200) return -2;  // ambiguous
  return best - 1;
}

inline int ladderRead() {
  int s = 0;
  for (int i = 0; i < 8; i++) s += analogReadMilliVolts(cfg.btnAdc);
  return s / 8;
}

// Capacitive touch front panel: each button is an ESP32 touch pad. The
// reading drops when a finger is on it; touchBase[] is the resting value.
static const int TOUCH_PINS[] = {4, 13, 14, 27, 32, 33};
inline int touchBase[4] = {0, 0, 0, 0};
inline bool touchMode() { return cfg.btnPressedLevel == 2; }
inline int touchAvg(int p, int n = 4) { long s = 0; for (int i = 0; i < n; i++) s += touchRead(p); return s / n; }

inline bool isInputOnly(int p) { for (int q : INPUT_ONLY) if (q == p) return true; return false; }

inline void buttonsBegin() {
  if (keypadReady()) { Wire.end(); Wire.begin(cfg.kpSda, cfg.kpScl, 100000); Wire.setTimeOut(5); return; }
  if (cfg.btnAdc >= 0) {
    pinMode(cfg.btnAdc, INPUT);
    analogSetPinAttenuation(cfg.btnAdc, ADC_11db);
    long s = 0; for (int i = 0; i < 32; i++) { s += analogReadMilliVolts(cfg.btnAdc); delay(2); }
    int idle = s / 32;
    // only trust the boot reading if it is not sitting on a button level
    bool onButton = false;
    for (int b = 0; b < 4; b++) if (cfg.btnMv[b] >= 0 && abs(idle - cfg.btnMv[b]) < 200) onButton = true;
    if (!onButton) ladderIdle = idle;
  }
  for (int b = 0; b < 4; b++) {
    int p = btnPin(b);
    if (p < 0) continue;
    if (touchMode()) { touchBase[b] = touchAvg(p, 16); continue; }
    if (isInputOnly(p)) pinMode(p, INPUT);
    else pinMode(p, cfg.btnPressedLevel ? INPUT_PULLDOWN : INPUT_PULLUP);
  }
}

// Debounced reading. A press only counts after the same button reads
// steadily for 60 ms, and the next press only after the line has been
// back at rest for 120 ms. UP/DOWN repeat while held; PRINT never repeats.
inline Btn readButton() {
  static int stableBtn = -1, candidate = -1;
  static unsigned long candSince = 0, repeatAt = 0, idleSince = 0;
  static bool armed = true;
  unsigned long now = millis();

  int raw;
  if (keypadReady()) {
    static unsigned long nextRead = 0; static int lastRaw = -1;
    if ((long)(millis() - nextRead) >= 0) {
      nextRead = millis() + 10;
      int v = keypadRead();
      lastRaw = -1;
      if (v >= 0) { v ^= cfg.kpInv; for (int b = 0; b < 4; b++) if (cfg.kpBit[b] >= 0 && !(v & (1 << cfg.kpBit[b]))) { lastRaw = b; break; } }
    }
    raw = lastRaw;
  } else if (ladderReady()) {
    raw = ladderButton(ladderRead());
    if (raw == -2) return B_NONE;  // in between levels: ignore, keep state
  } else {
    raw = -1;
    for (int b = 0; b < 4; b++) {
      int p = btnPin(b);
      if (p < 0) continue;
      bool on = touchMode() ? (touchBase[b] > 0 && touchAvg(p) < touchBase[b] * 7 / 10)
                            : digitalRead(p) == (cfg.btnPressedLevel ? HIGH : LOW);
      if (on) { raw = b; break; }
    }
  }

  if (raw != candidate) { candidate = raw; candSince = now; }
  if (now - candSince < 60) return B_NONE;  // not steady yet

  if (candidate == -1) {
    if (stableBtn != -1) { stableBtn = -1; idleSince = now; }
    if (!armed && now - idleSince >= 120) armed = true;
    return B_NONE;
  }
  if (candidate != stableBtn) {
    stableBtn = candidate;
    if (!armed) return B_NONE;
    armed = false;
    repeatAt = now + 600;
    logf("button %s", BTN_NAMES[candidate]);
    return (Btn)candidate;
  }
  if ((candidate == B_UP || candidate == B_DOWN) && (long)(now - repeatAt) >= 0) {
    repeatAt = now + 200;
    return (Btn)candidate;
  }
  return B_NONE;
}

// -------------------------------------------------------------- UI state
enum Screen { S_HOME, S_LIST, S_PREP, S_NEWORDER, S_INFO, S_NOTE, S_IDLE, S_SET };
inline Screen uiScreen = S_HOME;
inline int uiSel = 0;            // selected order (index into orders)
inline int uiPrep = 15;
inline unsigned long uiLastInput = 0;
inline unsigned long uiExpireAt = 0;   // when a timed screen ends
inline unsigned long uiRedrawAt = 0;
inline int uiMinute = -1;        // last minute drawn, so the clock updates on the minute
inline int setSel = 0;           // settings menu row
static const unsigned long IDLE_AFTER = 60000;  // logo screen after a minute of quiet
inline bool uiDirty = true;
inline String noteBig, noteSmall;
inline uint16_t noteColor = C_BLACK;

// Set by net.h
bool pollingHealthy();
bool sendPrepTime(const String& orderNumber, int minutes);
inline String keyHint() {
  if (cfg.key.length() < 4) return cfg.key.isEmpty() ? "NOT SET" : "set";
  return "..." + cfg.key.substring(cfg.key.length() - 4);
}

inline void uiShow(Screen s, unsigned long forMs = 0) {
  uiScreen = s;
  uiExpireAt = forMs ? millis() + forMs : 0;
  uiDirty = true;
}

inline void uiNote(const String& big, const String& small, uint16_t color, unsigned long ms = 2000) {
  noteBig = big; noteSmall = small; noteColor = color;
  uiShow(S_NOTE, ms);
}

inline void drawBand(const String& title, uint16_t color, uint16_t text) {
  tft->fillRect(0, 0, SW, 26, color);
  centerText(6, title, text, 2);
}

inline void drawHome() {
  tft->fillScreen(C_BLACK);
  bool setUp = !cfg.key.isEmpty();
  bool wifi = WiFi.isConnected();
  if (apOn) {
    drawBand("WIFI SETUP", C_AMBER, C_BLACK);
    centerText(34, "On a phone, join WiFi", C_WHITE);
    centerText(50, apName, C_GREEN, apName.length() * 12 <= SW ? 2 : 1);
    centerText(72, "The setup page opens.", C_WHITE);
    centerText(84, "Pick the store WiFi,", C_GREY);
    centerText(96, "type its password, Save.", C_GREY);
    centerText(114, "or go to 192.168.4.1", C_DIM);
    return;
  }
  if (!wifi && !cfg.ssid.isEmpty()) {
    drawBand("NO WIFI", C_RED, C_WHITE);
    centerText(40, "Trying to join", C_WHITE);
    centerText(56, fitText(cfg.ssid, 1), C_GREEN);
    centerText(80, "Setup WiFi opens in", C_GREY);
    centerText(92, "about a minute.", C_GREY);
    return;
  }
  if (!setUp) {
    drawBand("PAIR PRINTER", C_AMBER, C_BLACK);
    if (pairCode.length() == 6) {
      centerText(34, "Pair code", C_GREY);
      centerText(48, pairCode.substring(0, 3) + " " + pairCode.substring(3), C_WHITE, 3);
      centerText(80, "Enter it in the CRM:", C_WHITE);
      centerText(92, "Equipment, Add printer", C_WHITE);
    } else {
      centerText(52, "Getting a pair code...", C_WHITE);
    }
    centerText(114, WiFi.localIP().toString(), C_DIM);
    return;
  }
  bool ok = pollingHealthy() && errorText.isEmpty();
  uint16_t bandBg = ok ? C_GREEN : C_RED, bandFg = ok ? C_BLACK : C_WHITE;
  tft->fillRect(0, 0, SW, 26, bandBg);
  textAt(4, 6, ok ? "ONLINE" : "PROBLEM", bandFg, 2);
  String now = clockText(nowEpoch());
  if (now.length()) textAt(SW - 4 - now.length() * 12, 6, now, bandFg, 2);
  if (!ok) {
    centerText(36, fitText(errorText.length() ? errorText : String(wifi ? "Cannot reach PFD" : "No WiFi"), 1), C_RED);
  }
  int n = ordersToday();
  textAt(8, 40 + (ok ? 0 : 10), "Orders today", C_GREY);
  textAt(104, 34 + (ok ? 0 : 10), String(n), C_WHITE, 3);
  String last = orderCount ? clockText(orders[orderCount - 1].at) : String("");
  textAt(8, 66, "Last order", C_GREY);
  textAt(8, 78, last.length() ? last + "  " + fitText(orders[orderCount - 1].name, 1, 90) : String("none yet"), C_WHITE);
  tft->drawFastHLine(0, 104, SW, C_DIM);
  if (buttonsReady()) {
    textAt(4, 112, "^v orders", C_GREY);
    textAt(92, 112, "= settings", C_GREY);
  } else {
    centerText(112, "Buttons not set up yet", C_DIM);
  }
}

inline void drawList() {
  tft->fillScreen(C_BLACK);
  int n = orderCount;
  tft->fillRect(0, 0, SW, 16, C_NAVY);
  textAt(4, 4, n ? "Today's orders  " + String(n - uiSel) + "/" + String(n) : String("Today's orders"), C_WHITE);
  if (!n) {
    centerText(52, "No orders yet today", C_GREY);
  } else {
    // newest first; 6 rows of 14px from y=20
    const int ROWS = 6;
    int top = uiSel - (uiSel % ROWS);  // page containing the selection
    for (int r = 0; r < ROWS; r++) {
      int i = top + r;             // i counts from newest (0) to oldest
      if (i >= n) break;
      const OrderEntry& o = orders[n - 1 - i];
      int y = 19 + r * 12;
      bool sel = i == uiSel;
      if (sel) tft->fillRect(0, y - 2, SW, 14, C_GREEN);
      uint16_t fg = sel ? C_BLACK : C_WHITE;
      String t = clockText(o.at);
      String line = (t.length() ? t : String("--:--")) + " #" + o.number;
      textAt(2, y, fitText(line, 1, 92), fg);
      textAt(96, y, fitText(o.total, 1, 62), fg);
      // second detail (name) only for the selected row, on the footer line
    }
    const OrderEntry& s = orders[n - 1 - uiSel];
    tft->fillRect(0, 104, SW, 24, C_DIM);
    textAt(4, 106, fitText(s.type.length() ? s.type + " " + s.name : s.name, 1), C_WHITE);
    textAt(4, 118, "PRINT=reprint  =:prep time", C_GREY);
  }
}

inline void drawPrep() {
  tft->fillScreen(C_BLACK);
  const OrderEntry& o = orders[orderCount - 1 - uiSel];
  drawBand("PREP TIME", C_AMBER, C_BLACK);
  centerText(32, fitText("#" + o.number + "  " + o.name, 1), C_WHITE);
  centerText(50, String(uiPrep) + " min", C_GREEN, 3);
  centerText(84, "^ v  change", C_GREY);
  centerText(98, "PRINT = send   = back", C_GREY);
  centerText(114, "Ready at " + clockText(nowEpoch() + uiPrep * 60), C_AMBER);
}

inline void drawNewOrder() {
  tft->fillScreen(C_GREEN);
  centerText(14, "NEW", C_BLACK, 3);
  centerText(40, "ORDER", C_BLACK, 3);
  if (orderCount) {
    const OrderEntry& o = orders[orderCount - 1];
    centerText(74, fitText("#" + o.number + " " + o.total, 2), C_BLACK, 2);
    centerText(96, fitText(o.type.length() ? o.type + "  " + o.name : o.name, 1), C_BLACK);
  }
  centerText(114, "Prep time: =  Reprint: PRINT", C_BLACK);
}

inline void drawInfo() {
  tft->fillScreen(C_BLACK);
  drawBand("PFD PRINTER", C_BLUE, C_WHITE);
  int y = 32;
  textAt(4, y, FW_VERSION, C_WHITE); y += 12;
  textAt(4, y, "WiFi " + fitText(cfg.ssid, 1, 120), C_GREY); y += 12;
  textAt(4, y, WiFi.isConnected() ? WiFi.localIP().toString() + "  " + String(WiFi.RSSI()) + "dBm" : String("not connected"), C_GREY); y += 12;
  textAt(4, y, "Key " + keyHint(), C_GREY); y += 12;
  textAt(4, y, "Printer pin " + String(cfg.tx) + " @ " + String(cfg.baud), C_GREY); y += 12;
  textAt(4, y, "Tickets " + String(orderCount) + " today", C_GREY); y += 12;
  textAt(4, 116, "= back", C_DIM);
}


inline void drawIdle() {
  tft->fillScreen(C_WHITE);
  int x = (SW - LOGO_W) / 2;
  tft->drawRGBBitmap(x, 2, LOGO_565, LOGO_W, LOGO_H);
  String now = clockText(nowEpoch());
  if (now.length()) {
    String t = now.substring(0, now.length() - 1) + (now.endsWith("a") ? " AM" : " PM");
    centerText(SH - 22 + 4, t, 0x8200, 2);  // brown, matches the logo
  }
}

// --------------------------------------------------------------- settings
static const char* LED_MODES[] = {"flash", "solid", "off"};
static const char* LED_MODE_NAMES[] = {"Flash on order", "Always on", "Off"};
static const uint32_t LED_COLORS[] = {0x00FF00, 0x0000FF, 0xFFFFFF, 0xFF8000, 0xFF00FF, 0x00FFFF, 0xFFFF00};
static const char* LED_COLOR_NAMES[] = {"Green", "Blue", "White", "Orange", "Purple", "Teal", "Yellow"};
static const int N_COLORS = 7;
static const int BRIGHT_STEPS[] = {20, 40, 60, 80, 100};
static const int FLASH_STEPS[] = {5, 10, 15, 20, 30, 60};
static const char* LED_STYLES[] = {"pulse", "blink", "rainbow"};
static const char* LED_STYLE_NAMES[] = {"Pulse", "Blink", "Rainbow"};
enum { SET_MODE, SET_STYLE, SET_COLOR, SET_BRIGHT, SET_FLASH, SET_WIFI, SET_INFO, SET_ROWS };

inline String colorName(uint32_t c) {
  for (int i = 0; i < N_COLORS; i++) if (LED_COLORS[i] == c) return LED_COLOR_NAMES[i];
  return colorHex(c);
}
inline String modeName() {
  for (int i = 0; i < 3; i++) if (cfg.ledMode == LED_MODES[i]) return LED_MODE_NAMES[i];
  return cfg.ledMode;
}

inline void drawSettings() {
  tft->fillScreen(C_BLACK);
  tft->fillRect(0, 0, SW, 16, C_NAVY);
  textAt(4, 4, "Settings", C_WHITE);
  String style = cfg.ledStyle;
  for (int i = 0; i < 3; i++) if (cfg.ledStyle == LED_STYLES[i]) style = LED_STYLE_NAMES[i];
  String labels[SET_ROWS] = {"Lights", "Flash style", "Color", "Brightness", "Flash time", "Change WiFi", "Printer info"};
  String values[SET_ROWS] = {modeName(), style, colorName(cfg.ledColor), String(cfg.ledBright) + "%", String(cfg.flashSec) + " sec", ">", ">"};
  for (int r = 0; r < SET_ROWS; r++) {
    int y = 19 + r * 12;
    bool sel = r == setSel;
    if (sel) tft->fillRect(0, y - 2, SW, 12, C_GREEN);
    uint16_t fg = sel ? C_BLACK : C_WHITE;
    textAt(4, y, labels[r], fg);
    String v = fitText(values[r], 1, 84);
    textAt(SW - 4 - v.length() * 6, y, v, sel ? C_BLACK : C_AMBER);
    if (r == SET_COLOR) tft->fillRect(SW - 4 - v.length() * 6 - 12, y, 8, 8, tft->color565((cfg.ledColor >> 16) & 0xFF, (cfg.ledColor >> 8) & 0xFF, cfg.ledColor & 0xFF));
  }
  tft->fillRect(0, 104, SW, 24, C_DIM);
  textAt(4, 106, "^v pick   PRINT change", C_WHITE);
  textAt(4, 118, "= done (saves)", C_GREY);
}

inline void settingsChange() {
  switch (setSel) {
    case SET_MODE: {
      int i = 0; for (int k = 0; k < 3; k++) if (cfg.ledMode == LED_MODES[k]) i = k;
      cfg.ledMode = LED_MODES[(i + 1) % 3];
      if (cfg.ledMode != "off") ledsPreview();
      break;
    }
    case SET_STYLE: {
      int i = 0; for (int k = 0; k < 3; k++) if (cfg.ledStyle == LED_STYLES[k]) i = k;
      cfg.ledStyle = LED_STYLES[(i + 1) % 3];
      ledsNewOrder();  // show a few seconds of it
      flashUntil = millis() + 4000;
      break;
    }
    case SET_COLOR: {
      int i = -1; for (int k = 0; k < N_COLORS; k++) if (LED_COLORS[k] == cfg.ledColor) i = k;
      cfg.ledColor = LED_COLORS[(i + 1) % N_COLORS];
      ledsPreview();
      break;
    }
    case SET_BRIGHT: {
      int i = -1; for (int k = 0; k < 5; k++) if (BRIGHT_STEPS[k] <= cfg.ledBright) i = k;
      cfg.ledBright = BRIGHT_STEPS[(i + 1) % 5];
      ledsPreview();
      break;
    }
    case SET_FLASH: {
      int i = -1; for (int k = 0; k < 6; k++) if (FLASH_STEPS[k] <= cfg.flashSec) i = k;
      cfg.flashSec = FLASH_STEPS[(i + 1) % 6];
      break;
    }
    case SET_INFO: uiShow(S_INFO); return;
    case SET_WIFI:
      saveConfig();
      apKeepUntil = millis() + 15UL * 60 * 1000;
      startAP();
      uiNote("WIFI SETUP ON", "Join " + apName, C_AMBER, 6000);
      return;
  }
  uiDirty = true;
}

inline void drawNote() { bigMessage(noteBig, noteSmall, noteColor, noteColor == C_GREEN || noteColor == C_AMBER ? C_BLACK : C_WHITE); }

inline void uiDraw() {
  if (!screenReady) return;
  switch (uiScreen) {
    case S_HOME: drawHome(); break;
    case S_LIST: drawList(); break;
    case S_PREP: drawPrep(); break;
    case S_NEWORDER: drawNewOrder(); break;
    case S_INFO: drawInfo(); break;
    case S_NOTE: drawNote(); break;
    case S_IDLE: drawIdle(); break;
    case S_SET: drawSettings(); break;
  }
  uiDirty = false;
  uiRedrawAt = millis() + 20000;
  time_t t = nowEpoch(); uiMinute = t ? (int)((t / 60) % 1440) : -1;
}

inline void uiNewOrder() {
  uiLastInput = millis();
  ledsNewOrder();
  uiShow(S_NEWORDER, (unsigned long)max(cfg.flashSec, 5) * 1000);
}

// One reprint per press, and none within 4 s of the last, so a bump of the
// button can never run off a stack of copies.
inline bool reprintOk() {
  static unsigned long last = 0;
  if (last && millis() - last < 4000) return false;
  last = millis();
  return true;
}

inline void uiHandle(Btn b) {
  uiLastInput = millis();
  switch (uiScreen) {
    case S_HOME:
      if (b == B_UP || b == B_DOWN) { uiSel = 0; printLampHold = true; uiShow(S_LIST); }
      else if (b == B_MENU) { setSel = 0; uiShow(S_SET); }
      else if (b == B_PRINT) {
        if (orderCount) { if (!reprintOk()) break; uiSel = 0; uiNote("REPRINTING", "#" + orders[orderCount - 1].number, C_NAVY); uiDraw(); ordersReprint(orderCount - 1); }
        else uiNote("NO ORDERS", "Nothing to reprint yet", C_DIM);
      }
      break;
    case S_LIST:
      if (b == B_UP || b == B_DOWN) {
        int was = uiSel;
        if (b == B_UP) { if (uiSel > 0) uiSel--; else uiSel = max(0, orderCount - 1); }
        else { if (uiSel < orderCount - 1) uiSel++; else uiSel = 0; }
        if (uiSel != was) uiDirty = true;  // nothing to redraw with one order
      }
      else if (b == B_PRINT && orderCount) {
        if (!reprintOk()) break;
        int idx = orderCount - 1 - uiSel;
        uiNote("REPRINTING", "#" + orders[idx].number, C_NAVY); uiDraw();
        ordersReprint(idx);
      }
      else if (b == B_MENU) {
        if (orderCount) { uiPrep = cfg.prepDefault; uiShow(S_PREP); }
        else { printLampHold = false; uiShow(S_HOME); }
      }
      break;
    case S_PREP:
      if (b == B_UP || b == B_DOWN) {
        int was = uiPrep;
        uiPrep = b == B_UP ? min(uiPrep + 5, 120) : max(uiPrep - 5, 5);
        if (uiPrep != was) uiDirty = true;
      }
      else if (b == B_MENU) uiShow(S_LIST);
      else if (b == B_PRINT) {
        const OrderEntry& o = orders[orderCount - 1 - uiSel];
        bigMessage("SENDING", "#" + o.number + "  " + String(uiPrep) + " min", C_NAVY);
        bool ok = sendPrepTime(o.number, uiPrep);
        if (ok) { cfg.prepDefault = uiPrep; saveConfig(); uiNote("READY " + clockText(nowEpoch() + uiPrep * 60), "#" + o.number + " in " + String(uiPrep) + " min", C_GREEN, 2500); }
        else uiNote("NOT SENT", "Could not reach PFD", C_RED, 2500);
        uiShow(S_NOTE, 2500);
      }
      break;
    case S_NEWORDER:
      if (b == B_MENU && orderCount) { uiSel = 0; uiPrep = cfg.prepDefault; uiShow(S_PREP); }
      else if (b == B_PRINT && orderCount) { if (!reprintOk()) break; uiNote("REPRINTING", "#" + orders[orderCount - 1].number, C_NAVY); uiDraw(); ordersReprint(orderCount - 1); }
      else { printLampHold = false; uiShow(S_HOME); }
      break;
    case S_SET:
      if (b == B_UP) { setSel = (setSel + SET_ROWS - 1) % SET_ROWS; uiDirty = true; }
      else if (b == B_DOWN) { setSel = (setSel + 1) % SET_ROWS; uiDirty = true; }
      else if (b == B_PRINT) settingsChange();
      else if (b == B_MENU) {
        saveConfig();
        logf("lights: %s %s %d%% flash %ds (from screen)", cfg.ledMode.c_str(), colorHex(cfg.ledColor).c_str(), cfg.ledBright, cfg.flashSec);
        uiShow(S_HOME);
      }
      break;
    case S_IDLE:
      uiShow(S_HOME);  // first press just wakes it
      break;
    case S_INFO:
      uiShow(S_SET);
      break;
    case S_NOTE:
      printLampHold = false;
      uiShow(S_HOME);
      break;
  }
}

inline void uiTick() {
  if (!screenReady) return;
  unsigned long now = millis();
  Btn b = buttonsReady() ? readButton() : B_NONE;
  if (b != B_NONE) uiHandle(b);
  // Re-read the clock: handling a press stamps uiLastInput with a later
  // millis() than `now`, and now - uiLastInput would wrap to ~49 days.
  now = millis();

  if (uiExpireAt && (long)(now - uiExpireAt) >= 0) {
    uiExpireAt = 0;
    if (uiScreen == S_NOTE && noteColor != C_RED && orderCount && printLampHold) uiShow(S_LIST);
    else { printLampHold = false; uiShow(S_HOME); }
  }
  // Back to HOME after a while without a button press.
  if ((uiScreen == S_LIST || uiScreen == S_PREP || uiScreen == S_INFO || uiScreen == S_SET) && now - uiLastInput > 45000) {
    if (uiScreen == S_SET) saveConfig();
    printLampHold = false;
    uiShow(S_HOME);
  }
  // Logo + clock when nothing is happening. A live problem keeps the red
  // home screen up instead, so the kitchen sees it.
  bool problem = apOn || !WiFi.isConnected() || cfg.key.isEmpty() || (!cfg.key.isEmpty() && (!pollingHealthy() || errorText.length()));
  if (uiScreen == S_HOME && !problem && now - uiLastInput > IDLE_AFTER && (long)(now - flashUntil) >= 0) uiShow(S_IDLE);
  if (uiScreen == S_IDLE && problem) uiShow(S_HOME);
  // Redraw on the minute so the clock stays right.
  time_t t = nowEpoch();
  int minute = t ? (int)((t / 60) % 1440) : -1;
  bool clockScreen = uiScreen == S_HOME || uiScreen == S_IDLE;
  if (uiDirty || (clockScreen && minute != uiMinute) || (uiScreen == S_HOME && (long)(now - uiRedrawAt) >= 0)) uiDraw();
}

// ------------------------------------------------------------- wizards
// Which pin wakes the screen. Reads the display's colour-mode register
// back over SPI: after our init it reads 0x05; after a hardware reset it
// does not. Pulsing each spare pin HIGH and re-reading finds the one that
// resets it. If the display cannot be read back, the visual fallback shows
// the pin under test and the person says which number blanked the screen.
namespace rstfind {
inline void clk() { digitalWrite(cfg.tftSck, HIGH); delayMicroseconds(1); digitalWrite(cfg.tftSck, LOW); delayMicroseconds(1); }
inline void sendByte(uint8_t b) {
  pinMode(cfg.tftSda, OUTPUT);
  for (int i = 7; i >= 0; i--) { digitalWrite(cfg.tftSda, (b >> i) & 1); delayMicroseconds(1); clk(); }
}
inline uint8_t readReg(uint8_t reg) {
  pinMode(cfg.tftSck, OUTPUT); digitalWrite(cfg.tftSck, LOW);
  pinMode(cfg.tftDc, OUTPUT); pinMode(cfg.tftCs, OUTPUT);
  digitalWrite(cfg.tftCs, LOW);
  digitalWrite(cfg.tftDc, LOW);
  sendByte(reg);
  digitalWrite(cfg.tftDc, HIGH);
  pinMode(cfg.tftSda, INPUT_PULLUP);
  uint8_t v = 0;
  for (int i = 0; i < 8; i++) { digitalWrite(cfg.tftSck, HIGH); delayMicroseconds(1); v = (v << 1) | (digitalRead(cfg.tftSda) ? 1 : 0); digitalWrite(cfg.tftSck, LOW); delayMicroseconds(1); }
  digitalWrite(cfg.tftCs, HIGH);
  pinMode(cfg.tftSda, OUTPUT);
  return v;
}
inline void writeCmd(uint8_t c, int n = 0, uint8_t d = 0) {
  pinMode(cfg.tftSck, OUTPUT); digitalWrite(cfg.tftSck, LOW);
  pinMode(cfg.tftDc, OUTPUT); pinMode(cfg.tftCs, OUTPUT);
  digitalWrite(cfg.tftCs, LOW);
  digitalWrite(cfg.tftDc, LOW);
  sendByte(c);
  digitalWrite(cfg.tftDc, HIGH);
  if (n) sendByte(d);
  digitalWrite(cfg.tftCs, HIGH);
}
}  // namespace rstfind

inline int rstCandidates(int* out) {
  int n = 0;
  for (int p : ALL_GPIO) {
    if (p == cfg.tx || p == cfg.rx || p == cfg.tftSck || p == cfg.tftSda || p == cfg.tftCs || p == cfg.tftDc) continue;
    if (p == cfg.ledR || p == cfg.ledG || p == cfg.ledB || p == 1 || p == 3) continue;
    out[n++] = p;  // the PRINT lamp pin is included: it was only ever a guess
  }
  return n;
}

inline bool findResetPin() {
  int cand[24];
  int n = rstCandidates(cand);
  for (int i = 0; i < n; i++) { pinMode(cand[i], OUTPUT); digitalWrite(cand[i], LOW); }
  screenBegin();
  bigMessage("SCREEN CHECK", "finding the reset pin", C_NAVY);
  delay(300);
  // Does the display read back?
  rstfind::writeCmd(0x3A, 1, 0x05);
  uint8_t a = rstfind::readReg(0x0C);
  rstfind::writeCmd(0x3A, 1, 0x06);
  uint8_t b = rstfind::readReg(0x0C);
  rstfind::writeCmd(0x3A, 1, 0x05);
  bool readable = (a & 0x07) == 0x05 && (b & 0x07) == 0x06;
  logf("screen readback %s (0x%02X / 0x%02X)", readable ? "works" : "not available", a, b);
  int found = -1;
  if (readable) {
    for (int i = 0; i < n && found < 0; i++) {
      digitalWrite(cand[i], HIGH);
      delay(80);
      digitalWrite(cand[i], LOW);
      delay(150);
      uint8_t v = rstfind::readReg(0x0C);
      if ((v & 0x07) != 0x05) { found = cand[i]; }
      rstfind::writeCmd(0x3A, 1, 0x05);
    }
    screenBegin();
  } else {
    // Visual: no re-init between steps, so once the right pin has reset the
    // screen it stays white for every number after it. The last number seen
    // is the reset pin.
    screenBegin();
    for (int i = 0; i < n; i++) {
      tft->fillScreen(C_NAVY);
      centerText(14, "RESET TEST", C_WHITE, 2);
      centerText(44, String(cand[i]), C_AMBER, 4);
      centerText(96, "last number seen = answer", C_GREY);
      centerText(110, String(i + 1) + " of " + String(n), C_DIM);
      delay(1200);
      digitalWrite(cand[i], HIGH);
      delay(100);
      digitalWrite(cand[i], LOW);
      delay(1500);
    }
    screenBegin();
  }
  if (found >= 0) {
    cfg.rstDrive = found;
    saveConfig();
    logf("screen reset driver: GPIO %d", found);
    bigMessage("FOUND", "reset pin " + String(found), C_GREEN, C_BLACK);
  } else {
    logf("screen reset driver not found automatically%s", readable ? "" : " (visual test ran)");
    bigMessage("RESET TEST DONE", readable ? "no pin reset it" : "tell PFD which number blanked", C_NAVY);
  }
  delay(1500);
  uiDirty = true;
  return found >= 0;
}


// Resistor-ladder setup: watches the analog pins for a press, then learns
// the voltage each button produces. Returns true when all four are learned.
// Touch-pad front panel: learn which touch pad is which button.
inline bool findTouchButtons() {
  const int N = sizeof(TOUCH_PINS) / sizeof(int);
  int base[N];
  for (int i = 0; i < N; i++) base[i] = touchAvg(TOUCH_PINS[i], 16);
  String bl; for (int i = 0; i < N; i++) bl += String(TOUCH_PINS[i]) + "=" + String(base[i]) + " ";
  logf("touch rest: %s", bl.c_str());
  int got[4] = {-1, -1, -1, -1};
  for (int b = 0; b < 4; b++) {
    tft->fillScreen(C_NAVY);
    centerText(10, "BUTTON SETUP", C_WHITE, 2);
    centerText(44, "Press and hold the", C_GREY);
    centerText(60, BTN_NAMES[b], C_AMBER, 2);
    centerText(100, String(b + 1) + " of 4", C_GREY);
    unsigned long until = millis() + 60000;
    while (millis() < until && got[b] < 0) {
      for (int i = 0; i < N; i++) {
        if (base[i] <= 0) continue;
        bool dup = false; for (int k = 0; k < b; k++) if (got[k] == TOUCH_PINS[i]) dup = true;
        if (dup) continue;
        int v = touchAvg(TOUCH_PINS[i], 8);
        if (v < base[i] * 6 / 10) {
          delay(80);
          if (touchAvg(TOUCH_PINS[i], 8) < base[i] * 6 / 10) { got[b] = TOUCH_PINS[i]; logf("touch %s = GPIO %d (%d, rest %d)", BTN_NAMES[b], TOUCH_PINS[i], v, base[i]); break; }
        }
      }
      delay(10);
    }
    if (got[b] < 0) { logf("touch setup: nothing for %s", BTN_NAMES[b]); return false; }
    bigMessage("GOT IT", BTN_NAMES[b], C_GREEN, C_BLACK);
    int pin = got[b], ii = 0; for (int i = 0; i < N; i++) if (TOUCH_PINS[i] == pin) ii = i;
    unsigned long rel = millis() + 5000;
    while (touchAvg(pin, 8) < base[ii] * 8 / 10 && millis() < rel) delay(10);
    delay(400);
  }
  cfg.btnUp = got[0]; cfg.btnDown = got[1]; cfg.btnMenu = got[2]; cfg.btnPrint = got[3];
  cfg.btnPressedLevel = 2;
  cfg.btnAdc = -1;
  for (int b = 0; b < 4; b++) cfg.btnMv[b] = -1;
  saveConfig();
  buttonsBegin();
  bigMessage("BUTTONS READY", "touch pads", C_GREEN, C_BLACK);
  delay(1500);
  uiDirty = true;
  return true;
}

inline bool findLadderButtons() {
  int pins[] = {34, 35, 36, 39, 32, 33, 4};
  int idle[7];
  for (int i = 0; i < 7; i++) {
    if (isReserved(pins[i]) && pins[i] != cfg.btnAdc) { idle[i] = -1; continue; }
    pinMode(pins[i], INPUT);
    analogSetPinAttenuation(pins[i], ADC_11db);
    int s = 0; for (int k = 0; k < 8; k++) { s += analogReadMilliVolts(pins[i]); delay(3); }
    idle[i] = s / 8;
  }
  String idleLog;
  for (int i = 0; i < 7; i++) idleLog += String(pins[i]) + "=" + String(idle[i]) + "mV ";
  logf("ladder idle: %s", idleLog.c_str());

  int adc = -1, mv[4] = {-1, -1, -1, -1};
  for (int b = 0; b < 4; b++) {
    tft->fillScreen(C_NAVY);
    centerText(10, "BUTTON SETUP", C_WHITE, 2);
    centerText(44, "Press and hold the", C_GREY);
    centerText(60, BTN_NAMES[b], C_AMBER, 2);
    centerText(100, String(b + 1) + " of 4", C_GREY);
    unsigned long until = millis() + 90000;
    int got = -1;
    while (millis() < until && got < 0) {
      for (int i = 0; i < 7; i++) {
        if (idle[i] < 0 || (adc >= 0 && pins[i] != adc)) continue;
        int v = (int)analogReadMilliVolts(pins[i]);
        if (abs(v - idle[i]) < 250) continue;
        delay(60);  // let it settle, then average
        int s = 0; for (int k = 0; k < 16; k++) { s += analogReadMilliVolts(pins[i]); delay(2); }
        v = s / 16;
        if (abs(v - idle[i]) < 250) continue;
        bool dup = false;
        for (int k = 0; k < b; k++) if (abs(mv[k] - v) < 150) dup = true;
        if (dup) continue;
        adc = pins[i];
        got = v;
        break;
      }
      delay(10);
    }
    if (got < 0) {
      logf("ladder setup: no press seen for %s", BTN_NAMES[b]);
      bigMessage("NO PRESS SEEN", "tell PFD", C_RED);
      delay(2500);
      uiDirty = true;
      return false;
    }
    mv[b] = got;
    logf("button %s = %d mV on GPIO %d", BTN_NAMES[b], got, adc);
    bigMessage("GOT IT", BTN_NAMES[b], C_GREEN, C_BLACK);
    int ii = 0; for (int i = 0; i < 7; i++) if (pins[i] == adc) ii = i;
    unsigned long rel = millis() + 5000;
    while (abs((int)analogReadMilliVolts(adc) - idle[ii]) > 250 && millis() < rel) delay(10);
    delay(500);
  }
  cfg.btnAdc = adc;
  for (int b = 0; b < 4; b++) cfg.btnMv[b] = mv[b];
  for (int i = 0; i < 7; i++) if (pins[i] == adc) ladderIdle = idle[i];
  cfg.btnUp = cfg.btnDown = cfg.btnMenu = cfg.btnPrint = -1;
  saveConfig();
  logf("ladder buttons on GPIO %d: up %d down %d menu %d print %d mV", adc, mv[0], mv[1], mv[2], mv[3]);
  bigMessage("BUTTONS READY", "^ v orders, PRINT reprints", C_GREEN, C_BLACK);
  delay(2000);
  buttonsBegin();
  uiDirty = true;
  return true;
}

// Keypad boards (TCA9534 on the front panel): learn which input bit each
// button pulls low. The pin-scan setup below can't see these buttons at all.
inline bool findKeypadButtons() {
  int addr = keypadProbe();
  if (addr < 0) return false;
  delay(20);
  int idle = keypadReadAt(addr);
  logf("keypad chip at 0x%02X, idle bits %02X", addr, idle & 0xFF);
  int bits[4] = {-1, -1, -1, -1};
  for (int b = 0; b < 4; b++) {
    tft->fillScreen(C_NAVY);
    centerText(10, "BUTTON SETUP", C_WHITE, 2);
    centerText(44, "Press and hold the", C_GREY);
    centerText(60, BTN_NAMES[b], C_AMBER, 2);
    centerText(100, String(b + 1) + " of 4", C_GREY);
    unsigned long until = millis() + 90000;
    int got = -1;
    while (millis() < until && got < 0) {
      int v = keypadReadAt(addr);
      if (v >= 0) {
        int changed = (v ^ idle) & 0xFF;
        for (int k = 0; k < 8 && got < 0; k++) {
          if (!(changed & (1 << k))) continue;
          bool taken = false;
          for (int j = 0; j < b; j++) if (bits[j] == k) taken = true;
          if (taken) continue;
          delay(40);
          int v2 = keypadReadAt(addr);
          if (v2 >= 0 && ((v2 ^ idle) & (1 << k))) got = k;
        }
      }
      delay(10);
    }
    if (got < 0) {
      logf("keypad setup: no press seen for %s", BTN_NAMES[b]);
      bigMessage("NO PRESS SEEN", "tell PFD", C_RED);
      delay(2500);
      uiDirty = true;
      return true;  // handled (keypad exists); don't fall back to pin scan
    }
    bits[b] = got;
    logf("button %s = keypad bit %d", BTN_NAMES[b], got);
    bigMessage("GOT IT", BTN_NAMES[b], C_GREEN, C_BLACK);
    unsigned long rel = millis() + 5000;
    while (millis() < rel) { int v = keypadReadAt(addr); if (v >= 0 && !((v ^ idle) & (1 << got))) break; delay(10); }
    delay(400);
  }
  cfg.kpSda = 14; cfg.kpScl = 27; cfg.kpAddr = addr;
  for (int b = 0; b < 4; b++) cfg.kpBit[b] = bits[b];
  // Pressed normally reads low; a bit that idles low (pressed = high) is
  // flipped at read time through kpInv.
  cfg.kpInv = 0;
  for (int b = 0; b < 4; b++) if (!(idle & (1 << bits[b]))) cfg.kpInv |= 1 << bits[b];
  cfg.btnUp = cfg.btnDown = cfg.btnMenu = cfg.btnPrint = -1; cfg.btnAdc = -1;
  saveConfig();
  buttonsBegin();
  bigMessage("BUTTONS READY", "^ v orders, PRINT reprints", C_GREEN, C_BLACK);
  delay(2000);
  uiDirty = true;
  return true;
}

// Walks through the four buttons on screen. Needs the reset driver known,
// because every other spare pin becomes an input during the search.
inline bool findButtons() {
  if (findKeypadButtons()) return true;
  if (cfg.rstDrive < 0) {
    bigMessage("BUTTON SETUP", "find the reset pin first", C_RED);
    delay(2000);
    uiDirty = true;
    return false;
  }
  int cand[32];
  int n = 0;
  for (int p : ALL_GPIO) {
    if (p == cfg.tx || p == cfg.rx || p == cfg.tftSck || p == cfg.tftSda || p == cfg.tftCs || p == cfg.tftDc) continue;
    if (p == cfg.ledR || p == cfg.ledG || p == cfg.ledB || p == cfg.rstDrive || p == 1 || p == 3) continue;
    cand[n++] = p;
  }
  for (int p : INPUT_ONLY) cand[n++] = p;
  // Plain inputs, no internal pulls: the board's own resistors decide the
  // idle level, and a press moves the pin away from it in whichever direction.
  for (int i = 0; i < n; i++) pinMode(cand[i], INPUT);
  delay(80);
  int idle[32];
  for (int i = 0; i < n; i++) {
    int hi = 0;
    for (int k = 0; k < 8; k++) { hi += digitalRead(cand[i]); delay(2); }
    idle[i] = hi >= 6 ? 1 : (hi <= 2 ? 0 : -1);  // -1: floating, ignore
  }
  String idleLog;
  for (int i = 0; i < n; i++) idleLog += String(cand[i]) + (idle[i] == 1 ? "H " : idle[i] == 0 ? "L " : "? ");
  logf("button setup idle: %s", idleLog.c_str());

  int pins[4] = {-1, -1, -1, -1};
  int level = -1;
  for (int b = 0; b < 4; b++) {
    tft->fillScreen(C_NAVY);
    centerText(10, "BUTTON SETUP", C_WHITE, 2);
    centerText(44, "Press and hold the", C_GREY);
    centerText(60, BTN_NAMES[b], C_AMBER, 2);
    centerText(100, String(b + 1) + " of 4", C_GREY);
    unsigned long until = millis() + 90000;
    int got = -1;
    while (millis() < until && got < 0) {
      for (int i = 0; i < n; i++) {
        if (idle[i] < 0) continue;
        if (digitalRead(cand[i]) != idle[i]) {
          delay(40);
          if (digitalRead(cand[i]) == idle[i]) continue;
          bool taken = false;
          for (int k = 0; k < b; k++) if (pins[k] == cand[i]) taken = true;
          if (taken) continue;
          got = cand[i];
          if (level < 0) level = idle[i] ? 0 : 1;
          break;
        }
      }
      delay(5);
    }
    if (got < 0) {
      logf("button setup: no press seen for %s", BTN_NAMES[b]);
      bigMessage("NO PRESS SEEN", "tell PFD - trying another way", C_RED);
      delay(2500);
      break;
    }
    pins[b] = got;
    logf("button %s = GPIO %d", BTN_NAMES[b], got);
    bigMessage("GOT IT", BTN_NAMES[b] + String(" = pin ") + String(got), C_GREEN, C_BLACK);
    int gi = 0;
    for (int i = 0; i < n; i++) if (cand[i] == got) gi = i;
    unsigned long rel = millis() + 5000;
    while (digitalRead(got) != idle[gi] && millis() < rel) delay(10);  // wait for release
    delay(500);
  }
  if (pins[0] >= 0 && pins[1] >= 0 && pins[2] >= 0 && pins[3] >= 0) {
    cfg.btnUp = pins[0]; cfg.btnDown = pins[1]; cfg.btnMenu = pins[2]; cfg.btnPrint = pins[3];
    cfg.btnPressedLevel = level < 0 ? 0 : level;
    if (cfg.ledPrint == cfg.btnUp || cfg.ledPrint == cfg.btnDown || cfg.ledPrint == cfg.btnMenu || cfg.ledPrint == cfg.btnPrint || cfg.ledPrint == cfg.rstDrive) cfg.ledPrint = -1;
    saveConfig();
    logf("buttons: up %d down %d menu %d print %d, pressed=%s", pins[0], pins[1], pins[2], pins[3], cfg.btnPressedLevel ? "HIGH" : "LOW");
    bigMessage("BUTTONS READY", "^ v orders, PRINT reprints", C_GREEN, C_BLACK);
    delay(2000);
  }
  for (int i = 0; i < n; i++) {
    bool isBtn = false;
    for (int k = 0; k < 4; k++) if (pins[k] == cand[i]) isBtn = true;
    if (!isBtn && !isInputOnly(cand[i])) { pinMode(cand[i], OUTPUT); digitalWrite(cand[i], LOW); }
  }
  buttonsBegin();
  ledsBegin();
  uiDirty = true;
  return buttonsReady();
}
