#include <Wire.h>
#include "pixels.h"
// The printer's own settings page, plus the setup network on first boot.
#pragma once
#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <Update.h>
#include "config.h"
#include "printer.h"
#include "orders.h"
#include "leds.h"
#include "ui.h"
#include "net.h"
#include "sample_ticket.h"

inline WebServer web(80);
inline DNSServer dns;

// Work the page asks for, done from loop() so the reply goes out first.
inline bool pendingReboot = false, pendingTest = false, pendingSample = false, pendingFinder = false,
            pendingButtons = false, pendingResetFind = false;
inline int pendingReprint = -1;
inline int pinTestGpio = -1;
inline unsigned long pinTestUntil = 0;

static const int BAUDS[] = {9600, 19200, 38400, 57600, 115200};

inline bool authed() {
  if (apOn && !WiFi.isConnected()) return true;
  if (cfg.adminPw.isEmpty()) return true;
  if (web.authenticate("admin", cfg.adminPw.c_str())) return true;
  web.requestAuthentication(BASIC_AUTH, "PFD Printer");
  return false;
}

inline String esc(const String& s) {
  String o;
  for (size_t i = 0; i < s.length(); i++) {
    char c = s[i];
    if (c == '<') o += "&lt;"; else if (c == '>') o += "&gt;"; else if (c == '"') o += "&quot;"; else if (c == '&') o += "&amp;"; else o += c;
  }
  return o;
}

inline String opt(int v, int cur, const String& label) {
  return "<option value=\"" + String(v) + "\"" + (v == cur ? " selected" : "") + ">" + label + "</option>";
}

inline String pinSelect(const char* name, int cur, bool allowInputOnly = false) {
  String h = String("<select name=") + name + ">" + opt(-1, cur, "none");
  for (int p : ALL_GPIO) if (p != 1 && p != 3) h += opt(p, cur, "GPIO " + String(p));
  if (allowInputOnly) for (int p : INPUT_ONLY) h += opt(p, cur, "GPIO " + String(p));
  return h + "</select>";
}

static const char* CSS =
    "<style>body{font-family:system-ui,sans-serif;max-width:600px;margin:20px auto;padding:0 14px;color:#111}"
    "h1{font-size:22px}h3{margin-top:28px}label{display:block;margin:12px 0 4px;font-weight:600}label.net{font-weight:400;margin:8px 0;padding:10px;border:1px solid #ccc;border-radius:6px}label.net input{width:auto;margin-right:8px}input,select{width:100%;padding:9px;font-size:16px;box-sizing:border-box}"
    "button{padding:11px 16px;font-size:16px;margin:6px 6px 0 0;border:0;border-radius:6px;background:#111;color:#fff}"
    ".muted{color:#666;font-size:14px}.box{background:#f4f4f4;padding:10px 12px;border-radius:6px;font-size:14px}pre{white-space:pre-wrap;font-size:12px}"
    "table{width:100%;border-collapse:collapse;font-size:14px}td{padding:6px 4px;border-bottom:1px solid #ddd}.ok{color:#1a7f37}.bad{color:#b00}</style>";

inline void page(const String& title, const String& body) {
  web.send(200, "text/html", "<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'><title>" + title + "</title>" + CSS + body);
}

inline void back() { web.sendHeader("Location", "/"); web.send(303); }

// Tap-to-pick list of the WiFi networks this box can actually hear, strongest
// first, one row per name. A plain text box with a datalist showed the phone's
// own remembered networks instead (and nothing at all before a scan finished).
inline String wifiPicker() {
  String h;
  int n = WiFi.scanComplete();
  if (n == WIFI_SCAN_FAILED || n == -2) { WiFi.scanNetworks(true); n = -1; }
  if (n < 0) {
    h += "<p class=muted>Looking for WiFi networks&hellip;</p><script>setTimeout(()=>location.reload(),3000)</script>";
  } else {
    int idx[40]; int m = 0;
    for (int i = 0; i < n && m < 40; i++) {
      String id = WiFi.SSID(i);
      if (!id.length()) continue;
      bool dup = false;
      for (int j = 0; j < m; j++) if (WiFi.SSID(idx[j]) == id) { dup = true; if (WiFi.RSSI(i) > WiFi.RSSI(idx[j])) idx[j] = i; break; }
      if (!dup) idx[m++] = i;
    }
    for (int a = 0; a < m; a++) for (int b = a + 1; b < m; b++) if (WiFi.RSSI(idx[b]) > WiFi.RSSI(idx[a])) { int t = idx[a]; idx[a] = idx[b]; idx[b] = t; }
    if (!m) h += "<p class=muted>No networks found.</p>";
    for (int a = 0; a < m; a++) {
      int i = idx[a]; String id = WiFi.SSID(i); int r = WiFi.RSSI(i);
      String bars = r > -60 ? "strong" : r > -72 ? "good" : r > -82 ? "weak" : "very weak";
      bool open = WiFi.encryptionType(i) == WIFI_AUTH_OPEN;
      h += "<label class=net><input type=radio name=ssid value=\"" + esc(id) + "\"" + String(id == cfg.ssid ? " checked" : "") + "> " + esc(id) +
           " <span class=muted>(" + bars + (open ? ", no password" : "") + ")</span></label>";
    }
    h += "<label class=net><input type=radio name=ssid value=\"\"" + String(m ? "" : " checked") + "> Other (type the name)</label>";
    h += "<input name=ssid_other autocomplete=off autocapitalize=none placeholder=\"Network name\">";
    h += "<p><a href=/rescan>Scan again</a></p>";
  }
  return h;
}

inline String chosenSsid() {
  String o = web.arg("ssid_other"); o.trim();
  return o.length() ? o : web.arg("ssid");
}

inline void pageWifiSetup() {
  String h = "<h1>Connect this printer to WiFi</h1><form method=post action=/wifi>";
  h += "<label>Pick the store WiFi</label>" + wifiPicker();
  h += "<label>WiFi password</label><input name=pass type=password autocomplete=off>";
  h += "<button>Save</button></form><p class=muted>The printer restarts and joins it. Only 2.4 GHz networks show up.</p>";
  page("WiFi setup", h);
}

inline void pageRoot() {
  if (!authed()) return;
  if (apOn && !WiFi.isConnected()) { pageWifiSetup(); return; }
  String h = "<h1>PFD Printer</h1><div class=box>";
  h += "Firmware " FW_VERSION "<br>WiFi: " + (WiFi.isConnected() ? esc(cfg.ssid) + " &middot; " + WiFi.localIP().toString() + " &middot; " + String(WiFi.RSSI()) + " dBm" : String("not connected"));
  h += "<br>Device key: " + esc(keyHint());
  h += "<br>Status: " + String(errorText.length() ? "<span class=bad>" + esc(errorText) + "</span>" : (pollingHealthy() ? "<span class=ok>online</span>" : "waiting for first poll"));
  h += "<br>Last poll: " + esc(lastPollResult) + (lastPollOkAt ? " (" + String((millis() - lastPollOkAt) / 1000) + "s ago)" : "");
  h += "<br>Screen: " + String(screenReady ? "working" : "off") + " &middot; Buttons: " + String(buttonsReady() ? "set up" : "<span class=bad>not set up</span>");
  h += "<br>Tickets since boot: " + String(ticketsPrinted) + "</div>";

  h += "<p><a href=/sample><button>Print sample ticket</button></a><a href=/test><button>Print test page</button></a>";
  h += "<a href=/buttons><button>Set up buttons</button></a></p>";

  // Today's orders
  h += "<h3>Today's orders</h3>";
  if (!orderCount) h += "<p class=muted>None yet.</p>";
  else {
    h += "<table>";
    for (int i = orderCount - 1; i >= 0; i--) {
      const OrderEntry& o = orders[i];
      h += "<tr><td>" + esc(clockText(o.at)) + "</td><td>#" + esc(o.number) + "</td><td>" + esc(o.type) + "</td><td>" + esc(o.name) + "</td><td>" + esc(o.total) + "</td><td><a href=/reprint?i=" + String(i) + ">reprint</a></td></tr>";
    }
    h += "</table>";
  }

  h += "<h3>Settings</h3><form method=post action=/save>";
  h += "<label>WiFi network</label>" + wifiPicker();
  h += "<label>WiFi password</label><input name=pass type=password placeholder=\"" + String(cfg.pass.isEmpty() ? "" : "(unchanged)") + "\">";
  h += "<label>Device key</label><input name=key autocomplete=off placeholder=\"" + String(cfg.key.isEmpty() ? "PFD-XXXX-XXXX-XXXX" : "(unchanged, ends " + esc(keyHint()) + ")") + "\">";
  h += "<p class=muted>From the CRM: Devices, add printer, copy the key.</p>";
  h += "<label>Paper</label><select name=dots>" + opt(576, cfg.dots, "80mm") + opt(384, cfg.dots, "58mm") + "</select>";
  h += "<label>Large text</label><select name=tall>" + opt(1, cfg.tallText, "yes, every line double height") + opt(0, cfg.tallText, "no") + "</select>";
  h += "<label>Compact (no blank lines)</label><select name=compact>" + opt(1, cfg.compact, "yes") + opt(0, cfg.compact, "no") + "</select>";
  h += "<label>Default prep time (minutes)</label><input name=prep type=number min=5 max=120 value=" + String(cfg.prepDefault) + ">";
  h += "<label>Check for orders every (seconds)</label><input name=poll type=number min=2 max=60 value=" + String(cfg.pollSec) + ">";
  h += "<label>Settings password (optional)</label><input name=admin type=password placeholder=\"" + String(cfg.adminPw.isEmpty() ? "none" : "(unchanged)") + "\">";
  h += "<p><button>Save and restart</button></p></form>";

  h += "<h3>Lights</h3><form method=post action=/leds>";
  h += "<label>Ring</label><select name=mode>";
  for (const char* m : {"flash", "solid", "off"})
    h += String("<option value=") + m + (cfg.ledMode == m ? " selected" : "") + ">" +
         (String(m) == "flash" ? "Off until a new order, red on a problem" : String(m) == "solid" ? "Always on, red on a problem" : "Always off") + "</option>";
  h += "</select><label>Colour</label><input type=color name=color value=\"" + colorHex(cfg.ledColor) + "\" style=height:48px>";
  h += "<label>Flash style</label><select name=style>";
  for (const char* st : {"pulse", "blink", "rainbow"})
    h += String("<option value=") + st + (cfg.ledStyle == st ? " selected" : "") + ">" + (strcmp(st, "pulse") == 0 ? "Pulse" : strcmp(st, "blink") == 0 ? "Blink" : "Rainbow") + "</option>";
  h += "</select>";
  h += "<label>Brightness (%)</label><input type=range name=bright min=5 max=100 value=" + String(cfg.ledBright) + ">";
  h += "<label>New-order flash (seconds)</label><input name=flashsec type=number min=0 max=120 value=" + String(cfg.flashSec) + ">";
  h += "<p><button>Save lights</button></p></form>";

  h += "<details><summary class=muted>Board wiring (set once per board model)</summary><form method=post action=/wiring>";
  h += "<label>Printer TX pin</label>" + pinSelect("tx", cfg.tx) + "<label>Baud</label><select name=baud>";
  for (int b : BAUDS) h += opt(b, cfg.baud, String(b));
  h += "</select><label>Printer status pin (optional)</label>" + pinSelect("rx", cfg.rx, true);
  h += "<label>Cutter</label><select name=cutter>" + opt(1, cfg.cutter, "yes") + opt(0, cfg.cutter, "no, tear bar") + "</select>";
  h += "<label>Screen SCK / SDA / CS / A0</label><div style='display:flex;gap:6px'>" + pinSelect("tsck", cfg.tftSck) + pinSelect("tsda", cfg.tftSda) + pinSelect("tcs", cfg.tftCs) + pinSelect("tdc", cfg.tftDc) + "</div>";
  h += "<label>Screen reset driver</label>" + pinSelect("rst", cfg.rstDrive) + "<p class=muted><a href=/findreset>Find it automatically</a> (screen must be working).</p>";
  h += "<label>LED red / green / blue</label><div style='display:flex;gap:6px'>" + pinSelect("r", cfg.ledR) + pinSelect("g", cfg.ledG) + pinSelect("b", cfg.ledB) + "</div>";
  h += "<label>PRINT button lamp</label>" + pinSelect("lp", cfg.ledPrint);
  h += "<label>Buttons up / down / menu / print</label><div style='display:flex;gap:6px'>" + pinSelect("bu", cfg.btnUp, true) + pinSelect("bd", cfg.btnDown, true) + pinSelect("bm", cfg.btnMenu, true) + pinSelect("bp", cfg.btnPrint, true) + "</div>";
  h += "<label>LEDs inverted</label><select name=low>" + opt(0, cfg.ledActiveLow, "no") + opt(1, cfg.ledActiveLow, "yes") + "</select>";
  h += "<label>Print server</label><input name=url value=\"" + esc(cfg.url) + "\">";
  h += "<p><button>Save wiring and restart</button></p></form>";
  h += "<p class=muted>Pin tester (2 seconds high, number shown on screen): ";
  for (int p : ALL_GPIO) if (!isReserved(p)) h += "<a href=/pin?g=" + String(p) + "><button type=button>" + String(p) + "</button></a>";
  h += "</p><p><a href=/finder><button type=button>Find printer pin</button></a></p></details>";

  h += "<h3>Firmware</h3><form method=post action=/update enctype=multipart/form-data><input type=file name=fw accept=.bin><button>Upload</button></form>";
  h += "<h3>Activity</h3><pre>";
  for (int i = 0; i < 30; i++) { const String& l = logLines[(logHead + i) % 30]; if (l.length()) h += esc(l) + "\n"; }
  h += "</pre>";
  page("PFD Printer", h);
}

inline void pageSave() {
  if (!authed()) return;
  { String id = chosenSsid(); if (id.length()) cfg.ssid = id; }
  if (web.arg("pass").length()) cfg.pass = web.arg("pass");
  String k = web.arg("key"); k.trim();
  if (k.length()) { cfg.key = k; cfg.announce = true; }
  if (web.arg("admin").length()) cfg.adminPw = web.arg("admin");
  cfg.dots = web.arg("dots").toInt() == 384 ? 384 : 576;
  cfg.tallText = web.arg("tall") != "0";
  cfg.compact = web.arg("compact") != "0";
  cfg.prepDefault = constrain(web.arg("prep").toInt(), 5, 120);
  cfg.pollSec = constrain(web.arg("poll").toInt(), 2, 60);
  cfg.announce = cfg.announce || chosenSsid().length();
  saveConfig();
  page("Saved", "<h1>Saved</h1><p>Restarting. Once it reaches PFD it prints a PRINTER ONLINE slip.</p>");
  pendingReboot = true;
}

inline void pageLeds() {
  if (!authed()) return;
  String m = web.arg("mode");
  if (m == "off" || m == "solid" || m == "flash") cfg.ledMode = m;
  { String st = web.arg("style"); if (st == "pulse" || st == "blink" || st == "rainbow") cfg.ledStyle = st; }
  if (web.hasArg("color")) cfg.ledColor = parseColor(web.arg("color"));
  if (web.hasArg("bright")) cfg.ledBright = constrain(web.arg("bright").toInt(), 5, 100);
  if (web.hasArg("flashsec")) cfg.flashSec = constrain(web.arg("flashsec").toInt(), 0, 120);
  saveConfig();
  logf("lights: %s %s %d%% flash %ds", cfg.ledMode.c_str(), colorHex(cfg.ledColor).c_str(), cfg.ledBright, cfg.flashSec);
  back();
}

inline void pageWiring() {
  if (!authed()) return;
  cfg.tx = web.arg("tx").toInt();
  cfg.rx = web.arg("rx").toInt();
  cfg.baud = web.arg("baud").toInt(); if (cfg.baud < 1200) cfg.baud = 19200;
  cfg.cutter = web.arg("cutter") == "1";
  cfg.tftSck = web.arg("tsck").toInt(); cfg.tftSda = web.arg("tsda").toInt(); cfg.tftCs = web.arg("tcs").toInt(); cfg.tftDc = web.arg("tdc").toInt();
  cfg.rstDrive = web.arg("rst").toInt();
  cfg.ledR = web.arg("r").toInt(); cfg.ledG = web.arg("g").toInt(); cfg.ledB = web.arg("b").toInt();
  cfg.ledPrint = web.arg("lp").toInt();
  cfg.btnUp = web.arg("bu").toInt(); cfg.btnDown = web.arg("bd").toInt(); cfg.btnMenu = web.arg("bm").toInt(); cfg.btnPrint = web.arg("bp").toInt();
  if (cfg.btnUp >= 0 && cfg.btnDown >= 0 && cfg.btnMenu >= 0 && cfg.btnPrint >= 0) { cfg.btnAdc = -1; if (cfg.btnPressedLevel == 2) cfg.btnPressedLevel = 0; }
  cfg.ledActiveLow = web.arg("low") == "1";
  String u = web.arg("url"); u.trim(); cfg.url = u.length() ? u : DEFAULT_URL;
  saveConfig();
  page("Saved", "<h1>Saved</h1><p>Restarting with the new wiring.</p>");
  pendingReboot = true;
}

inline void pagePin() {
  if (!authed()) return;
  int g = web.arg("g").toInt();
  bool ok = false;
  for (int p : ALL_GPIO) if (p == g && !isReserved(p)) ok = true;
  if (ok) {
    pinMode(g, OUTPUT);
    digitalWrite(g, HIGH);
    pinTestGpio = g;
    pinTestUntil = millis() + 2000;
    logf("pin test GPIO %d high for 2s", g);
    bigMessage("PIN TEST", "pin " + String(g) + " is on now", C_BLACK);
  }
  back();
}

inline void updateDone() {
  if (!authed()) return;
  bool ok = !Update.hasError();
  page("Update", ok ? "<h1>Updated</h1><p>Restarting.</p>" : "<h1>Update failed</h1><p><a href=/>Back</a></p>");
  if (ok) pendingReboot = true;
}

inline void updateUpload() {
  if (!authed()) return;
  HTTPUpload& up = web.upload();
  if (up.status == UPLOAD_FILE_START) { logf("firmware upload %s", up.filename.c_str()); bigMessage("UPDATING", "do not unplug", C_NAVY); Update.begin(UPDATE_SIZE_UNKNOWN); }
  else if (up.status == UPLOAD_FILE_WRITE) Update.write(up.buf, up.currentSize);
  else if (up.status == UPLOAD_FILE_END) { if (Update.end(true)) logf("firmware update ok, %u bytes", up.totalSize); else logf("firmware update failed"); }
}

inline void captive() {
  if (apOn && !WiFi.isConnected()) { web.sendHeader("Location", "http://192.168.4.1/"); web.send(302); }
  else web.send(404, "text/plain", "not found");
}

inline void startAP() {
  if (apOn) return;
  WiFi.mode(WIFI_AP_STA);  // STA side on so the box can scan for the store's WiFi
  WiFi.softAP(apName.c_str());
  dns.start(53, "*", WiFi.softAPIP());
  apOn = true;
  uiDirty = true;
  WiFi.scanNetworks(true);
  logf("setup network %s open at %s", apName.c_str(), WiFi.softAPIP().toString().c_str());
}

inline void stopAP() {
  if (!apOn) return;
  dns.stop();
  WiFi.softAPdisconnect(true);
  WiFi.mode(WIFI_STA);
  apOn = false;
  uiDirty = true;
  logf("setup network closed");
}

inline void webBegin() {
  web.on("/", HTTP_GET, pageRoot);
  web.on("/rescan", HTTP_GET, []() { WiFi.scanDelete(); WiFi.scanNetworks(true); back(); });
  web.on("/wifi", HTTP_POST, []() {
    if (!authed()) return;
    String id = chosenSsid();
    if (!id.length()) { page("WiFi", "<h1>Pick a network</h1><p><a href=/>Back</a></p>"); return; }
    cfg.ssid = id; cfg.pass = web.arg("pass"); cfg.announce = true;
    saveConfig();
    logf("WiFi set to %s from the setup page", id.c_str());
    page("Saved", "<h1>Saved</h1><p>Joining " + esc(id) + ". The screen shows PAIR PRINTER with a code once it is online.</p>");
    pendingReboot = true;
  });
  web.on("/save", HTTP_POST, pageSave);
  web.on("/leds", HTTP_POST, pageLeds);
  web.on("/wiring", HTTP_POST, pageWiring);
  web.on("/pin", HTTP_GET, pagePin);
  // I2C scan: try every pin pair as SDA/SCL and look for a keypad/IO chip.
  // /i2cread?sda=..&scl=..&a=.. reads one byte from it.
  web.on("/i2cscan", HTTP_GET, []() {
    if (!authed()) return;
    static const int cand[] = {5, 12, 13, 14, 16, 17, 18, 19, 21, 25, 26, 27, 32, 33};
    const int n = sizeof(cand) / sizeof(int);
    String o;
    for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) {
      if (i == j) continue;
      Wire.end();
      if (!Wire.begin(cand[i], cand[j], 50000)) continue;
      Wire.setTimeOut(5);
      for (int a = 0x08; a < 0x78; a++) {
        Wire.beginTransmission(a);
        if (Wire.endTransmission() == 0) o += "SDA " + String(cand[i]) + " SCL " + String(cand[j]) + " addr 0x" + String(a, HEX) + "\n";
      }
      yield();
    }
    Wire.end();
    parkSparePins();
    screenBegin();
    uiDirty = true;
    web.send(200, "text/plain", o.length() ? o : String("no I2C device found\n"));
  });
  // /setpixels?pin=12[&n=30]: board B ring on an addressable-LED data pin.
  web.on("/setpixels", HTTP_GET, []() {
    if (!authed()) return;
    cfg.pixPin = web.arg("pin").toInt();
    if (web.hasArg("n")) cfg.pixCount = web.arg("n").toInt();
    cfg.ledR = cfg.ledG = cfg.ledB = -1;
    saveConfig();
    logf("ring: addressable LEDs on GPIO %d", cfg.pixPin);
    web.send(200, "text/plain", "saved, restarting\n");
    pendingReboot = true;
  });
  // LED data-pin scan: each candidate pin in turn gets "all green", with its
  // number on the screen for 3 s. The number showing when the ring lights
  // is the data pin.
  web.on("/ledscan", HTTP_GET, []() {
    if (!authed()) return;
    web.send(200, "text/plain", "scanning LED pins, ~40 s; watch the ring and the screen\n");
    static const int cand[] = {5, 12, 13, 16, 17, 18, 19, 21, 25, 26, 32, 33};
    for (int p : cand) {
      if (isReserved(p) && p != cfg.ledR && p != cfg.ledG && p != cfg.ledB) continue;
      if (tft) { tft->fillScreen(C_BLACK); centerText(20, "LED TEST", C_WHITE, 2); centerText(56, String(p), C_AMBER, 4); centerText(108, "ring lit = this pin", C_GREY); }
      ledcDetach(p);
      pinMode(p, OUTPUT); digitalWrite(p, LOW); delay(5);
      pixelsFill(p, 40, 0x003000);
      delay(3000);
      pixelsFill(p, 40, 0);
      pixelsRelease();
      pinMode(p, OUTPUT); digitalWrite(p, LOW);
    }
    uiDirty = true;
    logf("led scan done");
  });
  // Board B keypad: /setkeypad?sda=14&scl=27[&u=3&d=2&m=1&p=7] saves it.
  web.on("/setkeypad", HTTP_GET, []() {
    if (!authed()) return;
    cfg.kpSda = web.arg("sda").toInt(); cfg.kpScl = web.arg("scl").toInt();
    if (web.hasArg("u")) { cfg.kpBit[0] = web.arg("u").toInt(); cfg.kpBit[1] = web.arg("d").toInt(); cfg.kpBit[2] = web.arg("m").toInt(); cfg.kpBit[3] = web.arg("p").toInt(); }
    cfg.btnUp = cfg.btnDown = cfg.btnMenu = cfg.btnPrint = -1; cfg.btnAdc = -1;
    saveConfig();
    logf("keypad: TCA9534 SDA %d SCL %d bits %d/%d/%d/%d", cfg.kpSda, cfg.kpScl, cfg.kpBit[0], cfg.kpBit[1], cfg.kpBit[2], cfg.kpBit[3]);
    buttonsBegin();
    web.send(200, "text/plain", "saved\n");
  });
  // TCA9534: read the input port register (0x00) for each candidate SCL.
  web.on("/tca", HTTP_GET, []() {
    if (!authed()) return;
    int sda = web.hasArg("sda") ? web.arg("sda").toInt() : 14;
    String list = web.hasArg("scl") ? web.arg("scl") : String("5,12,13,16,17,18,19,21,25,26,27,32,33");
    String o;
    int from = 0;
    while (from <= (int)list.length()) {
      int comma = list.indexOf(',', from); if (comma < 0) comma = list.length();
      int scl = list.substring(from, comma).toInt(); from = comma + 1;
      Wire.end(); Wire.begin(sda, scl, 100000); Wire.setTimeOut(5);
      Wire.beginTransmission(0x20); Wire.write(0x00);
      int e = Wire.endTransmission(false);
      int got = Wire.requestFrom(0x20, 1);
      o += "scl " + String(scl) + ": tx " + String(e) + " got " + String(got);
      if (got) o += " in=" + String(Wire.read() | 0x100, BIN).substring(1);
      o += "\n";
    }
    Wire.end();
    web.send(200, "text/plain", o);
  });
  web.on("/i2cread", HTTP_GET, []() {
    if (!authed()) return;
    int sda = web.arg("sda").toInt(), scl = web.arg("scl").toInt(), a = strtol(web.arg("a").c_str(), nullptr, 16);
    Wire.end(); Wire.begin(sda, scl, 100000);
    String o;
    int got = Wire.requestFrom(a, 2);
    while (Wire.available()) o += String(Wire.read(), BIN) + " ";
    web.send(200, "text/plain", String(got) + ": " + o + "\n");
  });
  // Matrix keypad probe: every candidate line idles as a pulled-up input;
  // drive one LOW at a time and read the sense pin. A held button shows the
  // line it connects to the sense pin.
  web.on("/matrix", HTTP_GET, []() {
    if (!authed()) return;
    int sense = web.hasArg("sense") ? web.arg("sense").toInt() : 35;
    static const int cand[] = {5, 12, 13, 14, 16, 17, 18, 19, 21, 25, 26, 27, 32, 33};
    pinMode(sense, INPUT);
    for (int c : cand) if (c != cfg.tftSck && c != cfg.tftSda && c != cfg.tftCs && c != cfg.tftDc && c != cfg.rstDrive && c != cfg.tx) pinMode(c, INPUT_PULLUP);
    delay(2);
    String o = "idle " + String(digitalRead(sense)) + " |";
    for (int c : cand) {
      if (c == cfg.tftSck || c == cfg.tftSda || c == cfg.tftCs || c == cfg.tftDc || c == cfg.rstDrive || c == cfg.tx) continue;
      pinMode(c, OUTPUT); digitalWrite(c, LOW); delayMicroseconds(400);
      if (!digitalRead(sense)) o += " " + String(c);
      pinMode(c, INPUT_PULLUP); delayMicroseconds(200);
    }
    web.send(200, "text/plain", o + "\n");
  });
  // Ladder keypad: /mv?pin=35 reads the line in millivolts (avg of 16);
  // /setladder?pin=35&u=..&d=..&m=..&p=.. saves it as the keypad.
  web.on("/mv", HTTP_GET, []() {
    if (!authed()) return;
    int p = web.arg("pin").toInt();
    pinMode(p, INPUT);
    long s = 0; for (int i = 0; i < 16; i++) s += analogReadMilliVolts(p);
    web.send(200, "text/plain", String(s / 16) + "\n");
  });
  web.on("/setladder", HTTP_GET, []() {
    if (!authed()) return;
    cfg.btnAdc = web.arg("pin").toInt();
    cfg.btnMv[0] = web.arg("u").toInt(); cfg.btnMv[1] = web.arg("d").toInt();
    cfg.btnMv[2] = web.arg("m").toInt(); cfg.btnMv[3] = web.arg("p").toInt();
    cfg.btnUp = cfg.btnDown = cfg.btnMenu = cfg.btnPrint = -1;
    saveConfig();
    logf("keypad set: GPIO %d up %d down %d menu %d print %d mV", cfg.btnAdc, cfg.btnMv[0], cfg.btnMv[1], cfg.btnMv[2], cfg.btnMv[3]);
    buttonsBegin();
    web.send(200, "text/plain", "saved\n");
  });
  // Input scan: every pin not used by the screen, printer or ring, read with
  // a pull-up. A pressed button-to-ground reads 0. For finding buttons.
  web.on("/inputs", HTTP_GET, []() {
    if (!authed()) return;
    String o;
    static const int pins[] = {4, 5, 12, 13, 14, 16, 17, 18, 19, 21, 22, 23, 25, 26, 27, 32, 33, 34, 35, 36, 39};
    for (int p : pins) {
      if (p == cfg.tftSck || p == cfg.tftSda || p == cfg.tftCs || p == cfg.tftDc || p == cfg.rstDrive || p == cfg.tx ||
          p == cfg.ledR || p == cfg.ledG || p == cfg.ledB) continue;
      bool inOnly = p >= 34;
      pinMode(p, inOnly ? INPUT : INPUT_PULLUP);
      delayMicroseconds(300);
      o += String(p) + "=" + String(digitalRead(p)) + " ";
    }
    web.send(200, "text/plain", o + "\n");
  });
  // SPI scan: try every pair of candidate pins as SDA/SCK, drawing the pair on
  // the screen each time. On the right pair the screen shows its own answer.
  // Runs ~4 minutes; the web server is busy meanwhile.
  web.on("/scanspi", HTTP_GET, []() {
    if (!authed()) return;
    web.send(200, "text/plain", "scanning SDA/SCK pairs for ~4 minutes; watch the screen\n");
    static const int cand[] = {5, 12, 13, 14, 15, 16, 17, 18, 19, 21, 23, 25, 26, 27, 32, 33};
    const int n = sizeof(cand) / sizeof(int);
    int saveSda = cfg.tftSda, saveSck = cfg.tftSck, tries = 0;
    for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) {
      if (i == j) continue;
      cfg.tftSda = cand[i]; cfg.tftSck = cand[j];
      screenBegin();
      if (tft) {
        tft->fillScreen(C_BLACK);
        centerText(10, "SCREEN FOUND", C_GREEN, 2);
        centerText(44, "SDA " + String(cand[i]), C_WHITE, 3);
        centerText(80, "SCK " + String(cand[j]), C_WHITE, 3);
        centerText(114, "tell PFD these numbers", C_GREY);
      }
      tries++;
      delay(700);
      yield();
    }
    cfg.tftSda = saveSda; cfg.tftSck = saveSck;
    logf("spi scan done: %d pairs tried", tries);
    parkSparePins();
    screenBegin();
    uiDirty = true;
  });
  // Pin finder: with a jumper from a known screen pin (its GPIO = probe,
  // default A0 = GPIO 2) to the screen pin under test, pulse every other
  // GPIO and report which one shows up on the probe.
  web.on("/findpin", HTTP_GET, []() {
    if (!authed()) return;
    int probe = web.hasArg("probe") ? web.arg("probe").toInt() : cfg.tftDc;
    pinMode(probe, INPUT_PULLDOWN);
    delay(5);
    String o = "probe GPIO " + String(probe) + " idle " + String(digitalRead(probe)) + "\n";
    int found = -1;
    for (int c : ALL_GPIO) {
      if (c == probe || c == cfg.tx) continue;
      pinMode(c, OUTPUT); digitalWrite(c, LOW); delay(2);
      int low = digitalRead(probe);
      digitalWrite(c, HIGH); delay(2);
      int high = digitalRead(probe);
      digitalWrite(c, LOW);
      o += "GPIO " + String(c) + ": " + String(low) + "->" + String(high) + "\n";
      if (!low && high && found < 0) found = c;
    }
    o += found >= 0 ? "FOUND GPIO " + String(found) + "\n" : "nothing connected to the probe\n";
    logf("findpin via GPIO %d: %s", probe, found >= 0 ? String(found).c_str() : "none");
    web.send(200, "text/plain", o);
    parkSparePins();
    screenBegin();
    uiDirty = true;
  });
  // Wire check: /drive?g=N&v=1 drives any GPIO (screen pins included) to a
  // level for 8 s so it can be measured at the far end of its wire, then the
  // screen is re-initialised.
  web.on("/drive", HTTP_GET, []() {
    if (!authed()) return;
    int g = web.arg("g").toInt(), v = web.arg("v").toInt() ? HIGH : LOW;
    bool ok = false; for (int p : ALL_GPIO) if (p == g) ok = true;
    if (!ok) { web.send(400, "text/plain", "bad pin\n"); return; }
    pinMode(g, OUTPUT); digitalWrite(g, v);
    logf("drive GPIO %d %s for 8s", g, v ? "HIGH" : "LOW");
    web.send(200, "text/plain", String("GPIO ") + g + (v ? " HIGH" : " LOW") + " for 8 s\n");
    delay(8000);
    parkSparePins();
    screenBegin();
    uiDirty = true;
  });
  // Screen reset polarity test: /screentest?hi=1 runs the screen with the
  // reset driver HIGH, hi=0 with it LOW; add save=1 to keep the setting.
  web.on("/screentest", HTTP_GET, []() {
    if (!authed()) return;
    cfg.rstHigh = web.arg("hi") == "1";
    screenBegin();
    bigMessage("SCREEN TEST", cfg.rstHigh ? "reset line HIGH" : "reset line LOW", C_GREEN, C_BLACK);
    logf("screen test: reset driver %s", cfg.rstHigh ? "HIGH" : "LOW");
    if (web.arg("save") == "1") { saveConfig(); logf("screen reset polarity saved"); }
    uiRedrawAt = millis() + 8000;
    web.send(200, "text/plain", String("screen re-initialised with reset driver ") + (cfg.rstHigh ? "HIGH" : "LOW") + "\n");
  });
  web.on("/touch", HTTP_GET, []() {
    if (!authed()) return;
    String o;
    for (int p : TOUCH_PINS) o += String(p) + "=" + String(touchAvg(p, 8)) + " ";
    web.send(200, "text/plain", o);
  });
  // Live keypad readings: what the ladder line reads right now, 100 samples.
  web.on("/adc", HTTP_GET, []() {
    if (!authed()) return;
    String o = "pin " + String(cfg.btnAdc) + " idle " + String(ladderIdle) + " up " + String(cfg.btnMv[0]) + " down " + String(cfg.btnMv[1]) +
               " menu " + String(cfg.btnMv[2]) + " print " + String(cfg.btnMv[3]) + "\n";
    if (cfg.btnAdc >= 0) {
      int mn = 99999, mx = 0; long sum = 0; String seq;
      for (int i = 0; i < 100; i++) {
        int v = analogReadMilliVolts(cfg.btnAdc);
        mn = min(mn, v); mx = max(mx, v); sum += v;
        if (i % 5 == 0) seq += String(v) + " ";
        delay(5);
      }
      o += "now min " + String(mn) + " max " + String(mx) + " avg " + String(sum / 100) + "\n" + seq + "\n";
    }
    web.send(200, "text/plain", o);
  });
  web.on("/test", HTTP_GET, []() { if (!authed()) return; pendingTest = true; back(); });
  web.on("/sample", HTTP_GET, []() { if (!authed()) return; pendingSample = true; back(); });
  web.on("/finder", HTTP_GET, []() { if (!authed()) return; pendingFinder = true; page("Pin finder", "<h1>Printing pin test</h1><p>Find the one line on the paper that reads cleanly, like <b>PIN 22 BAUD 19200</b>, and set those under Board wiring.</p>"); });
  web.on("/buttons", HTTP_GET, []() { if (!authed()) return; pendingButtons = true; page("Buttons", "<h1>Go to the printer</h1><p>The screen asks for each button in turn. Press them as it asks. If the screen says to find the reset pin first, it does that on its own and then asks again.</p>"); });
  web.on("/findreset", HTTP_GET, []() { if (!authed()) return; pendingResetFind = true; page("Reset pin", "<h1>Watch the screen</h1><p>Takes up to a minute. If the printer cannot work it out on its own, it shows a number for each pin; tell PFD the number that was showing when the screen went blank.</p>"); });
  web.on("/resetpin", HTTP_GET, []() {
    if (!authed()) return;
    int g = web.arg("g").toInt();
    cfg.rstDrive = g;
    if (cfg.ledPrint == g) cfg.ledPrint = -1;
    saveConfig();
    logf("screen reset driver set to GPIO %d", g);
    page("Saved", "<h1>Reset pin saved</h1><p>Restarting, then the screen asks for the buttons.</p>");
    pendingReboot = true;
  });
  web.on("/reprint", HTTP_GET, []() { if (!authed()) return; pendingReprint = web.arg("i").toInt(); back(); });
  web.on("/update", HTTP_POST, updateDone, updateUpload);
  web.on("/generate_204", HTTP_GET, captive);
  web.on("/hotspot-detect.html", HTTP_GET, captive);
  web.onNotFound(captive);
  web.begin();
}
