# PFD firmware for Eatabit printers (2.0)

ESP32-WROOM-32D + EP-300 head, Eatabit board 112-P01 Rev A. Speaks Epson
Server Direct Print to pfd-order-monitor with a normal print_devices key; to
the queue, the CRM Devices console and monitoring it is just another printer.

Files
- dist/pfd-eatabit-2.0.0-update.bin   upload from the printer's own web page
- dist/pfd-eatabit-1.0.0-full.bin     first flash over USB-serial (offset 0x0), then update over WiFi
- dist/server-eatabit-support.patch   order-monitor change: text-only large tickets for Eatabits + SetReadyTime
- src/epos.h      ePOS-Print XML -> ESC/POS translator (host-tested: test/)
- src/config.h    settings and the Rev A board defaults
- src/printer.h   UART2, sinks, ticket summary
- src/orders.h    today's orders on flash (LittleFS), reprint
- src/leds.h      ring + PRINT lamp behaviour
- src/tft.h       ST7735 screen
- src/ui.h        buttons, screens, reset-pin and button wizards
- src/net.h       polling, results, prep time
- src/web.h       settings page, setup network, OTA
- src/main.cpp    boot + loop

Board wiring (Rev A, traced 2026-11-01)
- printer TX GPIO 22 @ 19200, tear bar (no cutter)
- screen SCK 17, SDA 16, CS 0, A0 2; RESET via R4/Q5, released while the driver pin is LOW (found by the firmware)
- LED ring R 25, G 26, B 12; PRINT lamp 15 (to confirm)
- buttons on P5 (found by the on-screen wizard)

Behaviour
- tickets print as they arrive; stored on the box for the day
- screen: ONLINE/PROBLEM, orders today, last order; NEW ORDER screen for flashSec
- UP/DOWN: today's orders; PRINT: reprint; MENU on an order: prep time (sent to PFD as SetReadyTime)
- ring: flashes the chosen colour on a new order for flashSec, solid red on a problem, otherwise off
