# Preview of the order box screens, laid out like ui.h (480x800 portrait, 10px glow edge).
from PIL import Image, ImageDraw, ImageFont
B='/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'; R='/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'
F=lambda p,s: ImageFont.truetype(p,s)
SW,SH,EDGE,M=480,800,10,22
BG=(8,12,8); CARD=(24,28,24); BTN=(40,40,40); DIM=(64,64,64); GREY=(132,132,132); WHITE=(255,255,255); GREEN=(0,230,110); AMBER=(255,165,0); RED=(240,40,40)
def scr(edge=BG):
    im=Image.new('RGB',(SW,SH),BG); d=ImageDraw.Draw(im); d.rectangle([0,0,SW-1,SH-1],outline=edge,width=EDGE); return im,d
def tc(d,s,y,f,c): w=d.textlength(s,font=f); d.text(((SW-w)/2,y),s,font=f,fill=c,anchor='ls')
def tr(d,s,x,y,f,c): w=d.textlength(s,font=f); d.text((x-w,y),s,font=f,fill=c,anchor='ls')
def header(d,st='Online',sc=GREEN):
    d.rectangle([EDGE,EDGE,SW-EDGE-1,EDGE+92],fill=CARD)
    d.text((M+4,EDGE+56),'PFD',font=F(B,44),fill=WHITE,anchor='ls'); tr(d,'6:42p',SW-M-4,EDGE+56,F(B,32),WHITE)
    d.ellipse([M+4,EDGE+74,M+16,EDGE+86],fill=sc); d.text((M+24,EDGE+87),st,font=F(B,17),fill=sc,anchor='ls')
def btn(d,x,y,w,h,l,bg,fg,f): d.rounded_rectangle([x,y,x+w,y+h],14,fill=bg); tc2(d,l,x,w,y+h/2+12,f,fg)
def tc2(d,s,x,w,y,f,c): tw=d.textlength(s,font=f); d.text((x+(w-tw)/2,y),s,font=f,fill=c,anchor='ls')
# new order
im,d=scr(GREEN); d.rectangle([EDGE,EDGE,SW-EDGE-1,EDGE+120],fill=GREEN); tc(d,'NEW ORDER',EDGE+80,F(B,46),(0,0,0))
d.rounded_rectangle([M,170,SW-M,420],18,fill=CARD); tc(d,'#10482',250,F(B,84),WHITE); tc(d,'Sarah M.',320,F(B,34),WHITE); tc(d,'Delivery   $38.47',370,F(R,32),GREY); tc(d,'Printed 6:42p',406,F(R,22),GREY)
tc(d,'The ticket is printing.',520,F(R,22),GREY); btn(d,M,SH-200,SW-2*M,150,'GOT IT',GREEN,(0,0,0),F(B,46)); im.save('1-new-order.png')
# prep
im,d=scr(); tc(d,'Ready in how long?',110,F(B,34),WHITE); tc(d,'#10482  Sarah M.',160,F(R,32),GREY)
bw=(SW-2*M-20)//2
for k,m in enumerate([10,15,20,25,30,45]):
    x=M+(k%2)*(bw+20); y=200+(k//2)*128; dflt=m==15; btn(d,x,y,bw,110,f'{m} min',GREEN if dflt else BTN,(0,0,0) if dflt else WHITE,F(B,34))
btn(d,M,SH-150,SW-2*M,100,'Skip',DIM,WHITE,F(B,34)); im.save('2-prep-time.png')
# home
im,d=scr(); header(d); d.text((M+4,160),'Today',font=F(B,34),fill=WHITE,anchor='ls'); tr(d,'14 orders',SW-M-4,160,F(R,32),GREY)
rows=[('10482','Delivery  Sarah M.','6:42p','$38.47'),('10481','Pickup  Jason T.','6:31p','$22.10'),('10480','Delivery  Lisa W.','6:18p','$51.85'),('10479','Delivery  Mark R.','6:02p','$19.99'),('10478','Pickup  Amanda K.','5:55p','$27.40'),('10477','Delivery  Chris P.','5:41p','$44.12')]
y=182
for n,t,c,tot in rows:
    d.rounded_rectangle([M,y,SW-M,y+88],12,fill=CARD); d.text((M+16,y+38),'#'+n,font=F(B,32),fill=WHITE,anchor='ls'); tr(d,c,SW-M-16,y+38,F(R,30),GREY)
    d.text((M+16,y+74),t,font=F(R,22),fill=GREY,anchor='ls'); tr(d,tot,SW-M-16,y+74,F(B,22),WHITE); y+=98
im.save('3-home.png')
# pair
im,d=scr(); header(d,'Not paired yet',AMBER); tc(d,'Pair this printer',220,F(B,44),WHITE)
d.rounded_rectangle([M,270,SW-M,440],18,fill=CARD); tc(d,'482 913',395,F(B,92),GREEN)
tc(d,'In the CRM:',510,F(R,32),GREY); tc(d,'Equipment, Add printer',555,F(B,32),WHITE); tc(d,'and type this code.',600,F(R,32),GREY); im.save('4-pair.png')
# setup
im,d=scr(); header(d,'Connecting to WiFi',AMBER); tc(d,'Connect to WiFi',230,F(B,44),WHITE); tc(d,'On your phone, join this WiFi:',300,F(R,22),GREY)
d.rounded_rectangle([M,330,SW-M,430],16,fill=CARD); tc(d,'PFD-Box-6F54',395,F(B,44),GREEN)
tc(d,'A page opens. Pick the store',490,F(R,32),WHITE); tc(d,'WiFi, type the password, Save.',530,F(R,32),WHITE); tc(d,'No page? Go to 192.168.4.1',620,F(R,22),GREY); im.save('5-wifi-setup.png')
# sheet
ims=[Image.open(f) for f in ['5-wifi-setup.png','4-pair.png','3-home.png','1-new-order.png','2-prep-time.png']]
gap=30; sheet=Image.new('RGB',(len(ims)*SW+(len(ims)+1)*gap,SH+2*gap+50),(236,234,228)); sd=ImageDraw.Draw(sheet)
labels=['1. WiFi setup','2. Pair code','3. Today\'s orders','4. New order','5. Prep time']
for i,(m,l) in enumerate(zip(ims,labels)):
    x=gap+i*(SW+gap); sheet.paste(m,(x,gap)); sd.text((x+SW/2,SH+gap+36),l,font=F(B,26),fill=(30,30,30),anchor='ms')
sheet.save('orderbox-screens.png'); print(sheet.size)
