// Waveshare ESP32-S3-Touch-LCD-7: 800x480 RGB panel, GT911 touch on I2C,
// CH422G I/O expander for backlight and the reset lines.
// Pins from the Waveshare wiki. Panel timing from Waveshare's own demo and
// still to be confirmed on a real board (see PANEL_* below).
#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <Arduino_GFX_Library.h>
#include "config.h"

static const int I2C_SDA = 8, I2C_SCL = 9, TP_INT = 4;
static const int NATIVE_W = 800, NATIVE_H = 480;

// ---- CH422G: write 0x01 to 0x24 (outputs on), then the output byte to 0x38.
// EXIO1 touch reset, EXIO2 backlight, EXIO3 LCD reset, EXIO4 SD CS, EXIO5 USB(0)/CAN(1).
static const int EX_TP_RST = 1, EX_BL = 2, EX_LCD_RST = 3, EX_SD_CS = 4;
inline uint8_t exio = 0;
inline bool exioOk = false;
inline void exioWrite() { Wire.beginTransmission(0x38); Wire.write(exio); exioOk = Wire.endTransmission() == 0; }
inline void exioSet(int bit, bool on) { if (on) exio |= (1 << bit); else exio &= ~(1 << bit); exioWrite(); }
inline void exioBegin() {
  Wire.beginTransmission(0x24); Wire.write(0x01); Wire.endTransmission();
  exio = (1 << EX_TP_RST) | (1 << EX_LCD_RST) | (1 << EX_SD_CS);  // backlight off until the first frame is drawn
  exioWrite();
}
inline void backlight(bool on) { exioSet(EX_BL, on); }

// ---- display
// Timing: Waveshare demo values for this panel. If the picture rolls or is
// shifted, these are the numbers to adjust.
static const uint16_t PANEL_HFP = 8, PANEL_HPW = 4, PANEL_HBP = 8, PANEL_VFP = 8, PANEL_VPW = 4, PANEL_VBP = 8;
static const int32_t PANEL_PCLK = 16000000;
inline Arduino_ESP32RGBPanel* rgbpanel = nullptr;
inline Arduino_RGB_Display* gfx = nullptr;
inline bool screenReady = false;

inline void screenBegin() {
  exioSet(EX_LCD_RST, false); delay(10); exioSet(EX_LCD_RST, true); delay(20);
  rgbpanel = new Arduino_ESP32RGBPanel(
      5 /*DE*/, 3 /*VSYNC*/, 46 /*HSYNC*/, 7 /*PCLK*/,
      1, 2, 42, 41, 40,          // R3..R7
      39, 0, 45, 48, 47, 21,     // G2..G7
      14, 38, 18, 17, 10,        // B3..B7
      0, PANEL_HFP, PANEL_HPW, PANEL_HBP,
      0, PANEL_VFP, PANEL_VPW, PANEL_VBP,
      1 /*pclk active neg*/, PANEL_PCLK);
  gfx = new Arduino_RGB_Display(NATIVE_W, NATIVE_H, rgbpanel, cfg.rotation == 3 ? 3 : 1, true);
  screenReady = gfx->begin();
  if (screenReady) { gfx->fillScreen(0x0000); backlight(true); }
}
inline void screenApplySettings() { if (screenReady) gfx->setRotation(cfg.rotation == 3 ? 3 : 1); }

// ---- touch (GT911)
inline bool touchReady = false;
inline uint8_t gtAddr = 0x5D;
inline bool gtRead(uint16_t reg, uint8_t* buf, int n) {
  Wire.beginTransmission(gtAddr); Wire.write(reg >> 8); Wire.write(reg & 0xFF);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)gtAddr, n) != n) return false;
  for (int i = 0; i < n; i++) buf[i] = Wire.read();
  return true;
}
inline void gtWrite8(uint16_t reg, uint8_t v) {
  Wire.beginTransmission(gtAddr); Wire.write(reg >> 8); Wire.write(reg & 0xFF); Wire.write(v); Wire.endTransmission();
}
inline void touchBegin() {
  // INT held low through reset selects address 0x5D.
  pinMode(TP_INT, OUTPUT); digitalWrite(TP_INT, LOW);
  exioSet(EX_TP_RST, false); delay(10); exioSet(EX_TP_RST, true); delay(60);
  pinMode(TP_INT, INPUT); delay(50);
  for (uint8_t a : {(uint8_t)0x5D, (uint8_t)0x14}) {
    Wire.beginTransmission(a);
    if (Wire.endTransmission() == 0) { gtAddr = a; touchReady = true; break; }
  }
}
// Native panel coordinates to the rotated (portrait) screen.
inline void mapTouch(int nx, int ny, int& x, int& y) {
  if (cfg.rotation == 3) { x = NATIVE_H - 1 - ny; y = nx; }
  else { x = ny; y = NATIVE_W - 1 - nx; }
}
// true while a finger is down, with its position on the screen
inline bool touchGet(int& x, int& y) {
  if (!touchReady) return false;
  uint8_t st;
  if (!gtRead(0x814E, &st, 1) || !(st & 0x80)) return false;
  bool got = false;
  if ((st & 0x0F) > 0) {
    uint8_t p[4];
    if (gtRead(0x8150, p, 4)) { mapTouch(p[0] | (p[1] << 8), p[2] | (p[3] << 8), x, y); got = true; }
  }
  gtWrite8(0x814E, 0);
  return got;
}
