// Remote firmware updates. The box asks PFD whether there is newer firmware
// for it, downloads it straight into the spare app partition, checks it and
// restarts. The running firmware is untouched until the new one is complete
// and verified, so a bad download changes nothing.
//
//   box -> PFD  POST <base>/firmware  Device=<id>&Version=<x.y.z>&Key=<last 4 of key>
//   PFD -> box  update=none
//            or update=2.9.1\nurl=https://...bin\nsize=<bytes>\nmd5=<hex>
#pragma once
#include <Arduino.h>
#include <Update.h>
#include <HTTPClient.h>
#include "net.h"

inline unsigned long nextOtaAt = 90000;       // first check 1.5 min after boot
inline String otaStatus = "not checked yet";
inline String otaFailedVersion;                // don't retry a bad build every 15 min
inline unsigned long otaFailedAt = 0;
inline bool otaCheckNow = false;
static const unsigned long OTA_EVERY_MS = 15UL * 60 * 1000;

inline String firmwareUrl() {
  String u = cfg.url;
  if (u.endsWith("/epson")) return u.substring(0, u.length() - 6) + "/firmware";
  int slash = u.lastIndexOf('/');
  return slash > 8 ? u.substring(0, slash) + "/firmware" : u;
}

// 2.10.0 > 2.9.3; anything unparseable counts as 0.
inline long versionRank(const String& v) {
  long parts[3] = {0, 0, 0}; int i = 0; long cur = 0; bool any = false;
  for (size_t k = 0; k <= v.length() && i < 3; k++) {
    char c = k < v.length() ? v[k] : '.';
    if (isdigit((unsigned char)c)) { cur = cur * 10 + (c - '0'); any = true; }
    else if (c == '.') { parts[i++] = cur; cur = 0; }
    else break;
  }
  if (!any) return 0;
  return parts[0] * 1000000L + parts[1] * 1000L + parts[2];
}

inline bool otaInstall(const String& version, const String& url, size_t size, const String& md5) {
  logf("updating to %s from %s", version.c_str(), url.c_str());
  bigMessage("UPDATING", "to " + version + " - do not unplug", C_NAVY);
  tls.stop();  // the poll connection may still be open; start clean
  HTTPClient http;
  http.setTimeout(30000);
  http.setUserAgent(USER_AGENT);
  bool ok = false;
  String why;
  if (!http.begin(tls, url)) why = "bad url";
  else {
    int code = http.GET();
    int len = http.getSize();
    if (code != 200) why = "download http " + String(code);
    else if (len <= 0 || (size && (size_t)len != size)) why = "size " + String(len);
    else if (!Update.begin(len, U_FLASH)) why = "no room (" + String(Update.errorString()) + ")";
    else {
      if (md5.length() == 32) Update.setMD5(md5.c_str());
      size_t wrote = Update.writeStream(*http.getStreamPtr());
      if (wrote != (size_t)len) { why = "short download " + String((unsigned)wrote) + "/" + String(len); Update.abort(); }
      else if (!Update.end(true)) why = String("check failed: ") + Update.errorString();
      else ok = true;
    }
  }
  http.end();
  tls.stop();
  if (ok) {
    logf("update to %s installed, restarting", version.c_str());
    otaStatus = "installed " + version + ", restarting";
    bigMessage("UPDATED", version + " - restarting", C_GREEN);
    delay(1500);
    ESP.restart();
  }
  logf("update to %s failed: %s", version.c_str(), why.c_str());
  otaStatus = "update to " + version + " failed: " + why;
  otaFailedVersion = version; otaFailedAt = millis();
  uiDirty = true;
  return false;
}

inline void otaTick() {
  if (!WiFi.isConnected()) return;
  if (!otaCheckNow && (long)(millis() - nextOtaAt) < 0) return;
  bool manual = otaCheckNow;
  otaCheckNow = false;
  nextOtaAt = millis() + OTA_EVERY_MS;

  String keyTail = cfg.key.length() >= 4 ? cfg.key.substring(cfg.key.length() - 4) : "";
  int c; String reply;
  bool got = postTo(firmwareUrl(), "Device=" + urlEncode(deviceId) + "&Product=" PRODUCT "&Version=" FW_NUM "&Key=" + urlEncode(keyTail), nullptr, c, &reply);
  tls.stop();
  if (!got) { otaStatus = "check failed (http " + String(c) + ")"; return; }
  String v = field(reply, "update");
  if (!v.length() || v == "none") { otaStatus = "up to date (checked " + String(millis() / 60000) + " min after boot)"; return; }
  if (versionRank(v) <= versionRank(FW_NUM) && field(reply, "force") != "1") { otaStatus = "up to date"; return; }
  if (!manual && v == otaFailedVersion && millis() - otaFailedAt < 6UL * 3600 * 1000) { otaStatus = "skipping " + v + " (failed earlier)"; return; }
  String url = field(reply, "url");
  // Never install another product's build (an Eatabit image would not boot on this board).
  if (url.indexOf("/pfd-" PRODUCT "-") < 0) { otaStatus = "ignored an offer for another product"; logf("firmware offer %s is not for " PRODUCT ", ignored", url.c_str()); return; }
  otaInstall(v, url, (size_t)field(reply, "size").toInt(), field(reply, "md5"));
}
