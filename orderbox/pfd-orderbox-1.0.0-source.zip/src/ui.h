// The order box touchscreen: portrait 480 x 800.
//   setup   - no WiFi yet: tells you which network to join on your phone
//   pair    - on WiFi, not paired: the six-digit code for CRM Equipment
//   home    - today's orders; tap one to reprint it or send a prep time
//   new     - a new order just printed: edge glows, buzzer beeps until GOT IT
//   prep    - pick the prep time, sent to PFD like the tablet's Accept
#pragma once
#include <Arduino.h>
#include <WiFi.h>
#include "config.h"
#include "board.h"
#include "orders.h"
#include "leds.h"
#include "printer.h"
#include "fonts/FreeSansBold24pt7b.h"
#include "fonts/FreeSansBold18pt7b.h"
#include "fonts/FreeSansBold12pt7b.h"
#include "fonts/FreeSansBold9pt7b.h"
#include "fonts/FreeSans12pt7b.h"
#include "fonts/FreeSans18pt7b.h"

static const uint16_t C_BLACK = 0x0000, C_WHITE = 0xFFFF, C_GREEN = 0x07E0, C_RED = 0xF800,
                      C_AMBER = 0xFD20, C_BLUE = 0x001F, C_GREY = 0x8410, C_DIM = 0x4208, C_NAVY = 0x0010,
                      C_BG = 0x0861, C_CARD = 0x18E3, C_LINE = 0x3186, C_BTN = 0x2945;
static const int SW = 480, SH = 800, EDGE = 10, M = 22;  // screen, glow edge, margin

// ---- state other modules use (names shared with the Eatabit firmware)
inline bool apOn = false;
inline String apName;
inline unsigned long apKeepUntil = 0;
inline void startAP();
inline String pairCode;
inline String errorText;
inline bool uiDirty = true;
bool pollingHealthy();
bool sendPrepTime(const String& orderNumber, int minutes);
inline String keyHint() {
  if (cfg.key.length() < 4) return cfg.key.isEmpty() ? "NOT SET" : "set";
  return "..." + cfg.key.substring(cfg.key.length() - 4);
}
inline void setError(const String& e) { if (e != errorText) { errorText = e; uiDirty = true; } }

enum Screen { S_HOME, S_NEW, S_PREP, S_ORDER, S_NOTE };
inline Screen uiScreen = S_HOME;
inline int uiSel = -1;                 // order shown on S_ORDER / S_PREP
inline bool newPending = false;        // a new order nobody has tapped GOT IT on
inline int newCount = 0;               // how many arrived since the last GOT IT
inline unsigned long nextBeepAt = 0;
inline unsigned long noteUntil = 0;
inline String noteBig, noteSmall;
inline uint16_t noteColor = C_NAVY;
inline int uiMinute = -1;

// ---- drawing helpers
struct Btn { int x, y, w, h, id; };
inline Btn btns[16];
inline int btnCount = 0;
inline void clearBtns() { btnCount = 0; }

inline int textW(const String& s, const GFXfont* f, int size = 1) {
  gfx->setFont(f); gfx->setTextSize(size);
  int16_t x1, y1; uint16_t w, h;
  gfx->getTextBounds(s.c_str(), 0, 0, &x1, &y1, &w, &h);
  return w;
}
inline void text(const String& s, int x, int baseline, const GFXfont* f, uint16_t col, int size = 1) {
  gfx->setFont(f); gfx->setTextSize(size); gfx->setTextColor(col);
  gfx->setCursor(x, baseline); gfx->print(s);
}
inline void textC(const String& s, int baseline, const GFXfont* f, uint16_t col, int size = 1) {
  text(s, (SW - textW(s, f, size)) / 2, baseline, f, col, size);
}
inline void textR(const String& s, int right, int baseline, const GFXfont* f, uint16_t col) {
  text(s, right - textW(s, f), baseline, f, col);
}
// Shorten to fit a width, with an ellipsis.
inline String fit(String s, int w, const GFXfont* f) {
  if (textW(s, f) <= w) return s;
  while (s.length() > 1 && textW(s + "...", f) > w) s.remove(s.length() - 1);
  return s + "...";
}
inline void button(int x, int y, int w, int h, const String& label, uint16_t bg, uint16_t fg, int id, const GFXfont* f = &FreeSansBold18pt7b) {
  gfx->fillRoundRect(x, y, w, h, 14, bg);
  int tw = textW(label, f);
  text(label, x + (w - tw) / 2, y + h / 2 + 12, f, fg);
  if (btnCount < 16) btns[btnCount++] = {x, y, w, h, id};
}

// ---- glowing edge: pulses in the glow colour for a new order, steady red on a problem
inline int glowShown = -1;
inline void drawEdge(uint16_t c) {
  gfx->fillRect(0, 0, SW, EDGE, c); gfx->fillRect(0, SH - EDGE, SW, EDGE, c);
  gfx->fillRect(0, 0, EDGE, SH, c); gfx->fillRect(SW - EDGE, 0, EDGE, SH, c);
}
inline void glowTick(bool force = false) {
  int key; uint16_t c;
  if (newPending) {
    int pct = 30 + (int)(70 * (0.5 + 0.5 * sin(millis() / 260.0)));
    key = 1000 + pct / 5; c = rgb565(cfg.ledColor, pct);
  } else if (errorText.length()) { key = 1; c = C_RED; }
  else { key = 0; c = C_BG; }
  if (key == glowShown && !force) return;
  glowShown = key;
  drawEdge(c);
}

// ---- full-screen message (also used while updating and pairing)
inline void bigMessage(const String& big, const String& small, uint16_t color, uint16_t textCol = C_WHITE) {
  if (!screenReady) return;
  gfx->fillScreen(color);
  textC(big, SH / 2 - 10, &FreeSansBold24pt7b, textCol);
  textC(small, SH / 2 + 50, &FreeSans18pt7b, textCol);
  glowShown = -1;
}
inline void uiNote(const String& big, const String& small, uint16_t color, unsigned long ms = 2000) {
  noteBig = big; noteSmall = small; noteColor = color; noteUntil = millis() + ms;
  uiScreen = S_NOTE; uiDirty = true;
}

// ---- header shared by the home screens
inline void drawHeader() {
  gfx->fillRect(EDGE, EDGE, SW - 2 * EDGE, 92, C_CARD);
  text("PFD", M + 4, EDGE + 56, &FreeSansBold24pt7b, C_WHITE);
  String clock = clockText(nowEpoch());
  if (clock.length()) textR(clock, SW - M - 4, EDGE + 56, &FreeSansBold18pt7b, C_WHITE);
  String st; uint16_t sc;
  if (errorText.length()) { st = errorText; sc = C_RED; }
  else if (!WiFi.isConnected()) { st = "Connecting to WiFi"; sc = C_AMBER; }
  else if (cfg.key.isEmpty()) { st = "Not paired yet"; sc = C_AMBER; }
  else if (pollingHealthy()) { st = "Online"; sc = C_GREEN; }
  else { st = "Reaching PFD"; sc = C_AMBER; }
  gfx->fillCircle(M + 10, EDGE + 80, 6, sc);
  text(st, M + 24, EDGE + 87, &FreeSansBold9pt7b, sc);
}

inline void drawSetup() {
  gfx->fillScreen(C_BG);
  drawHeader();
  textC("Connect to WiFi", 230, &FreeSansBold24pt7b, C_WHITE);
  textC("On your phone, join this WiFi:", 300, &FreeSans12pt7b, C_GREY);
  gfx->fillRoundRect(M, 330, SW - 2 * M, 100, 16, C_CARD);
  textC(apName, 395, &FreeSansBold24pt7b, C_GREEN);
  textC("A page opens. Pick the store", 490, &FreeSans18pt7b, C_WHITE);
  textC("WiFi, type the password, Save.", 530, &FreeSans18pt7b, C_WHITE);
  textC("No page? Go to 192.168.4.1", 620, &FreeSans12pt7b, C_GREY);
}

inline void drawConnecting() {
  gfx->fillScreen(C_BG);
  drawHeader();
  textC("Joining WiFi", 360, &FreeSansBold24pt7b, C_WHITE);
  textC(fit(cfg.ssid, SW - 2 * M, &FreeSans18pt7b), 420, &FreeSans18pt7b, C_GREY);
}

inline void drawPair() {
  gfx->fillScreen(C_BG);
  drawHeader();
  textC("Pair this printer", 220, &FreeSansBold24pt7b, C_WHITE);
  if (pairCode.length() == 6) {
    gfx->fillRoundRect(M, 270, SW - 2 * M, 170, 18, C_CARD);
    textC(pairCode.substring(0, 3) + " " + pairCode.substring(3), 395, &FreeSansBold24pt7b, C_GREEN, 2);
    textC("In the CRM:", 510, &FreeSans18pt7b, C_GREY);
    textC("Equipment, Add printer", 555, &FreeSansBold18pt7b, C_WHITE);
    textC("and type this code.", 600, &FreeSans18pt7b, C_GREY);
  } else {
    textC("Getting a code from PFD...", 380, &FreeSans18pt7b, C_GREY);
  }
}

inline void drawHome() {
  gfx->fillScreen(C_BG);
  drawHeader();
  clearBtns();
  int n = ordersToday();
  text("Today", M + 4, 160, &FreeSansBold18pt7b, C_WHITE);
  textR(String(n) + (n == 1 ? " order" : " orders"), SW - M - 4, 160, &FreeSans18pt7b, C_GREY);
  if (!orderCount) { textC("Orders show up here", 420, &FreeSans18pt7b, C_GREY); textC("as they print.", 460, &FreeSans18pt7b, C_GREY); return; }
  int y = 182, rowH = 98, shown = 0;
  for (int i = orderCount - 1; i >= 0 && shown < 6; i--, shown++) {
    const OrderEntry& o = orders[i];
    gfx->fillRoundRect(M, y, SW - 2 * M, rowH - 10, 12, C_CARD);
    text("#" + o.number, M + 16, y + 38, &FreeSansBold18pt7b, C_WHITE);
    textR(clockText(o.at), SW - M - 16, y + 38, &FreeSans18pt7b, C_GREY);
    text(fit(o.type + (o.name.length() ? "  " + o.name : ""), SW - 2 * M - 140, &FreeSans12pt7b), M + 16, y + 74, &FreeSans12pt7b, C_GREY);
    textR(o.total, SW - M - 16, y + 74, &FreeSansBold12pt7b, C_WHITE);
    btns[btnCount++] = {M, y, SW - 2 * M, rowH - 10, 100 + i};
    y += rowH;
  }
}

inline void drawOrderCard(const OrderEntry& o, int top) {
  gfx->fillRoundRect(M, top, SW - 2 * M, 250, 18, C_CARD);
  textC("#" + o.number, top + 80, &FreeSansBold24pt7b, C_WHITE, o.number.length() <= 6 ? 2 : 1);
  textC(fit(o.name.length() ? o.name : String("No name"), SW - 2 * M - 30, &FreeSansBold18pt7b), top + 150, &FreeSansBold18pt7b, C_WHITE);
  textC(o.type + (o.total.length() ? "   " + o.total : ""), top + 200, &FreeSans18pt7b, C_GREY);
  String t = clockText(o.at);
  if (t.length()) textC("Printed " + t, top + 236, &FreeSans12pt7b, C_GREY);
}

inline void drawNew() {
  gfx->fillScreen(C_BG);
  clearBtns();
  gfx->fillRect(EDGE, EDGE, SW - 2 * EDGE, 120, rgb565(cfg.ledColor));
  textC("NEW ORDER", EDGE + 80, &FreeSansBold24pt7b, C_BLACK);
  int i = orderCount - 1;
  if (i >= 0) drawOrderCard(orders[i], 170);
  if (newCount > 1) textC("+" + String(newCount - 1) + " more since", 470, &FreeSansBold12pt7b, C_AMBER);
  textC("The ticket is printing.", 520, &FreeSans12pt7b, C_GREY);
  button(M, SH - 200, SW - 2 * M, 150, "GOT IT", C_GREEN, C_BLACK, 1, &FreeSansBold24pt7b);
}

static const int PREP_STEPS[] = {10, 15, 20, 25, 30, 45};
inline void drawPrep() {
  gfx->fillScreen(C_BG);
  clearBtns();
  const OrderEntry* o = (uiSel >= 0 && uiSel < orderCount) ? &orders[uiSel] : nullptr;
  textC("Ready in how long?", 110, &FreeSansBold18pt7b, C_WHITE);
  if (o) textC("#" + o->number + (o->name.length() ? "  " + o->name : ""), 160, &FreeSans18pt7b, C_GREY);
  int bw = (SW - 2 * M - 20) / 2, bh = 110, y = 200;
  for (int k = 0; k < 6; k++) {
    int x = M + (k % 2) * (bw + 20);
    bool def = PREP_STEPS[k] == cfg.prepDefault;
    button(x, y + (k / 2) * (bh + 18), bw, bh, String(PREP_STEPS[k]) + " min", def ? C_GREEN : C_BTN, def ? C_BLACK : C_WHITE, 200 + PREP_STEPS[k]);
  }
  button(M, SH - 150, SW - 2 * M, 100, "Skip", C_DIM, C_WHITE, 2);
}

inline void drawOrder() {
  gfx->fillScreen(C_BG);
  clearBtns();
  if (uiSel < 0 || uiSel >= orderCount) { uiScreen = S_HOME; drawHome(); return; }
  drawOrderCard(orders[uiSel], 60);
  button(M, 360, SW - 2 * M, 120, "Reprint", C_BTN, C_WHITE, 3);
  button(M, 500, SW - 2 * M, 120, "Send prep time", C_BTN, C_WHITE, 4);
  button(M, SH - 140, SW - 2 * M, 100, "Back", C_DIM, C_WHITE, 2);
}

inline void uiDraw() {
  if (!screenReady) return;
  clearBtns();
  bool setup = apOn && !WiFi.isConnected();
  if (uiScreen == S_NOTE) bigMessage(noteBig, noteSmall, noteColor, noteColor == C_GREEN || noteColor == C_AMBER ? C_BLACK : C_WHITE);
  else if (setup) drawSetup();
  else if (!WiFi.isConnected() && !cfg.ssid.isEmpty() && cfg.key.isEmpty()) drawConnecting();
  else if (cfg.key.isEmpty()) drawPair();
  else if (uiScreen == S_NEW) drawNew();
  else if (uiScreen == S_PREP) drawPrep();
  else if (uiScreen == S_ORDER) drawOrder();
  else drawHome();
  glowTick(true);
  uiDirty = false;
}

// Called by net.h right after a ticket printed.
inline void uiNewOrder() {
  newPending = true;
  newCount++;
  uiSel = orderCount - 1;
  uiScreen = S_NEW;
  uiDirty = true;
  beep(250);
  nextBeepAt = cfg.flashSec > 0 ? millis() + (unsigned long)cfg.flashSec * 1000 : 0;
}

inline void uiTap(int id) {
  if (id == 1) {  // GOT IT
    newPending = false; newCount = 0; nextBeepAt = 0;
    uiSel = orderCount - 1; uiScreen = S_PREP;
  } else if (id == 2) {  // Back / Skip
    uiScreen = S_HOME;
  } else if (id == 3) {  // Reprint
    int i = uiSel;
    if (i >= 0 && i < orderCount && ordersReprint(i)) uiNote("REPRINTING", "#" + orders[i].number, C_NAVY);
    return;
  } else if (id == 4) {
    uiScreen = S_PREP;
  } else if (id >= 200 && id < 300) {
    int mins = id - 200;
    if (uiSel >= 0 && uiSel < orderCount) {
      bool ok = sendPrepTime(orders[uiSel].number, mins);
      uiNote(ok ? "SENT" : "NOT SENT", ok ? "Ready in " + String(mins) + " min" : "Check the WiFi and try again", ok ? C_GREEN : C_RED);
      return;
    }
    uiScreen = S_HOME;
  } else if (id >= 100 && id < 200) {
    uiSel = id - 100; uiScreen = S_ORDER;
  }
  uiDirty = true;
}

inline void uiTick() {
  if (!screenReady) return;
  // touch: act on the press, then ignore until the finger lifts
  static bool down = false;
  static unsigned long lastPoll = 0;
  if (millis() - lastPoll >= 20) {
    lastPoll = millis();
    int x, y;
    bool now = touchGet(x, y);
    if (now && !down) {
      for (int i = 0; i < btnCount; i++) {
        const Btn& b = btns[i];
        if (x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h) { beep(25); uiTap(b.id); break; }
      }
    }
    down = now;
  }
  if (uiScreen == S_NOTE && (long)(millis() - noteUntil) >= 0) { uiScreen = newPending ? S_NEW : S_HOME; uiDirty = true; }
  if (newPending && nextBeepAt && (long)(millis() - nextBeepAt) >= 0) { beep(250); nextBeepAt = millis() + (unsigned long)cfg.flashSec * 1000; }
  // the clock in the header, once a minute
  time_t t = nowEpoch();
  if (t) { struct tm tm; localtime_r(&t, &tm); if (tm.tm_min != uiMinute) { uiMinute = tm.tm_min; if (uiScreen == S_HOME) uiDirty = true; } }
  // the pair code and WiFi state change underneath the screens
  static String shownCode; static bool shownWifi = false, shownAp = false;
  if (pairCode != shownCode || WiFi.isConnected() != shownWifi || apOn != shownAp) {
    shownCode = pairCode; shownWifi = WiFi.isConnected(); shownAp = apOn; uiDirty = true;
  }
  if (uiDirty) uiDraw();
  glowTick();
  beepTick();
}
