// The order box's own channel to PFD (POST /api/print/box, see the bridge's
// lib/orderbox.ts): a Sync every cfg.syncSec seconds for the order list,
// drivers, timers, busy / pause, today's numbers and dispatch's replies, and
// one call per tap. Also the printer's paper sensor, remote commands from the
// CRM (reboot, screenshot, reprint) and the backup internet.
#pragma once
#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include "config.h"
#include "logic.h"
#include "boxstate.h"
#include "printer.h"
#include "orders.h"
#include "sound.h"
#include "board.h"
#include "ui.h"
#include "net.h"

inline unsigned long nextSyncAt = 0;
inline unsigned long nextHealthAt = 30000;
inline String healthSent;
inline unsigned long healthSentAt = 0;

inline String boxUrl() {
  String u = cfg.url;
  if (u.endsWith("/epson")) return u.substring(0, u.length() - 6) + "/box";
  int slash = u.lastIndexOf('/');
  return slash > 8 ? u.substring(0, slash) + "/box" : u;
}

long boxEpoch() { time_t t = time(nullptr); return t > 1600000000 ? (long)t : (long)t + boxClockSkew; }
void boxSyncSoon() { nextSyncAt = millis() + 300; }

/** One call. Returns the reply body (key=value lines) or "" when the network failed. */
inline String boxPost(const String& fields, int timeoutMs = 15000) {
  if (cfg.key.isEmpty() || !WiFi.isConnected()) { boxError = WiFi.isConnected() ? "Not paired" : "No internet"; return ""; }
  HTTPClient http;
  http.setTimeout(timeoutMs);
  http.setUserAgent(USER_AGENT);
  if (!http.begin(tls, boxUrl())) { boxError = "No connection"; return ""; }
  http.addHeader("Content-Type", "application/x-www-form-urlencoded");
  int code = http.POST("ID=" + urlEncode(cfg.key) + "&" + fields);
  String body = code > 0 ? http.getString() : "";
  http.end();
  if (code <= 0) { boxError = "Can't reach PFD"; return ""; }
  return body;
}

/** A tap's call: true when the server said ok=1; otherwise boxError holds its words. */
inline bool boxDo(const String& fields) {
  String r = boxPost(fields);
  if (!r.length()) return false;
  std::string rs(r.c_str());
  if (box::field(rs, "ok") == "1") { boxError = ""; boxSyncSoon(); return true; }
  std::string e = box::field(rs, "error");
  boxError = e.empty() ? "Didn't go through" : e.c_str();
  return false;
}

inline String enc(const std::string& s) { return urlEncode(String(s.c_str())); }

bool boxAck(const std::string& id, int minutes) { return boxDo("Action=Ack&Order=" + enc(id) + (minutes > 0 ? "&Minutes=" + String(minutes) : String())); }
bool boxReady(const std::string& id) { return boxDo("Action=Ready&Order=" + enc(id)); }
bool boxLate(const std::string& id, int add) { return boxDo("Action=Late&Order=" + enc(id) + "&Add=" + String(add)); }
bool boxPrep(const std::string& id, int minutes) { return boxDo("Action=Prep&Order=" + enc(id) + "&Minutes=" + String(minutes)); }
bool boxBusy(int add, int forMin) { return boxDo("Action=Busy&Add=" + String(add) + "&For=" + String(forMin)); }
bool boxBusyEnd() { return boxDo("Action=Busy&End=1"); }
bool boxPause(const char* choice) { return boxDo(String("Action=Pause&For=") + choice); }
bool boxPauseEnd() { return boxDo("Action=Pause&End=1"); }
bool boxMsg(const char* kind, const std::string& id) { return boxDo(String("Action=Msg&Kind=") + kind + (id.empty() ? String() : "&Order=" + enc(id))); }
bool boxRead() { return boxDo("Action=Read"); }
bool boxItem86(const std::string& ref, bool out) { return boxDo("Action=Item86&Ref=" + enc(ref) + "&Out=" + (out ? "1" : "0")); }
bool boxDeny(const std::string& id, const char* code) { return boxDo("Action=Deny&Order=" + enc(id) + "&Code=" + code); }
bool boxReprintServer(const std::string& id) { return boxDo("Action=Reprint&Order=" + enc(id)); }

bool boxLoadMenu() {
  String r = boxPost("Action=Menu", 20000);
  if (!r.length()) return false;
  std::string rs(r.c_str());
  if (box::field(rs, "ok") != "1") { boxError = box::field(rs, "error").c_str(); return false; }
  boxMenuItems = box::parseMenu(rs);
  return true;
}

// ---------------------------------------------------------------- screenshot

/** Half-size frame, run-length encoded, posted as the body (Action=Shot). */
inline bool boxScreenshot(String& result) {
  if (!screenReady) { result = "no screen"; return false; }
  uint16_t* fb = gfx->getFramebuffer();
  if (!fb) { result = "no framebuffer"; return false; }
  int w, h;
  uint16_t* half = (uint16_t*)ps_malloc(400 * 240 * 2);
  uint8_t* rle = (uint8_t*)ps_malloc(400 * 240 * 3 + 16);
  if (!half || !rle) { free(half); free(rle); result = "no memory"; return false; }
  box::downsample(fb, NATIVE_W, NATIVE_H, cfg.rotation, half, w, h);
  size_t n = 0;
  box::rleEncode(half, (size_t)w * h, [&](const uint8_t* p, size_t k) { memcpy(rle + n, p, k); n += k; });
  free(half);
  HTTPClient http;
  http.setTimeout(20000);
  http.setUserAgent(USER_AGENT);
  bool ok = false;
  String url = boxUrl() + "?ID=" + urlEncode(cfg.key) + "&Action=Shot&W=" + String(w) + "&H=" + String(h);
  if (http.begin(tls, url)) {
    http.addHeader("Content-Type", "application/octet-stream");
    int code = http.POST(rle, n);
    ok = code == 200;
    result = ok ? "sent " + String(n) + " bytes" : "upload failed (" + String(code) + ")";
    http.end();
  } else result = "no connection";
  free(rle);
  logf("screenshot %s", result.c_str());
  return ok;
}

// ---------------------------------------------------------------- remote commands

inline void boxCommand(const std::string& cmd) {
  String result;
  if (cmd == "reboot") {
    boxPost("Action=Done&Cmd=reboot&Result=restarting");
    logf("remote reboot");
    bigMessage("Restarting", "Asked by PFD", C_NAVY);
    delay(800);
    ESP.restart();
  } else if (cmd == "screenshot") {
    boxScreenshot(result);
  } else if (cmd.compare(0, 8, "reprint:") == 0) {
    std::string num = cmd.substr(8);
    int local = -1;
    for (int i = orderCount - 1; i >= 0; i--) if (orders[i].number == num.c_str()) { local = i; break; }
    if (local >= 0 && ordersReprint(local)) result = "reprinted here";
    else {
      const box::Order* o = nullptr;
      for (int i = 0; i < boxNow.orderCount; i++) if (boxNow.orders[i].number == num) o = &boxNow.orders[i];
      result = o && boxReprintServer(o->id) ? "queued from PFD" : "order not found";
    }
  } else result = "unknown command";
  boxPost("Action=Done&Cmd=" + urlEncode(cmd.c_str()) + "&Result=" + urlEncode(result));
}

// ---------------------------------------------------------------- Sync

inline void onSync(const box::Sync& before, const box::Sync& now, bool first);

inline void boxSyncNow() {
  String r = boxPost("Action=Sync");
  if (!r.length()) return;
  box::Sync s = box::parseSync(std::string(r.c_str()));
  if (!s.ok) { if (s.error == "not paired") logf("box: key refused"); return; }
  time_t t = time(nullptr);
  boxClockSkew = s.now - (long)t;
  bool first = !boxHaveSync;
  box::Sync before = boxNow;
  boxNow = s;
  boxHaveSync = true;
  boxSyncAt = millis();
  onSync(before, boxNow, first);
  if (!s.cmd.empty()) boxCommand(s.cmd);
}

/** New orders and driver arrivals: screen, sound and voice. */
inline void onSync(const box::Sync& before, const box::Sync& now, bool first) {
  std::vector<const box::Order*> fresh = box::newArrivals(before, now, first);
  for (const box::Order* o : fresh) say(box::announceOrder(*o));
  if (!fresh.empty()) uiNewOrder();
  if (!first) {
    for (int i = 0; i < now.orderCount; i++) {
      const box::Order& o = now.orders[i];
      const box::Order* was = before.find(o.id);
      if (o.driverStatus == "at_pickup" && (!was || was->driverStatus != "at_pickup")) { say(box::announceDriver(o, now.now)); uiNote("DRIVER HERE", String(o.driver.c_str()) + " for #" + o.number.c_str(), C_GREEN, 3000); }
    }
    bool newReply = now.msgCount && !now.msgs[0].read && (!before.msgCount || before.msgs[0].at != now.msgs[0].at);
    if (newReply) { say("message"); beep(120); }
  }
  uiDirty = true;
}

// ---------------------------------------------------------------- paper sensor

inline int printerQuery(uint8_t n) {
  if (!printerReady || cfg.rx < 0) return -1;
  while (PrinterSerial.available()) PrinterSerial.read();
  const uint8_t q[] = {0x10, 0x04, n};
  PrinterSerial.write(q, 3);
  PrinterSerial.flush();
  unsigned long t = millis();
  while (!PrinterSerial.available() && millis() - t < 300) delay(5);
  return PrinterSerial.available() ? PrinterSerial.read() : -1;
}

inline void healthTick() {
  if ((long)(millis() - nextHealthAt) < 0) return;
  nextHealthAt = millis() + 60000;
  String st = box::printerState(printerQuery(4), printerQuery(2));
  if (st != printerState) {
    if (st == "paper_out") { say("paper_out"); setError("Out of paper"); }
    else if (st == "paper_low") say("paper_low");
    else if (st == "cover_open") setError("Printer cover open");
    if (printerState == "paper_out" || printerState == "cover_open") setError("");
    printerState = st;
    uiDirty = true;
  }
  if (cfg.key.isEmpty() || !WiFi.isConnected()) return;
  String sig = st + "/" + boxLink;
  if (sig != healthSent || millis() - healthSentAt > 10UL * 60 * 1000) {
    if (boxDo("Action=Health&Printer=" + st + "&Link=" + boxLink)) { healthSent = sig; healthSentAt = millis(); }
  }
}

// ---------------------------------------------------------------- backup internet

inline void linkTick() {
  static unsigned long downSince = 0, onLinkSince = 0, lastScan = 0;
  static bool primaryVisible = false;
  if (cfg.ssid.isEmpty()) return;
  bool backup = boxLink == "backup";
  bool up = WiFi.isConnected();
  if (up) downSince = 0; else if (!downSince) downSince = millis();
  if (!onLinkSince) onLinkSince = millis();
  // On backup, look for the store's WiFi every two minutes.
  if (backup && up && millis() - lastScan > 120000) {
    lastScan = millis();
    int n = WiFi.scanNetworks(false, false, false, 300);
    primaryVisible = false;
    for (int i = 0; i < n; i++) if (WiFi.SSID(i) == cfg.ssid) primaryVisible = true;
    WiFi.scanDelete();
  }
  box::LinkAction a = box::linkDecision(backup, up, cfg.ssid2.length() > 0, downSince ? (long)(millis() - downSince) / 1000 : 0, (long)(millis() - onLinkSince) / 1000, primaryVisible);
  if (a == box::STAY) return;
  bool toBackup = a == box::TO_BACKUP;
  logf("internet: switching to %s", toBackup ? "backup" : "store WiFi");
  WiFi.disconnect();
  if (toBackup) WiFi.begin(cfg.ssid2.c_str(), cfg.pass2.c_str());
  else WiFi.begin(cfg.ssid.c_str(), cfg.pass.c_str());
  boxLink = toBackup ? "backup" : "wifi";
  onLinkSince = millis();
  downSince = 0;
  primaryVisible = false;
  healthSent = "";
  uiDirty = true;
}

inline void boxTick() {
  linkTick();
  healthTick();
  if (cfg.key.isEmpty() || !WiFi.isConnected()) return;
  if ((long)(millis() - nextSyncAt) < 0) return;
  nextSyncAt = millis() + (unsigned long)max(5, cfg.syncSec) * 1000;
  boxSyncNow();
}
