// What the screen knows from PFD (the last Sync) and the calls the screen
// makes. Defined in box.h; declared here so ui.h can use them without
// pulling in the network.
#pragma once
#include <Arduino.h>
#include <string>
#include <vector>
#include "logic.h"

inline box::Sync boxNow;            // the last good Sync
inline bool boxHaveSync = false;
inline unsigned long boxSyncAt = 0;  // millis of the last good Sync
inline long boxClockSkew = 0;        // server now - our now, seconds
inline String boxError;              // the server's words from the last failed call
inline String boxLink = "wifi";      // wifi | backup
inline String printerState = "ok";  // what the paper sensor last said
inline std::vector<box::MenuItem> boxMenuItems;

/** Server time, seconds: our clock corrected by the last Sync. */
long boxEpoch();

bool boxAck(const std::string& id, int minutes);
bool boxReady(const std::string& id);
bool boxLate(const std::string& id, int add);
bool boxPrep(const std::string& id, int minutes);
bool boxBusy(int add, int forMin);
bool boxBusyEnd();
bool boxPause(const char* choice);
bool boxPauseEnd();
bool boxMsg(const char* kind, const std::string& id);
bool boxRead();
bool boxLoadMenu();
bool boxItem86(const std::string& ref, bool out);
bool boxDeny(const std::string& id, const char* code);
bool boxReprintServer(const std::string& id);
void boxSyncSoon();
