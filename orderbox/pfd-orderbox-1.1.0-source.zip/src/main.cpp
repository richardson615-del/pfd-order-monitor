// PFD Order Box 1.1: Waveshare ESP32-S3 7" touchscreen + the EP-300 printer from
// the Eatabit boxes. Same PFD side as the Eatabit firmware (pairing code,
// Server Direct Print polling, prep times, self-updates); the screen and
// touch are new. Printer TTL on the UART terminal: GPIO43 TX, GPIO44 RX.
#include <Preferences.h>
#include <Wire.h>
#include <Arduino.h>
#include <WiFi.h>
#include <ESPmDNS.h>
#include <esp_system.h>
#include <esp_mac.h>
#include "config.h"
#include "printer.h"
#include "orders.h"
#include "board.h"
#include "leds.h"
#include "ui.h"
#include "net.h"
#include "box.h"
#include "ota.h"
#include "web.h"

void printTest() {
  if (!printerReady) return;
  const uint8_t init[] = {0x1B, 0x40, 0x1B, 0x61, 0x01, 0x1D, 0x21, 0x11};
  printBytes(init, sizeof init);
  printRaw("PFD ORDER BOX\n");
  const uint8_t norm[] = {0x1D, 0x21, 0x00, 0x1B, 0x61, 0x00};
  printBytes(norm, sizeof norm);
  String host = apName; host.toLowerCase();
  String s;
  s += "Firmware: " FW_VERSION "\n";
  s += "Device key: " + keyHint() + "\n";
  s += "WiFi: " + (WiFi.isConnected() ? cfg.ssid + " (" + String(WiFi.RSSI()) + " dBm)" : String("not connected")) + "\n";
  s += "Settings: http://" + (WiFi.isConnected() ? WiFi.localIP().toString() : WiFi.softAPIP().toString()) + "/\n";
  s += "      or: http://" + host + ".local/\n";
  s += "Printer: pin " + String(cfg.tx) + " @ " + String(cfg.baud) + ", " + (cfg.dots == 576 ? "80mm" : "58mm") + "\n";
  s += "Touch: " + String(touchReady ? "ok" : "NOT FOUND") + "   Screen: " + String(screenReady ? "ok" : "off") + "\n";
  s += "Last poll: " + lastPollResult + "\n";
  s += "Sound: " + String(cfg.speaker ? "speaker" : "buzzer") + " on pin " + String(cfg.buzzPin) + "   Paper: " + printerState + "\n";
  s += "Backup internet: " + (cfg.ssid2.length() ? cfg.ssid2 : String("none")) + "   Now on: " + boxLink + "\n";
  printRaw(s.c_str());
  String x = "<epos-print><text align=\"center\"/><symbol type=\"qrcode_model_2\" level=\"level_m\" width=\"5\">http://";
  x += WiFi.isConnected() ? WiFi.localIP().toString() : WiFi.softAPIP().toString();
  x += "/</symbol><feed line=\"1\"/><text align=\"center\">Scan for printer settings&#10;</text><feed line=\"2\"/><cut type=\"feed\"/></epos-print>";
  printEposXml(x.c_str(), x.length());
}

void printSample() {
  if (!printerReady) return;
  ChunkSink buf;
  EposTranslator tr(buf, eposOptions());
  const size_t n = strlen_P(SAMPLE_TICKET);
  char chunk[256];
  for (size_t i = 0; i < n; i += sizeof chunk) {
    size_t k = min(sizeof chunk, n - i);
    memcpy_P(chunk, SAMPLE_TICKET + i, k);
    tr.feed(chunk, k);
  }
  tr.finish();
  SerialSink out;
  buf.writeTo(out);
  PrinterSerial.flush();
  ordersAdd(buf);
  uiNewOrder();
  logf("printed sample ticket");
}

void setup() {
  loadConfig();
  uint8_t mac[6];
  esp_read_mac(mac, ESP_MAC_WIFI_STA);
  char nm[32];
  snprintf(nm, sizeof nm, "PFD-Box-%02X%02X", mac[4], mac[5]);
  apName = nm;
  char did[40];
  snprintf(did, sizeof did, "pfd-orderbox-%02x%02x%02x%02x%02x%02x", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
  deviceId = did;
  logf("%s booting, reset reason %d%s", FW_VERSION, (int)esp_reset_reason(), esp_reset_reason() == ESP_RST_PANIC ? " (CRASHED)" : "");

  Wire.begin(I2C_SDA, I2C_SCL, 400000);
  exioBegin();
  logf("io expander %s", exioOk ? "ok" : "NOT FOUND");
  touchBegin();
  logf("touch %s (0x%02X)", touchReady ? "ok" : "NOT FOUND", gtAddr);
  screenBegin();
  logf("screen %s", screenReady ? "ok" : "FAILED");
  bigMessage("PFD", "starting up", C_NAVY);
  buzzerBegin();
  printerBegin();
  ordersBegin();

  WiFi.persistent(false);
  WiFi.setAutoReconnect(true);
  WiFi.setHostname(apName.c_str());
  if (cfg.ssid.isEmpty()) startAP();
  else { WiFi.mode(WIFI_STA); WiFi.begin(cfg.ssid.c_str(), cfg.pass.c_str()); }
  netBegin();
  webBegin();
  uiDirty = true;
}

void loop() {
  if (apOn) dns.processNextRequest();
  web.handleClient();

  if (pendingReboot) { delay(500); ESP.restart(); }
  if (pendingTest) { pendingTest = false; printTest(); }
  if (pendingSample) { pendingSample = false; printSample(); }
  if (pendingReprint >= 0) { int i = pendingReprint; pendingReprint = -1; if (ordersReprint(i)) uiNote("REPRINTING", "#" + orders[i].number, C_NAVY); }

  static bool mdnsUp = false;
  if (!mdnsUp && WiFi.isConnected()) {
    String host = apName; host.toLowerCase();
    mdnsUp = MDNS.begin(host.c_str());
    if (mdnsUp) { MDNS.addService("http", "tcp", 80); logf("also at http://%s.local/", host.c_str()); }
  }
  static unsigned long wifiDownSince = 0;
  if (!cfg.ssid.isEmpty()) {
    if (WiFi.isConnected()) { wifiDownSince = 0; if (apOn && millis() > 120000 && (long)(millis() - apKeepUntil) >= 0) stopAP(); }
    else {
      if (!wifiDownSince) wifiDownSince = millis();
      if (millis() - wifiDownSince > 60000) startAP();
      static unsigned long lastRetry = 0;
      if (apOn && WiFi.softAPgetStationNum() == 0 && WiFi.scanComplete() != WIFI_SCAN_RUNNING && millis() - lastRetry > 90000) {
        lastRetry = millis();
        if (boxLink == "backup") WiFi.begin(cfg.ssid2.c_str(), cfg.pass2.c_str());
        else WiFi.begin(cfg.ssid.c_str(), cfg.pass.c_str());
      }
    }
  }

  netTick();
  boxTick();
  otaTick();
  uiTick();
  delay(2);
}
