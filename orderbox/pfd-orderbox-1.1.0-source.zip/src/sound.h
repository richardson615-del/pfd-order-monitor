// Sound on the Sensor AD header (cfg.buzzPin, GPIO6 by default). Two kinds:
//   active buzzer (default): the pin switches it on and off - beeps only.
//   speaker: the pin is PWM into a small class-D amp (PAM8302 or similar) and
//            a speaker - beeps are tones, and new orders, the driver and the
//            paper are said out loud (voice_clips.h, 8 kHz 8-bit).
// Speech plays on its own task on core 0, so the screen never waits for it.
#pragma once
#include <Arduino.h>
#include <string>
#include <vector>
#include "config.h"
#include "voice_clips.h"

static const uint32_t PWM_CARRIER = 62500;  // 8-bit PWM, far above hearing
inline bool soundReady = false;
inline unsigned long buzzOffAt = 0;
inline volatile bool speaking = false;
inline QueueHandle_t sayQueue = nullptr;

inline const VoiceClip* clipFor(const std::string& key) {
  for (int i = 0; i < VOICE_CLIP_COUNT; i++) if (key == VOICE_CLIPS[i].key) return &VOICE_CLIPS[i];
  return nullptr;
}

inline void speakerQuiet() { ledcWrite(cfg.buzzPin, 0); }

inline void sayTask(void*) {
  const VoiceClip* c;
  while (true) {
    if (xQueueReceive(sayQueue, &c, portMAX_DELAY) != pdTRUE || !c) continue;
    speaking = true;
    ledcChangeFrequency(cfg.buzzPin, PWM_CARRIER, 8);
    const int vol = constrain(cfg.volume, 0, 100);
    uint32_t next = micros();
    for (uint32_t i = 0; i < c->len; i++) {
      int v = (int)pgm_read_byte(c->pcm + i) - 128;
      ledcWrite(cfg.buzzPin, (uint32_t)constrain(128 + v * vol / 100, 0, 255));
      next += 125;  // 8 kHz
      while ((int32_t)(micros() - next) < 0) {}
    }
    ledcWrite(cfg.buzzPin, 128);
    vTaskDelay(pdMS_TO_TICKS(70));
    if (uxQueueMessagesWaiting(sayQueue) == 0) { speakerQuiet(); speaking = false; }
  }
}

inline void buzzerBegin() {
  if (cfg.buzzPin < 0) return;
  if (cfg.speaker) {
    soundReady = ledcAttach(cfg.buzzPin, PWM_CARRIER, 8);
    speakerQuiet();
    sayQueue = xQueueCreate(24, sizeof(const VoiceClip*));
    xTaskCreatePinnedToCore(sayTask, "say", 3072, nullptr, 2, nullptr, 0);
  } else {
    pinMode(cfg.buzzPin, OUTPUT);
    digitalWrite(cfg.buzzPin, LOW);
    soundReady = true;
  }
}

/** A short beep: the buzzer, or a 2.4 kHz tone on the speaker (skipped while it talks). */
inline void beep(int ms = 180) {
  if (cfg.buzzPin < 0 || !soundReady) return;
  if (cfg.speaker) {
    if (speaking) return;
    ledcChangeFrequency(cfg.buzzPin, 2400, 8);
    ledcWrite(cfg.buzzPin, 128 * constrain(cfg.volume, 0, 100) / 100);
  } else {
    digitalWrite(cfg.buzzPin, HIGH);
  }
  buzzOffAt = millis() + ms;
}
inline void beepTick() {
  if (!buzzOffAt || (long)(millis() - buzzOffAt) < 0) return;
  buzzOffAt = 0;
  if (cfg.speaker) { if (!speaking) { ledcChangeFrequency(cfg.buzzPin, PWM_CARRIER, 8); speakerQuiet(); } }
  else digitalWrite(cfg.buzzPin, LOW);
}

/** Say these clips in order (logic.h announce*). Nothing without a speaker or with voice off. */
inline void say(const std::vector<std::string>& keys) {
  if (!cfg.speaker || !cfg.voice || !sayQueue) return;
  for (const std::string& k : keys) {
    const VoiceClip* c = clipFor(k);
    if (c) xQueueSend(sayQueue, &c, 0);
  }
}
inline void say(const char* key) { say(std::vector<std::string>{key}); }
