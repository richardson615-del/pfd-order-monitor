// The printer's own settings page, plus the setup network on first boot.
#pragma once
#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <Update.h>
#include "config.h"
#include "printer.h"
#include "orders.h"
#include "leds.h"
#include "ui.h"
#include "net.h"
#include "sample_ticket.h"

inline WebServer web(80);
inline DNSServer dns;

// Work the page asks for, done from loop() so the reply goes out first.
inline bool pendingReboot = false, pendingTest = false, pendingSample = false, pendingFinder = false,
            pendingButtons = false;
inline int pendingReprint = -1;
inline int pinTestGpio = -1;
inline unsigned long pinTestUntil = 0;

static const int BAUDS[] = {9600, 19200, 38400, 57600, 115200};

inline bool authed() {
  if (apOn && !WiFi.isConnected()) return true;
  if (cfg.adminPw.isEmpty()) return true;
  if (web.authenticate("admin", cfg.adminPw.c_str())) return true;
  web.requestAuthentication(BASIC_AUTH, "PFD Printer");
  return false;
}

inline String esc(const String& s) {
  String o;
  for (size_t i = 0; i < s.length(); i++) {
    char c = s[i];
    if (c == '<') o += "&lt;"; else if (c == '>') o += "&gt;"; else if (c == '"') o += "&quot;"; else if (c == '&') o += "&amp;"; else o += c;
  }
  return o;
}

inline String opt(int v, int cur, const String& label) {
  return "<option value=\"" + String(v) + "\"" + (v == cur ? " selected" : "") + ">" + label + "</option>";
}

static const char* CSS =
    "<style>body{font-family:system-ui,sans-serif;max-width:600px;margin:20px auto;padding:0 14px;color:#111}"
    "h1{font-size:22px}h3{margin-top:28px}label{display:block;margin:12px 0 4px;font-weight:600}label.net{font-weight:400;margin:8px 0;padding:10px;border:1px solid #ccc;border-radius:6px}label.net input{width:auto;margin-right:8px}input,select{width:100%;padding:9px;font-size:16px;box-sizing:border-box}"
    "button{padding:11px 16px;font-size:16px;margin:6px 6px 0 0;border:0;border-radius:6px;background:#111;color:#fff}"
    ".muted{color:#666;font-size:14px}.box{background:#f4f4f4;padding:10px 12px;border-radius:6px;font-size:14px}pre{white-space:pre-wrap;font-size:12px}"
    "table{width:100%;border-collapse:collapse;font-size:14px}td{padding:6px 4px;border-bottom:1px solid #ddd}.ok{color:#1a7f37}.bad{color:#b00}</style>";

inline void page(const String& title, const String& body) {
  web.send(200, "text/html", "<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'><title>" + title + "</title>" + CSS + body);
}

inline void back() { web.sendHeader("Location", "/"); web.send(303); }

// Tap-to-pick list of the WiFi networks this box can actually hear, strongest
// first, one row per name. A plain text box with a datalist showed the phone's
// own remembered networks instead (and nothing at all before a scan finished).
inline unsigned long scanStartedAt = 0;

// Start a background scan. A box that is still trying to rejoin a saved
// network can't scan (the radio is busy), so stop those attempts first; the
// setup page needs the list more than the retries need the radio.
inline void startScan() {
  if (!WiFi.isConnected() && !cfg.ssid.isEmpty()) { WiFi.setAutoReconnect(false); WiFi.disconnect(false, false); }
  WiFi.scanDelete();
  WiFi.scanNetworks(true);
  scanStartedAt = millis();
}

inline String wifiPicker() {
  String h;
  int n = WiFi.scanComplete();
  if (n == WIFI_SCAN_FAILED) { startScan(); n = WIFI_SCAN_RUNNING; }
  // A scan that never finishes used to leave this page on "Looking..." for good.
  if (n == WIFI_SCAN_RUNNING && millis() - scanStartedAt > 15000) { startScan(); }
  if (n < 0) {
    h += "<p class=muted>Looking for WiFi networks&hellip; this page refreshes by itself. "
         "Or type the network name below.</p><script>setTimeout(()=>location.reload(),4000)</script>";
    h += "<input name=ssid_other autocomplete=off autocapitalize=none placeholder=\"Network name\">";
    h += "<p><a href=/rescan>Scan again</a></p>";
    return h;
  }
  int idx[40]; int m = 0;
  for (int i = 0; i < n && m < 40; i++) {
    String id = WiFi.SSID(i);
    if (!id.length()) continue;
    bool dup = false;
    for (int j = 0; j < m; j++) if (WiFi.SSID(idx[j]) == id) { dup = true; if (WiFi.RSSI(i) > WiFi.RSSI(idx[j])) idx[j] = i; break; }
    if (!dup) idx[m++] = i;
  }
  for (int a = 0; a < m; a++) for (int b = a + 1; b < m; b++) if (WiFi.RSSI(idx[b]) > WiFi.RSSI(idx[a])) { int t = idx[a]; idx[a] = idx[b]; idx[b] = t; }
  if (!m) h += "<p class=muted>No 2.4 GHz networks found. Type the name below, or scan again.</p>";
  for (int a = 0; a < m; a++) {
    int i = idx[a]; String id = WiFi.SSID(i); int r = WiFi.RSSI(i);
    String bars = r > -60 ? "strong" : r > -72 ? "good" : r > -82 ? "weak" : "very weak";
    bool open = WiFi.encryptionType(i) == WIFI_AUTH_OPEN;
    h += "<label class=net><input type=radio name=ssid value=\"" + esc(id) + "\"" + String(id == cfg.ssid ? " checked" : "") + "> " + esc(id) +
         " <span class=muted>(" + bars + (open ? ", no password" : "") + ")</span></label>";
  }
  h += "<label class=net><input type=radio name=ssid value=\"\"" + String(m ? "" : " checked") + "> Other (type the name)</label>";
  h += "<input name=ssid_other autocomplete=off autocapitalize=none placeholder=\"Network name\">";
  h += "<p><a href=/rescan>Scan again</a></p>";
  return h;
}

inline String chosenSsid() {
  String o = web.arg("ssid_other"); o.trim();
  return o.length() ? o : web.arg("ssid");
}

inline void pageWifiSetup() {
  String h = "<h1>Connect this printer to WiFi</h1><form method=post action=/wifi>";
  h += "<label>Pick the store WiFi</label>" + wifiPicker();
  h += "<label>WiFi password</label><input name=pass type=password autocomplete=off>";
  h += "<button>Save</button></form><p class=muted>The printer restarts and joins it. Only 2.4 GHz networks show up.</p>";
  h += "<h3>Firmware</h3><p class=muted>Firmware " FW_VERSION "</p><form method=post action=/update enctype=multipart/form-data><input type=file name=fw accept=.bin><button>Upload</button></form>";
  page("WiFi setup", h);
}

inline void pageRoot() {
  if (!authed()) return;
  if (apOn && !WiFi.isConnected()) { pageWifiSetup(); return; }
  String h = "<h1>PFD Order Box</h1><div class=box>";
  h += "Firmware " FW_VERSION "<br>WiFi: " + (WiFi.isConnected() ? esc(cfg.ssid) + " &middot; " + WiFi.localIP().toString() + " &middot; " + String(WiFi.RSSI()) + " dBm" : String("not connected"));
  h += "<br>Device id: " + esc(deviceId);
  h += "<br>Device key: " + esc(keyHint());
  h += "<br>Status: " + String(errorText.length() ? "<span class=bad>" + esc(errorText) + "</span>" : (pollingHealthy() ? "<span class=ok>online</span>" : "waiting for first poll"));
  h += "<br>Last poll: " + esc(lastPollResult) + (lastPollOkAt ? " (" + String((millis() - lastPollOkAt) / 1000) + "s ago)" : "");
  h += "<br>Screen: " + String(screenReady ? "working" : "off") + " &middot; Touch: " + String(touchReady ? "working" : "<span class=bad>not found</span>");
  h += "<br>Tickets since boot: " + String(ticketsPrinted) + "</div>";

  h += "<p><a href=/sample><button>Print sample ticket</button></a><a href=/test><button>Print test page</button></a>";
  h += "</p>";

  // Today's orders
  h += "<h3>Today's orders</h3>";
  if (!orderCount) h += "<p class=muted>None yet.</p>";
  else {
    h += "<table>";
    for (int i = orderCount - 1; i >= 0; i--) {
      const OrderEntry& o = orders[i];
      h += "<tr><td>" + esc(clockText(o.at)) + "</td><td>#" + esc(o.number) + "</td><td>" + esc(o.type) + "</td><td>" + esc(o.name) + "</td><td>" + esc(o.total) + "</td><td><a href=/reprint?i=" + String(i) + ">reprint</a></td></tr>";
    }
    h += "</table>";
  }

  h += "<h3>Settings</h3><form method=post action=/save>";
  h += "<label>WiFi network</label>" + wifiPicker();
  h += "<label>WiFi password</label><input name=pass type=password placeholder=\"" + String(cfg.pass.isEmpty() ? "" : "(unchanged)") + "\">";
  h += "<label>Device key</label><input name=key autocomplete=off placeholder=\"" + String(cfg.key.isEmpty() ? "PFD-XXXX-XXXX-XXXX" : "(unchanged, ends " + esc(keyHint()) + ")") + "\">";
  h += "<p class=muted>Usually you pair with the code on the screen instead (CRM: Equipment, Add printer).</p>";
  h += "<label>Paper</label><select name=dots>" + opt(576, cfg.dots, "80mm") + opt(384, cfg.dots, "58mm") + "</select>";
  h += "<label>Large text</label><select name=tall>" + opt(1, cfg.tallText, "yes, every line double height") + opt(0, cfg.tallText, "no") + "</select>";
  h += "<label>Compact (no blank lines)</label><select name=compact>" + opt(1, cfg.compact, "yes") + opt(0, cfg.compact, "no") + "</select>";
  h += "<label>Default prep time (minutes)</label><input name=prep type=number min=5 max=120 value=" + String(cfg.prepDefault) + ">";
  h += "<label>Check for orders every (seconds)</label><input name=poll type=number min=2 max=60 value=" + String(cfg.pollSec) + ">";
  h += "<label>Settings password (optional)</label><input name=admin type=password placeholder=\"" + String(cfg.adminPw.isEmpty() ? "none" : "(unchanged)") + "\">";
  h += "<p><button>Save and restart</button></p></form>";


  h += "<h3>Screen and sound</h3><form method=post action=/display>";
  h += "<label>Screen orientation</label><select name=rot>" + opt(1, cfg.rotation, "Portrait") + opt(3, cfg.rotation, "Portrait, upside down") + "</select>";
  h += "<label>Glow colour for new orders</label><input type=color name=color value=\"" + colorHex(cfg.ledColor) + "\" style=height:48px>";
  h += "<label>Beep every (seconds) until someone taps Got it</label><input name=flashsec type=number min=0 max=120 value=" + String(cfg.flashSec) + ">";
  h += "<p class=muted>0 = beep once only. After two minutes with no tap it beeps every 2 seconds anyway.</p>";
  h += "<label>Sound</label><select name=speaker>" + opt(0, cfg.speaker, "Buzzer (beeps)") + opt(1, cfg.speaker, "Speaker (beeps and spoken alerts)") + "</select>";
  h += "<label>Say new orders, the driver and paper out loud</label><select name=voice>" + opt(1, cfg.voice, "yes") + opt(0, cfg.voice, "no, beeps only") + "</select>";
  h += "<label>Speaker volume (%)</label><input name=vol type=number min=10 max=100 value=" + String(cfg.volume) + ">";
  h += "<label>Idle screen after (minutes, 0 = never)</label><input name=idle type=number min=0 max=60 value=" + String(cfg.idleMin) + ">";
  h += "<p class=muted>Changing buzzer/speaker restarts the box.</p><p><button>Save</button></p></form>";

  h += "<h3>Backup internet</h3><form method=post action=/backup>";
  h += "<p class=muted>A phone hotspot or LTE router. If the store WiFi is down for a minute the box switches to this, and back when the store WiFi returns. Now on: <b>" + String(boxLink == "backup" ? "backup" : "store WiFi") + "</b></p>";
  h += "<label>Backup WiFi name</label><input name=ssid2 value=\"" + esc(cfg.ssid2) + "\" placeholder=\"none\">";
  h += "<label>Backup WiFi password</label><input name=pass2 type=password placeholder=\"" + String(cfg.pass2.isEmpty() ? "" : "(unchanged)") + "\">";
  h += "<p><button>Save</button></p></form>";

  h += "<details><summary class=muted>Printer wiring (set once)</summary><form method=post action=/wiring>";
  h += "<label>Printer TX / status RX pins</label><div style='display:flex;gap:6px'><input name=tx type=number value=" + String(cfg.tx) + "><input name=rx type=number value=" + String(cfg.rx) + "></div>";
  h += "<label>Baud</label><select name=baud>";
  for (int b : BAUDS) h += opt(b, cfg.baud, String(b));
  h += "</select><label>Cutter</label><select name=cutter>" + opt(1, cfg.cutter, "yes") + opt(0, cfg.cutter, "no, tear bar") + "</select>";
  h += "<label>Buzzer pin</label><input name=buzz type=number value=" + String(cfg.buzzPin) + ">";
  h += "<label>Print server</label><input name=url value=\"" + esc(cfg.url) + "\">";
  h += "<p><button>Save wiring and restart</button></p></form></details>";

  if (!cfg.key.isEmpty())
    h += "<h3>Pair to a different restaurant</h3><form method=post action=/unpair onsubmit=\"return confirm('Unpair this printer? It stops printing for its current restaurant until it is paired again.')\">"
         "<p class=muted>Forgets the CRM key so the screen shows a new pair code. Also remove the old entry in CRM Equipment.</p><button>Unpair</button></form>";
  h += "<h3>Firmware</h3><p class=muted>Automatic updates: " + esc(otaStatus) + "</p><form method=post action=/otacheck><button>Check for update now</button></form>";
  h += "<h3>Firmware</h3><form method=post action=/update enctype=multipart/form-data><input type=file name=fw accept=.bin><button>Upload</button></form>";
  h += "<h3>Activity</h3><pre>";
  for (int i = 0; i < 30; i++) { const String& l = logLines[(logHead + i) % 30]; if (l.length()) h += esc(l) + "\n"; }
  h += "</pre>";
  page("PFD Order Box", h);
}
inline void pageSave() {
  if (!authed()) return;
  { String id = chosenSsid(); if (id.length()) cfg.ssid = id; }
  if (web.arg("pass").length()) cfg.pass = web.arg("pass");
  String k = web.arg("key"); k.trim();
  if (k.length()) { cfg.key = k; cfg.announce = true; }
  if (web.arg("admin").length()) cfg.adminPw = web.arg("admin");
  cfg.dots = web.arg("dots").toInt() == 384 ? 384 : 576;
  cfg.tallText = web.arg("tall") != "0";
  cfg.compact = web.arg("compact") != "0";
  cfg.prepDefault = constrain(web.arg("prep").toInt(), 5, 120);
  cfg.pollSec = constrain(web.arg("poll").toInt(), 2, 60);
  cfg.announce = cfg.announce || chosenSsid().length();
  saveConfig();
  page("Saved", "<h1>Saved</h1><p>Restarting. Once it reaches PFD it prints a PRINTER ONLINE slip.</p>");
  pendingReboot = true;
}

inline void pageDisplay() {
  if (!authed()) return;
  int r = web.arg("rot").toInt(); cfg.rotation = (r == 3) ? 3 : 1;
  if (web.hasArg("color")) cfg.ledColor = parseColor(web.arg("color"));
  cfg.flashSec = constrain(web.arg("flashsec").toInt(), 0, 120);
  bool speaker = web.arg("speaker") == "1";
  bool restart = speaker != cfg.speaker;
  cfg.speaker = speaker;
  cfg.voice = web.arg("voice") != "0";
  if (web.hasArg("vol")) cfg.volume = constrain(web.arg("vol").toInt(), 10, 100);
  if (web.hasArg("idle")) cfg.idleMin = constrain(web.arg("idle").toInt(), 0, 60);
  saveConfig();
  if (restart) { page("Saved", "<h1>Saved</h1><p>Restarting for the new sound setting.</p>"); pendingReboot = true; return; }
  screenApplySettings();
  uiDirty = true;
  back();
}

inline void pageBackup() {
  if (!authed()) return;
  String n = web.arg("ssid2"); n.trim();
  cfg.ssid2 = n;
  if (n.isEmpty()) cfg.pass2 = "";
  else if (web.arg("pass2").length()) cfg.pass2 = web.arg("pass2");
  saveConfig();
  back();
}

inline void pageWiring() {
  if (!authed()) return;
  cfg.tx = web.arg("tx").toInt(); cfg.rx = web.arg("rx").toInt();
  cfg.baud = web.arg("baud").toInt();
  cfg.cutter = web.arg("cutter") == "1";
  cfg.buzzPin = web.arg("buzz").toInt();
  String u = web.arg("url"); u.trim(); if (u.startsWith("http")) cfg.url = u;
  saveConfig();
  page("Saved", "<h1>Saved</h1><p>Restarting.</p>");
  pendingReboot = true;
}

inline void updateDone() {
  if (!authed()) return;
  bool ok = !Update.hasError();
  page("Update", ok ? "<h1>Updated</h1><p>Restarting.</p>" : "<h1>Update failed</h1><p><a href=/>Back</a></p>");
  if (ok) pendingReboot = true;
}

inline void updateUpload() {
  if (!authed()) return;
  HTTPUpload& up = web.upload();
  if (up.status == UPLOAD_FILE_START) { logf("firmware upload %s", up.filename.c_str()); bigMessage("UPDATING", "do not unplug", C_NAVY); Update.begin(UPDATE_SIZE_UNKNOWN); }
  else if (up.status == UPLOAD_FILE_WRITE) Update.write(up.buf, up.currentSize);
  else if (up.status == UPLOAD_FILE_END) { if (Update.end(true)) logf("firmware update ok, %u bytes", up.totalSize); else logf("firmware update failed"); }
}

inline void captive() {
  if (apOn && !WiFi.isConnected()) { web.sendHeader("Location", "http://192.168.4.1/"); web.send(302); }
  else web.send(404, "text/plain", "not found");
}

inline void startAP() {
  if (apOn) return;
  WiFi.mode(WIFI_AP_STA);  // STA side on so the box can scan for the store's WiFi
  WiFi.softAP(apName.c_str());
  dns.start(53, "*", WiFi.softAPIP());
  apOn = true;
  uiDirty = true;
  startScan();
  logf("setup network %s open at %s", apName.c_str(), WiFi.softAPIP().toString().c_str());
}

inline void stopAP() {
  if (!apOn) return;
  dns.stop();
  WiFi.softAPdisconnect(true);
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  apOn = false;
  uiDirty = true;
  logf("setup network closed");
}

inline void webBegin() {
  web.on("/", HTTP_GET, pageRoot);
  web.on("/rescan", HTTP_GET, []() { startScan(); back(); });
  web.on("/otacheck", HTTP_POST, []() { if (!authed()) return; otaCheckNow = true; page("Checking", "<h1>Checking for an update</h1><p>If there is one the screen shows UPDATING, then the printer restarts. Give it two minutes.</p><p><a href=/>Back</a></p>"); });
  web.on("/unpair", HTTP_POST, []() {
    if (!authed()) return;
    cfg.key = ""; cfg.announce = false;
    saveConfig();
    pairCode = ""; nextPairAt = 0; errorText = "";
    uiDirty = true;
    logf("unpaired from the settings page");
    page("Unpaired", "<h1>Unpaired</h1><p>The screen shows PAIR PRINTER with a new six-digit code in a few seconds. Enter it in the CRM: Equipment, Add printer.</p><p><a href=/>Back</a></p>");
  });
  web.on("/wifi", HTTP_POST, []() {
    if (!authed()) return;
    String id = chosenSsid();
    if (!id.length()) { page("WiFi", "<h1>Pick a network</h1><p><a href=/>Back</a></p>"); return; }
    cfg.ssid = id; cfg.pass = web.arg("pass"); cfg.announce = true;
    saveConfig();
    logf("WiFi set to %s from the setup page", id.c_str());
    page("Saved", "<h1>Saved</h1><p>Joining " + esc(id) + ". The screen shows PAIR PRINTER with a code once it is online.</p>");
    pendingReboot = true;
  });
  web.on("/save", HTTP_POST, pageSave);
  web.on("/display", HTTP_POST, pageDisplay);
  web.on("/wiring", HTTP_POST, pageWiring);
  web.on("/backup", HTTP_POST, pageBackup);
  web.on("/test", HTTP_GET, []() { if (!authed()) return; pendingTest = true; back(); });
  web.on("/sample", HTTP_GET, []() { if (!authed()) return; pendingSample = true; back(); });
  web.on("/reprint", HTTP_GET, []() { if (!authed()) return; pendingReprint = web.arg("i").toInt(); back(); });
  web.on("/update", HTTP_POST, updateDone, updateUpload);
  web.on("/generate_204", HTTP_GET, captive);
  web.on("/hotspot-detect.html", HTTP_GET, captive);
  web.onNotFound(captive);
  web.begin();
}