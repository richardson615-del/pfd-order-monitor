// Replies produced by the bridge's real handlers (pfd-order-monitor
// lib/orderbox-server.ts against an in-memory database), parsed by the box's
// real parser. Regenerate the fixtures when the protocol changes.
#include <cstdio>
#include <fstream>
#include <sstream>
#include "../src/logic.h"
using namespace box;
static std::string slurp(const char* p) { std::ifstream f(p); std::stringstream s; s << f.rdbuf(); return s.str(); }
static int passed = 0, failed = 0;
#define CHECK(c) do { if (c) passed++; else { failed++; printf("FAIL %d: %s\n", __LINE__, #c); } } while (0)
int main() {
  std::string r = slurp("test/fixtures/server-sync.txt");
  Sync s = parseSync(r);
  CHECK(s.ok && s.now > 1700000000);
  CHECK(s.name == "Joe's Grill" && s.prep == 35 && s.busyMin == 15 && s.busyUntil > s.now);
  CHECK(s.todayOrders == 2 && s.todaySalesCents == 4850 && s.topItem == "Burger");
  CHECK(s.cmd == "reprint:1" && s.msgCount == 1 && s.unread == 1);
  CHECK(s.orderCount == 2);
  const Order* uber = s.find("aaaaaaaa-0000-4000-8000-000000000002");
  const Order* acked = s.find("aaaaaaaa-0000-4000-8000-000000000001");
  CHECK(uber && uber->isUber() && !uber->accepted && uber->open());
  CHECK(acked && acked->accepted && acked->readyBy > s.now && acked->driver == "Mike");
  CHECK(driverLine(*acked, s.now) == "Mike, 6 min away");
  Sync empty; std::vector<const Order*> fresh = newArrivals(empty, s, false);
  CHECK(fresh.size() == 1 && fresh[0] == uber);
  std::vector<MenuItem> m = parseMenu(slurp("test/fixtures/server-menu.txt"));
  CHECK(m.size() == 1 && m[0].ref == "itm_1" && m[0].name == "Brisket Plate" && m[0].category == "Mains");
  std::string e = slurp("test/fixtures/server-error.txt");
  CHECK(field(e, "ok") == "0" && field(e, "error") == "Order not found");
  printf("%d passed, %d failed\n", passed, failed);
  return failed ? 1 : 0;
}
