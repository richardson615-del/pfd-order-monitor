// Draws every order box screen from the real ui.h onto a host canvas and
// writes PNG-ready PPMs, then taps through the main flows and checks which
// server calls the screen makes. Built by tools/render_screens.sh.
#include <cstdio>
#include <cassert>
#include <map>
#include "Arduino.h"
#include "ui.h"

// ---- the box.h calls, recorded instead of sent
static std::vector<std::string> calls;
static bool callsOk = true;
long boxEpoch() { return boxNow.now ? boxNow.now : 1764093600; }
bool pollingHealthy() { return true; }
inline void startAP() {}
#define REC(x) do { calls.push_back(x); if (!callsOk) boxError = "Order not found"; return callsOk; } while (0)
bool boxAck(const std::string& id, int m) { REC("Ack " + id.substr(0, 8) + " " + std::to_string(m)); }
bool boxReady(const std::string& id) { REC("Ready " + id.substr(0, 8)); }
bool boxLate(const std::string& id, int a) { REC("Late " + id.substr(0, 8) + " " + std::to_string(a)); }
bool boxPrep(const std::string& id, int m) { REC("Prep " + id.substr(0, 8) + " " + std::to_string(m)); }
bool boxBusy(int a, int f) { REC("Busy " + std::to_string(a) + " " + std::to_string(f)); }
bool boxBusyEnd() { REC("BusyEnd"); }
bool boxPause(const char* c) { REC(std::string("Pause ") + c); }
bool boxPauseEnd() { REC("PauseEnd"); }
bool boxMsg(const char* k, const std::string& id) { REC(std::string("Msg ") + k + (id.empty() ? "" : " " + id.substr(0, 8))); }
bool boxRead() { REC("Read"); }
bool boxLoadMenu() { boxMenuItems = box::parseMenu("cat=Mains\nitem=itm_1|1|0|Brisket Plate\nitem=itm_2|0|0|Half Rack Ribs\nitem=itm_3|1|1|Pulled Pork Sandwich\ncat=Sides\nitem=itm_4|1|0|Mac and Cheese\nitem=itm_5|1|0|Collard Greens\nitem=itm_6|1|0|Banana Pudding\nitem=itm_7|1|0|Sweet Tea\nitem=itm_8|1|0|Cornbread\n"); calls.push_back("Menu"); return true; }
bool boxItem86(const std::string& r, bool out) { REC("Item86 " + r + (out ? " out" : " on")); }
bool boxDeny(const std::string& id, const char* c) { REC("Deny " + id.substr(0, 8) + " " + c); }
bool boxReprintServer(const std::string& id) { REC("Reprint " + id.substr(0, 8)); }
void boxSyncSoon() {}

static void save(const char* name) {
  char path[256]; snprintf(path, sizeof path, "%s/%s.ppm", getenv("OUT"), name);
  FILE* f = fopen(path, "wb");
  fprintf(f, "P6 480 800 255\n");
  for (uint16_t c : gfx->px) { uint8_t rgb[3] = {(uint8_t)(((c >> 11) & 31) * 255 / 31), (uint8_t)(((c >> 5) & 63) * 255 / 63), (uint8_t)((c & 31) * 255 / 31)}; fwrite(rgb, 1, 3, f); }
  fclose(f);
}
static void show(Screen s, const char* name) { uiScreen = s; uiDraw(); save(name); }
static int failed = 0, passed = 0;
#define CHECK(c) do { if (c) passed++; else { failed++; printf("FAIL line %d: %s\n", __LINE__, #c); } } while (0)
static bool hasBtn(int id) { for (int i = 0; i < btnCount; i++) if (btns[i].id == id) return true; return false; }
static bool btnsInside() { for (int i = 0; i < btnCount; i++) { const Btn& b = btns[i]; if (b.x < 0 || b.y < 0 || b.x + b.w > SW || b.y + b.h > SH) return false; } return true; }
static bool btnsApart() {
  for (int i = 0; i < btnCount; i++) for (int j = i + 1; j < btnCount; j++) {
    const Btn &a = btns[i], &b = btns[j];
    if (a.w >= SW || b.w >= SW) continue;  // the idle screen's whole-screen tap
    if (a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h) return false;
  }
  return true;
}

static const char* BASE =
  "ok=1\nnow=1764093600\nname=Willie Mae's Barbeque\nprep=20\nbusy=0\npaused=0\nunread=1\n"
  "today=14|61250|4375|Brisket Plate\npromo=Ask about catering for your next event\n"
  "msg=1764093300|0|Forrest|Your 6:15 pickup driver is running 5 minutes behind\n"
  "msg=1764090000|1|Kayla|Menu change for Banana Pudding is live\n";
static const char* O_NEW = "o=aaaaaaaa-0000-4000-8000-000000000042|42|zuppler|delivery|printed|0|0|0|||0|0|Dana Smith|3|1764093560|0\n";
static const char* O_UBER = "o=bbbbbbbb-0000-4000-8000-000000000043|43|ubereats|pickup|printed|0|0|0|||0|0|Chris|2|1764093580|0\n";
static const char* O_OPEN =
  "o=cccccccc-0000-4000-8000-000000000041|41|phone|delivery|printed|1|1764094200|0|Mike|assigned|1764093960|0|Sam|4|1764092900|0\n"
  "o=dddddddd-0000-4000-8000-000000000040|40|zuppler|pickup|printed|1|1764093480|0|||0|0|Lee|1|1764092500|0\n"
  "o=eeeeeeee-0000-4000-8000-000000000039|39|zuppler|delivery|printed|1|1764093900|1764093500|Ana (DoorDash)|at_pickup|1764093600|0|Pat|2|1764092300|0\n"
  "o=ffffffff-0000-4000-8000-000000000038|38|zuppler|delivery|completed|1|1764092000|1764091900|||0|0|Jo|2|1764091000|0\n";

static void load(const std::string& reply) { boxNow = box::parseSync(reply); boxHaveSync = true; }

int main() {
  setenv("TZ", "CST6CDT,M3.2.0,M11.1.0", 1); tzset();
  // Screens
  load(std::string(BASE) + O_OPEN);
  show(S_HOME, "01-home");
  CHECK(hasBtn(B_BUSY) && hasBtn(B_MENU) && hasBtn(100) && btnsInside() && btnsApart());
  load(std::string(BASE) + O_NEW + O_OPEN);
  show(S_NEW, "02-new-order");
  CHECK(hasBtn(1) && !hasBtn(5) && btnsInside());
  CHECK(uiOrder.substr(0, 8) == "aaaaaaaa");
  load(std::string(BASE) + O_UBER + O_OPEN);
  show(S_NEW, "03-uber-accept-deny");
  CHECK(hasBtn(1) && hasBtn(5) && btnsApart());
  show(S_DENY, "04-deny-reasons");
  CHECK(hasBtn(60) && hasBtn(63) && btnsInside() && btnsApart());
  // escalated: two and a half minutes without GOT IT
  load(std::string(BASE) + O_NEW + O_OPEN);
  boxNow.now += 150;
  show(S_NEW, "05-not-acknowledged");
  CHECK(escalated());
  load(std::string(BASE) + O_OPEN);
  uiOrder = "cccccccc-0000-4000-8000-000000000041";
  show(S_ORDER, "06-order");
  CHECK(hasBtn(B_READY) && hasBtn(B_LATE5) && hasBtn(B_LATE10) && hasBtn(B_WHERE) && btnsInside() && btnsApart());
  show(S_PREP, "07-ready-time");
  CHECK(hasBtn(220) && btnsApart());
  busyAdd = 0; show(S_BUSY, "08-busy-pick");
  CHECK(hasBtn(415) && btnsApart());
  busyAdd = 15; show(S_BUSY, "09-busy-length"); busyAdd = 0;
  CHECK(hasBtn(560));
  load(std::string(BASE).replace(std::string(BASE).find("busy=0"), 6, "busy=15|1764097200") + O_OPEN);
  show(S_HOME, "10-home-busy");
  show(S_BUSY, "11-busy-on");
  CHECK(hasBtn(70));
  load(std::string(BASE) + O_OPEN);
  show(S_PAUSE, "12-pause");
  CHECK(hasBtn(91) && hasBtn(95) && btnsInside() && btnsApart());
  load(std::string(BASE).replace(std::string(BASE).find("paused=0"), 8, "paused=1764095400|Paused on the order box") + O_OPEN);
  show(S_PAUSE, "13-paused");
  CHECK(hasBtn(90));
  load(std::string(BASE) + O_OPEN);
  show(S_MSGS, "14-dispatch");
  CHECK(hasBtn(30) && hasBtn(32) && btnsInside() && btnsApart());
  boxLoadMenu(); menuLoaded = true; menuPage = 0;
  show(S_MENU, "15-86");
  CHECK(hasBtn(1000) && hasBtn(41) && btnsInside() && btnsApart());
  show(S_TODAY, "16-today");
  load(std::string(BASE));
  show(S_IDLE, "17-idle");
  uiNote("READY", "Dispatch and the driver know", C_GREEN); uiDraw(); save("18-confirm");

  // Taps -> server calls
  load(std::string(BASE) + O_NEW + O_OPEN);
  calls.clear(); uiScreen = S_NEW; uiDraw(); uiTap(1);
  CHECK(calls.size() == 1 && calls[0] == "Ack aaaaaaaa 0");
  CHECK(uiScreen == S_NOTE && noteBig == "GOT IT");
  load(std::string(BASE) + O_UBER + O_OPEN);
  calls.clear(); uiScreen = S_NEW; uiDraw(); uiTap(5); CHECK(uiScreen == S_DENY); uiTap(60);
  CHECK(calls.size() == 1 && calls[0] == "Deny bbbbbbbb CAPACITY");
  load(std::string(BASE) + O_OPEN);
  calls.clear(); uiOrder = "cccccccc-0000-4000-8000-000000000041"; uiScreen = S_ORDER; uiDraw();
  uiTap(B_READY); uiTap(B_LATE10); uiTap(B_WHERE);
  CHECK((calls == std::vector<std::string>{"Ready cccccccc", "Late cccccccc 10", "Msg wheres_driver cccccccc"}));
  calls.clear(); uiScreen = S_PREP; uiDraw(); uiTap(230);
  CHECK(calls.size() == 1 && calls[0] == "Prep cccccccc 30");
  calls.clear(); uiScreen = S_BUSY; busyAdd = 0; uiDraw(); uiTap(420); CHECK(busyAdd == 20); uiDraw(); uiTap(560);
  CHECK(calls.size() == 1 && calls[0] == "Busy 20 60");
  calls.clear(); uiScreen = S_PAUSE; uiDraw(); uiTap(95);
  CHECK(calls.size() == 1 && calls[0] == "Pause today");
  calls.clear(); uiTap(B_MSGS);
  CHECK(calls.size() == 1 && calls[0] == "Read" && boxNow.unread == 0);
  calls.clear(); uiTap(B_MENU); uiTap(1001);
  CHECK((calls == std::vector<std::string>{"Menu", "Item86 itm_2 on"}));
  calls.clear(); uiTap(B_MENU); uiTap(1000);
  CHECK(calls.back() == "Item86 itm_1 out");
  // a refused call keeps the server's words on screen
  callsOk = false; calls.clear(); uiOrder = "cccccccc-0000-4000-8000-000000000041"; uiScreen = S_ORDER; uiTap(B_READY);
  CHECK(uiScreen == S_NOTE && noteBig == "NOT SENT" && noteSmall == "Order not found");
  callsOk = true;
  // a home row opens the order, or the GOT IT screen when it's still waiting
  load(std::string(BASE) + O_NEW + O_OPEN);
  uiScreen = S_HOME; uiDraw(); uiTap(101); CHECK(uiScreen == S_ORDER);
  uiTap(2); uiTap(100); CHECK(uiScreen == S_NEW);

  printf("%d passed, %d failed\n", passed, failed);
  return failed ? 1 : 0;
}
