// Host stand-in for the bits of Arduino the screen code uses.
#pragma once
#include <stdint.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <string>
#include <vector>
#include <algorithm>
#define PROGMEM
#define pgm_read_byte(p) (*(const uint8_t*)(p))
inline unsigned long g_millis = 100000;
inline unsigned long millis() { return g_millis; }
template <class T> T constrain(T v, T a, T b) { return v < a ? a : v > b ? b : v; }
using std::max; using std::min;
class String {
 public:
  std::string s;
  String() {}
  String(const char* c) : s(c ? c : "") {}
  String(const std::string& x) : s(x) {}
  String(char c) : s(1, c) {}
  String(int v) : s(std::to_string(v)) {}
  String(long v) : s(std::to_string(v)) {}
  String(unsigned v) : s(std::to_string(v)) {}
  String(unsigned long v) : s(std::to_string(v)) {}
  const char* c_str() const { return s.c_str(); }
  unsigned length() const { return (unsigned)s.size(); }
  bool isEmpty() const { return s.empty(); }
  String substring(int a, int b = -1) const { if (b < 0 || b > (int)s.size()) b = (int)s.size(); if (a > b) a = b; return s.substr(a, b - a); }
  int indexOf(char c, int from = 0) const { size_t p = s.find(c, from); return p == std::string::npos ? -1 : (int)p; }
  int lastIndexOf(char c, int from = -1) const { size_t p = s.rfind(c, from < 0 ? std::string::npos : (size_t)from); return p == std::string::npos ? -1 : (int)p; }
  bool startsWith(const String& p) const { return s.compare(0, p.s.size(), p.s) == 0; }
  bool endsWith(const String& p) const { return s.size() >= p.s.size() && s.compare(s.size() - p.s.size(), p.s.size(), p.s) == 0; }
  void remove(int i) { s.erase(i); }
  long toInt() const { return atol(s.c_str()); }
  String& operator+=(const String& o) { s += o.s; return *this; }
  bool operator==(const String& o) const { return s == o.s; }
  bool operator!=(const String& o) const { return s != o.s; }
};
inline String operator+(const String& a, const String& b) { return String(a.s + b.s); }
inline String operator+(const String& a, const char* b) { return String(a.s + b); }
inline String operator+(const char* a, const String& b) { return String(std::string(a) + b.s); }
