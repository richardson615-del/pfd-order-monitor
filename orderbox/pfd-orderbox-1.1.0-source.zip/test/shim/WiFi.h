#pragma once
inline bool g_wifi = true;
struct WiFiClass { bool isConnected() { return g_wifi; } };
inline WiFiClass WiFi;
