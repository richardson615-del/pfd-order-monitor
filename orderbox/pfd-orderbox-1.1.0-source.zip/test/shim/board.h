// A 480x800 RGB565 canvas in place of the RGB panel, drawing with the same font format.
#pragma once
#include <Arduino.h>
#include "Arduino_GFX.h"
struct Canvas {
  int W = 480, H = 800;
  std::vector<uint16_t> px = std::vector<uint16_t>(480 * 800);
  const GFXfont* font = nullptr; int size = 1; uint16_t color = 0xFFFF; int cx = 0, cy = 0;
  void pset(int x, int y, uint16_t c) { if (x >= 0 && y >= 0 && x < W && y < H) px[y * W + x] = c; }
  void fillScreen(uint16_t c) { std::fill(px.begin(), px.end(), c); }
  void fillRect(int x, int y, int w, int h, uint16_t c) { for (int j = y; j < y + h; j++) for (int i = x; i < x + w; i++) pset(i, j, c); }
  bool inRound(int i, int j, int x, int y, int w, int h, int r) {
    int dx = i < x + r ? x + r - i : i > x + w - 1 - r ? i - (x + w - 1 - r) : 0;
    int dy = j < y + r ? y + r - j : j > y + h - 1 - r ? j - (y + h - 1 - r) : 0;
    return dx * dx + dy * dy <= r * r;
  }
  void fillRoundRect(int x, int y, int w, int h, int r, uint16_t c) { for (int j = y; j < y + h; j++) for (int i = x; i < x + w; i++) if (inRound(i, j, x, y, w, h, r)) pset(i, j, c); }
  void drawRoundRect(int x, int y, int w, int h, int r, uint16_t c) {
    for (int j = y; j < y + h; j++) for (int i = x; i < x + w; i++) if (inRound(i, j, x, y, w, h, r) && !inRound(i, j, x + 1, y + 1, w - 2, h - 2, r > 1 ? r - 1 : 0)) pset(i, j, c);
  }
  void fillCircle(int x0, int y0, int r, uint16_t c) { for (int j = -r; j <= r; j++) for (int i = -r; i <= r; i++) if (i * i + j * j <= r * r) pset(x0 + i, y0 + j, c); }
  void setFont(const GFXfont* f) { font = f; }
  void setTextSize(int s) { size = s; }
  void setTextColor(uint16_t c) { color = c; }
  void setCursor(int x, int y) { cx = x; cy = y; }
  void drawChar(char ch) {
    if (!font || (uint8_t)ch < font->first || (uint8_t)ch > font->last) return;
    const GFXglyph& g = font->glyph[(uint8_t)ch - font->first];
    const uint8_t* bm = font->bitmap + g.bitmapOffset;
    int bit = 0; uint8_t bits = 0;
    for (int yy = 0; yy < g.height; yy++) for (int xx = 0; xx < g.width; xx++) {
      if (!(bit++ & 7)) bits = *bm++;
      if (bits & 0x80) for (int a = 0; a < size; a++) for (int b = 0; b < size; b++) pset(cx + (g.xOffset + xx) * size + a, cy + (g.yOffset + yy) * size + b, color);
      bits <<= 1;
    }
    cx += g.xAdvance * size;
  }
  void print(const String& s) { for (char c : s.s) drawChar(c); }
  void getTextBounds(const char* s, int x, int y, int16_t* x1, int16_t* y1, uint16_t* w, uint16_t* h) {
    int minx = 1 << 30, maxx = -(1 << 30), miny = 1 << 30, maxy = -(1 << 30), px0 = x;
    for (const char* p = s; *p; p++) {
      if (!font || (uint8_t)*p < font->first || (uint8_t)*p > font->last) continue;
      const GFXglyph& g = font->glyph[(uint8_t)*p - font->first];
      int gx0 = px0 + g.xOffset * size, gy0 = y + g.yOffset * size;
      minx = std::min(minx, gx0); maxx = std::max(maxx, gx0 + g.width * size - 1);
      miny = std::min(miny, gy0); maxy = std::max(maxy, gy0 + g.height * size - 1);
      px0 += g.xAdvance * size;
    }
    if (maxx < minx) { *x1 = x; *y1 = y; *w = 0; *h = 0; return; }
    *x1 = minx; *y1 = miny; *w = maxx - minx + 1; *h = maxy - miny + 1;
  }
};
inline Canvas* gfx = new Canvas();
inline bool screenReady = true;
inline bool touchGet(int&, int&) { return false; }
