#pragma once
#include <Arduino.h>
struct Config { String key = "PFD-KEY", ssid = "Store"; uint32_t ledColor = 0x00FF00; int flashSec = 10, idleMin = 3, rotation = 1; };
inline Config cfg;
