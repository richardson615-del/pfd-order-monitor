#pragma once
#include <Arduino.h>
#include <string>
#include <vector>
inline uint16_t rgb565(uint32_t c, int pct = 100) {
  uint32_t r = ((c >> 16) & 0xFF) * pct / 100, g = ((c >> 8) & 0xFF) * pct / 100, b = (c & 0xFF) * pct / 100;
  return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
}
inline void beep(int = 180) {}
inline void beepTick() {}
inline void say(const std::vector<std::string>&) {}
inline void say(const char*) {}
