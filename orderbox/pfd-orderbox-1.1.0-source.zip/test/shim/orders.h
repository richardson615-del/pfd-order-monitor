#pragma once
#include <Arduino.h>
#include <time.h>
struct OrderEntry { uint32_t seq = 0; time_t at = 0; String number, name, total, type; };
inline OrderEntry orders[60];
inline int orderCount = 0;
inline String clockText(time_t t) {
  if (t < 1600000000) return "";
  struct tm tm; localtime_r(&t, &tm);
  char b[12]; int h = tm.tm_hour % 12; if (h == 0) h = 12;
  snprintf(b, sizeof b, "%d:%02d%s", h, tm.tm_min, tm.tm_hour < 12 ? "a" : "p");
  return b;
}
inline bool ordersReprint(int) { return true; }
