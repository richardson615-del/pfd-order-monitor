#!/bin/sh
# Renders every screen of the real ui.h on this computer and runs the tap tests.
# Usage: tools/render_screens.sh <out-dir>
set -e
ROOT=$(cd "$(dirname "$0")/.." && pwd)
OUT=${1:-$ROOT/preview/real}
B=$(mktemp -d)
cp "$ROOT"/src/ui.h "$ROOT"/src/logic.h "$ROOT"/src/boxstate.h "$B"/
cp -r "$ROOT"/src/fonts "$B"/
cp "$ROOT"/test/shim/* "$B"/
mkdir -p "$OUT"
g++ -std=c++17 -O1 -w -I"$B" -o "$B/render" "$ROOT/test/render_screens.cpp"
OUT="$OUT" "$B/render"
python3 - "$OUT" <<'PY'
import sys, glob, os
from PIL import Image
for p in sorted(glob.glob(sys.argv[1] + "/*.ppm")):
    Image.open(p).save(p[:-4] + ".png"); os.remove(p)
PY
rm -rf "$B"
