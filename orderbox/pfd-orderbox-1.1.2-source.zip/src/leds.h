// The order box has no LED ring: the screen draws a glowing edge instead,
// and an active buzzer on the Sensor AD header does the beeping.
#pragma once
#include <Arduino.h>
#include "config.h"

inline uint32_t parseColor(const String& hex) {
  String h = hex;
  if (h.startsWith("#")) h = h.substring(1);
  return (uint32_t)strtoul(h.c_str(), nullptr, 16) & 0xFFFFFF;
}
inline String colorHex(uint32_t c) {
  char b[8];
  snprintf(b, sizeof b, "#%06X", (unsigned)(c & 0xFFFFFF));
  return b;
}
inline uint16_t rgb565(uint32_t c, int pct = 100) {
  uint32_t r = ((c >> 16) & 0xFF) * pct / 100, g = ((c >> 8) & 0xFF) * pct / 100, b = (c & 0xFF) * pct / 100;
  return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
}

// ---- buzzer: sound.h
#include "sound.h"
