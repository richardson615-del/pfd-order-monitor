// Order box logic with no hardware in it: the server's reply, timers,
// run-length screenshots and WiFi failover. Plain C++ so test/host_test.cpp
// runs every function on a normal computer.
#pragma once
#include <stdint.h>
#include <stdlib.h>
#include <string>
#include <vector>

namespace box {

// ---------------------------------------------------------------- parsing

inline std::vector<std::string> split(const std::string& s, char sep) {
  std::vector<std::string> out;
  size_t a = 0;
  while (true) {
    size_t b = s.find(sep, a);
    out.push_back(s.substr(a, b == std::string::npos ? std::string::npos : b - a));
    if (b == std::string::npos) break;
    a = b + 1;
  }
  return out;
}
inline long toL(const std::string& s) { return s.empty() ? 0 : strtol(s.c_str(), nullptr, 10); }

struct Order {
  std::string id, number, source, type, status, driver, driverStatus, customer;
  bool accepted = false, denied = false;
  long readyBy = 0, readyAt = 0, driverEta = 0, received = 0, due = 0;
  int items = 0;
  bool isUber() const { return source == "ubereats"; }
  bool settled() const { return status == "completed" || status == "cancelled" || denied; }
  bool open() const { return !settled() && readyAt == 0; }
};

struct Msg { long at = 0; bool read = false; std::string from, body; };

static const int MAX_ORDERS = 30;
static const int MAX_MSGS = 3;

struct Sync {
  bool ok = false;
  std::string error;
  long now = 0;
  std::string name, promo, cmd, pauseReason, topItem;
  int prep = 0, busyMin = 0, unread = 0, todayOrders = 0;
  long busyUntil = 0, pausedUntil = 0, todaySalesCents = 0, todayAvgCents = 0;
  Msg msgs[MAX_MSGS];
  int msgCount = 0;
  Order orders[MAX_ORDERS];
  int orderCount = 0;
  const Order* find(const std::string& id) const {
    for (int i = 0; i < orderCount; i++) if (orders[i].id == id) return &orders[i];
    return nullptr;
  }
  int openCount() const { int n = 0; for (int i = 0; i < orderCount; i++) if (orders[i].open()) n++; return n; }
};

inline bool parseOrder(const std::string& v, Order& o) {
  std::vector<std::string> f = split(v, '|');
  if (f.size() < 16 || f[0].size() != 36) return false;
  o.id = f[0]; o.number = f[1]; o.source = f[2]; o.type = f[3]; o.status = f[4];
  o.accepted = f[5] == "1"; o.readyBy = toL(f[6]); o.readyAt = toL(f[7]);
  o.driver = f[8]; o.driverStatus = f[9]; o.driverEta = toL(f[10]); o.denied = f[11] == "1";
  o.customer = f[12]; o.items = (int)toL(f[13]); o.received = toL(f[14]); o.due = toL(f[15]);
  return true;
}

/** One key's value from a key=value reply (first match). */
inline std::string field(const std::string& reply, const std::string& key) {
  std::string k = key + "=";
  size_t at = reply.compare(0, k.size(), k) == 0 ? 0 : reply.find("\n" + k);
  if (at == std::string::npos) return "";
  if (at > 0) at += 1;
  size_t end = reply.find('\n', at);
  return reply.substr(at + k.size(), end == std::string::npos ? std::string::npos : end - at - k.size());
}

inline Sync parseSync(const std::string& reply) {
  Sync s;
  for (const std::string& line : split(reply, '\n')) {
    size_t eq = line.find('=');
    if (eq == std::string::npos) continue;
    std::string k = line.substr(0, eq), v = line.substr(eq + 1);
    if (k == "ok") s.ok = v == "1";
    else if (k == "error") s.error = v;
    else if (k == "now") s.now = toL(v);
    else if (k == "name") s.name = v;
    else if (k == "prep") s.prep = (int)toL(v);
    else if (k == "busy") { std::vector<std::string> f = split(v, '|'); s.busyMin = (int)toL(f[0]); s.busyUntil = f.size() > 1 ? toL(f[1]) : 0; }
    else if (k == "paused") { std::vector<std::string> f = split(v, '|'); s.pausedUntil = toL(f[0]); s.pauseReason = f.size() > 1 ? f[1] : ""; }
    else if (k == "unread") s.unread = (int)toL(v);
    else if (k == "today") {
      std::vector<std::string> f = split(v, '|');
      s.todayOrders = (int)toL(f[0]);
      if (f.size() > 1) s.todaySalesCents = toL(f[1]);
      if (f.size() > 2) s.todayAvgCents = toL(f[2]);
      if (f.size() > 3) s.topItem = f[3];
    } else if (k == "promo") s.promo = v;
    else if (k == "cmd") s.cmd = v;
    else if (k == "msg" && s.msgCount < MAX_MSGS) {
      std::vector<std::string> f = split(v, '|');
      if (f.size() >= 4) {
        Msg& m = s.msgs[s.msgCount++];
        m.at = toL(f[0]); m.read = f[1] == "1"; m.from = f[2];
        m.body = f[3];
        for (size_t i = 4; i < f.size(); i++) m.body += " " + f[i];
      }
    } else if (k == "o" && s.orderCount < MAX_ORDERS) {
      if (parseOrder(v, s.orders[s.orderCount])) s.orderCount++;
    }
  }
  return s;
}

/** Orders that arrived since `before` and still want GOT IT, oldest first. */
inline std::vector<const Order*> newArrivals(const Sync& before, const Sync& now, bool firstSync) {
  std::vector<const Order*> out;
  if (firstSync) {
    // After a restart, only what is still unacknowledged and recent counts as new.
    for (int i = now.orderCount - 1; i >= 0; i--) {
      const Order& o = now.orders[i];
      if (!o.accepted && !o.settled() && now.now - o.received < 15 * 60) out.push_back(&o);
    }
    return out;
  }
  for (int i = now.orderCount - 1; i >= 0; i--) {
    const Order& o = now.orders[i];
    if (o.accepted || o.settled()) continue;
    if (!before.find(o.id)) out.push_back(&o);
  }
  return out;
}

// ---------------------------------------------------------------- menu

struct MenuItem { std::string ref, name, category; bool available = true, pending = false; };

inline std::vector<MenuItem> parseMenu(const std::string& reply) {
  std::vector<MenuItem> out;
  std::string cat;
  for (const std::string& line : split(reply, '\n')) {
    if (line.compare(0, 4, "cat=") == 0) cat = line.substr(4);
    else if (line.compare(0, 5, "item=") == 0) {
      std::vector<std::string> f = split(line.substr(5), '|');
      if (f.size() < 4) continue;
      MenuItem m;
      m.ref = f[0]; m.available = f[1] == "1"; m.pending = f[2] == "1"; m.category = cat;
      m.name = f[3];
      for (size_t i = 4; i < f.size(); i++) m.name += " " + f[i];
      out.push_back(m);
    }
  }
  return out;
}

// ---------------------------------------------------------------- words on the screen

/** "12 min", "1 min", "now", "3 min late" from seconds left. */
inline std::string minutesLeft(long secs) {
  if (secs <= -60) { long m = (-secs + 59) / 60; return std::to_string(m) + " min late"; }
  if (secs < 60) return secs > 0 ? "1 min" : "now";
  return std::to_string((secs + 59) / 60) + " min";
}

/** The kitchen timer's colour: 0 calm, 1 under five minutes, 2 late. */
inline int timerTone(long secsLeft) { return secsLeft < 0 ? 2 : secsLeft < 300 ? 1 : 0; }

/** "Mike, 6 min away" / "Mike is here" / "Mike has it" / "" when nobody is on it. */
inline std::string driverLine(const Order& o, long now) {
  if (o.driver.empty()) return "";
  if (o.driverStatus == "at_pickup") return o.driver + " is here";
  if (o.driverStatus == "picked_up") return o.driver + " has it";
  if (o.driverEta > 0) {
    long m = (o.driverEta - now + 59) / 60;
    if (m <= 1) return o.driver + ", arriving";
    return o.driver + ", " + std::to_string(m) + " min away";
  }
  return o.driver + " is on the way";
}

/** "$1,234" from cents, whole dollars. */
inline std::string dollars(long cents) {
  long d = (cents + 50) / 100;
  std::string s = std::to_string(d);
  for (int i = (int)s.size() - 3; i > 0; i -= 3) s.insert((size_t)i, ",");
  return "$" + s;
}

/** Seconds since the order arrived without GOT IT past which the box gets loud. */
static const long ESCALATE_AFTER = 120;
inline bool shouldEscalate(const Order& o, long now) { return !o.accepted && !o.settled() && o.received > 0 && now - o.received >= ESCALATE_AFTER; }

// ---------------------------------------------------------------- screenshots

/** Run-length RGB565, [count][lo][hi] per run, count 1-255. Same as the server's decodeShot. */
template <typename Emit>
inline size_t rleEncode(const uint16_t* px, size_t n, Emit emit) {
  size_t bytes = 0, i = 0;
  while (i < n) {
    uint16_t c = px[i];
    size_t run = 1;
    while (run < 255 && i + run < n && px[i + run] == c) run++;
    uint8_t b[3] = {(uint8_t)run, (uint8_t)(c & 0xFF), (uint8_t)(c >> 8)};
    emit(b, 3);
    bytes += 3;
    i += run;
  }
  return bytes;
}

/**
 * Half-size copy of the panel's framebuffer (native 800x480, landscape) as
 * the screen is seen. rotation 1 or 3 gives a 240x400 portrait image; 0 the
 * native landscape 400x240. `out` holds w*h pixels.
 */
inline void downsample(const uint16_t* fb, int nw, int nh, int rotation, uint16_t* out, int& w, int& h) {
  int hw = nw / 2, hh = nh / 2;
  if (rotation == 1 || rotation == 3) { w = hh; h = hw; } else { w = hw; h = hh; }
  for (int y = 0; y < h; y++)
    for (int x = 0; x < w; x++) {
      int sx, sy;  // in the half-size native frame
      // Arduino_RGB_Display::writePixelPreclipped: rotation 1 puts screen (x, y)
      // at native row x, column W-1-y; rotation 3 at row H-1-x, column y.
      if (rotation == 1) { sx = hw - 1 - y; sy = x; }
      else if (rotation == 3) { sx = y; sy = hh - 1 - x; }
      else { sx = x; sy = y; }
      out[y * w + x] = fb[(sy * 2) * nw + sx * 2];
    }
}

// ---------------------------------------------------------------- backup internet

enum LinkAction { STAY, TO_BACKUP, TO_PRIMARY };

/**
 * Which WiFi to be on. The store's WiFi first; after it has been down for a
 * minute, the backup (an LTE hotspot) when one is set. On backup, go back as
 * soon as a scan sees the store's WiFi again, but not more than every five
 * minutes, so a flaky router doesn't bounce the box.
 */
inline LinkAction linkDecision(bool onBackup, bool connected, bool backupSet, long secsDown, long secsOnLink, bool primaryVisible) {
  if (!backupSet) return onBackup ? TO_PRIMARY : STAY;
  if (!onBackup) return (!connected && secsDown >= 60) ? TO_BACKUP : STAY;
  if (!connected && secsDown >= 60) return TO_PRIMARY;
  if (primaryVisible && secsOnLink >= 300) return TO_PRIMARY;
  return STAY;
}

// ---------------------------------------------------------------- printer paper

/**
 * EP-300 / ESC-POS status. `paper` is the DLE EOT 4 reply, `cover` the DLE
 * EOT 2 reply, -1 for no answer. Returns ok | paper_low | paper_out |
 * cover_open | offline.
 */
inline const char* printerState(int paper, int cover) {
  if (paper < 0 && cover < 0) return "offline";
  if (cover >= 0 && (cover & 0x93) == 0x12 && (cover & 0x04)) return "cover_open";
  if (paper >= 0 && (paper & 0x93) == 0x12) {
    if (paper & 0x60) return "paper_out";
    if (paper & 0x0C) return "paper_low";
  }
  return "ok";
}

}  // namespace box
