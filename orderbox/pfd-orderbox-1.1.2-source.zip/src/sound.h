// The buzzer on the Sensor AD header (cfg.buzzPin, GPIO6 by default): an
// active 5V buzzer, switched on and off by the pin. Beeps only.
#pragma once
#include <Arduino.h>
#include "config.h"

inline bool soundReady = false;
inline unsigned long buzzOffAt = 0;

inline void buzzerBegin() {
  if (cfg.buzzPin < 0) return;
  pinMode(cfg.buzzPin, OUTPUT);
  digitalWrite(cfg.buzzPin, LOW);
  soundReady = true;
}

inline void beep(int ms = 180) {
  if (cfg.buzzPin < 0 || !soundReady) return;
  digitalWrite(cfg.buzzPin, HIGH);
  buzzOffAt = millis() + ms;
}

inline void beepTick() {
  if (!buzzOffAt || (long)(millis() - buzzOffAt) < 0) return;
  buzzOffAt = 0;
  digitalWrite(cfg.buzzPin, LOW);
}
