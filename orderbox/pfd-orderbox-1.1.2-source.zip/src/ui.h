// The order box touchscreen: portrait 480 x 800.
//   setup / connecting / pair  - getting onto WiFi and paired
//   home    - open orders with their timers and drivers; toolbar below
//   new     - an order waiting for GOT IT (ACCEPT / DENY for Uber Eats);
//             after two minutes it turns red and gets loud
//   order   - one order: READY, running late, change time, reprint, tell dispatch
//   prep    - pick a ready time
//   deny    - why an Uber Eats order is refused
//   busy / pause / msgs / menu (86) / today
//   idle    - nothing open and nobody touching: clock, numbers, the promo line
#pragma once
#include <Arduino.h>
#include <WiFi.h>
#include "config.h"
#include "board.h"
#include "orders.h"
#include "leds.h"
#include "printer.h"
#include "boxstate.h"
#include "fonts/FreeSansBold24pt7b.h"
#include "fonts/FreeSansBold18pt7b.h"
#include "fonts/FreeSansBold12pt7b.h"
#include "fonts/FreeSansBold9pt7b.h"
#include "fonts/FreeSans12pt7b.h"
#include "fonts/FreeSans18pt7b.h"

static const uint16_t C_BLACK = 0x0000, C_WHITE = 0xFFFF, C_GREEN = 0x07E0, C_RED = 0xF800,
                      C_AMBER = 0xFD20, C_BLUE = 0x001F, C_GREY = 0x8410, C_DIM = 0x4208, C_NAVY = 0x0010,
                      C_BG = 0x0861, C_CARD = 0x18E3, C_LINE = 0x3186, C_BTN = 0x2945, C_UBER = 0x0400,
                      C_DKRED = 0x6000, C_DKAMB = 0x4180;
static const int SW = 480, SH = 800, EDGE = 10, M = 22;

// ---- state other modules use (names shared with the Eatabit firmware)
inline bool apOn = false;
inline String apName;
inline unsigned long apKeepUntil = 0;
inline void startAP();
inline String pairCode;
inline String errorText;
inline bool uiDirty = true;
bool pollingHealthy();
inline String keyHint() {
  if (cfg.key.length() < 4) return cfg.key.isEmpty() ? "NOT SET" : "set";
  return "..." + cfg.key.substring(cfg.key.length() - 4);
}
inline void setError(const String& e) { if (e != errorText) { errorText = e; uiDirty = true; } }

enum Screen { S_HOME, S_NEW, S_PREP, S_ORDER, S_NOTE, S_DENY, S_BUSY, S_PAUSE, S_MSGS, S_MENU, S_TODAY, S_IDLE };
inline Screen uiScreen = S_HOME;
inline int uiSel = -1;               // a local ticket (orders.h) for the screens that only have that
inline std::string uiOrder;          // the server order on S_ORDER / S_PREP / S_DENY
inline bool newPending = false;      // a ticket printed and the server list has not caught up yet
inline unsigned long nextBeepAt = 0, nextNagAt = 0;
inline unsigned long noteUntil = 0;
inline unsigned long lastTouchAt = 0;
inline String noteBig, noteSmall;
inline uint16_t noteColor = C_NAVY;
inline int uiMinute = -1;
inline int busyAdd = 0;              // S_BUSY: minutes picked, waiting for how long
inline int menuPage = 0;
inline bool menuLoaded = false;

// ---- drawing helpers
struct Btn { int x, y, w, h, id; };
static const int MAX_BTNS = 40;
inline Btn btns[MAX_BTNS];
inline int btnCount = 0;
inline void clearBtns() { btnCount = 0; }
inline void addBtn(int x, int y, int w, int h, int id) { if (btnCount < MAX_BTNS) btns[btnCount++] = {x, y, w, h, id}; }

inline int textW(const String& s, const GFXfont* f, int size = 1) {
  gfx->setFont(f); gfx->setTextSize(size);
  int16_t x1, y1; uint16_t w, h;
  gfx->getTextBounds(s.c_str(), 0, 0, &x1, &y1, &w, &h);
  return w;
}
inline void text(const String& s, int x, int baseline, const GFXfont* f, uint16_t col, int size = 1) {
  gfx->setFont(f); gfx->setTextSize(size); gfx->setTextColor(col);
  gfx->setCursor(x, baseline); gfx->print(s);
}
inline void textC(const String& s, int baseline, const GFXfont* f, uint16_t col, int size = 1) {
  text(s, (SW - textW(s, f, size)) / 2, baseline, f, col, size);
}
inline void textR(const String& s, int right, int baseline, const GFXfont* f, uint16_t col) {
  text(s, right - textW(s, f), baseline, f, col);
}
inline String fit(String s, int w, const GFXfont* f) {
  if (textW(s, f) <= w) return s;
  while (s.length() > 1 && textW(s + "...", f) > w) s.remove(s.length() - 1);
  return s + "...";
}
inline void button(int x, int y, int w, int h, const String& label, uint16_t bg, uint16_t fg, int id, const GFXfont* f = &FreeSansBold18pt7b) {
  gfx->fillRoundRect(x, y, w, h, 14, bg);
  String l = fit(label, w - 16, f);
  text(l, x + (w - textW(l, f)) / 2, y + h / 2 + (f == &FreeSansBold24pt7b ? 16 : f == &FreeSansBold18pt7b ? 12 : 8), f, fg);
  addBtn(x, y, w, h, id);
}
inline String S(const std::string& s) { return String(s.c_str()); }

// ---- glowing edge: pulses for an order waiting on GOT IT, steady red on a problem
inline int glowShown = -1;
inline void drawEdge(uint16_t c) {
  gfx->fillRect(0, 0, SW, EDGE, c); gfx->fillRect(0, SH - EDGE, SW, EDGE, c);
  gfx->fillRect(0, 0, EDGE, SH, c); gfx->fillRect(SW - EDGE, 0, EDGE, SH, c);
}

// Orders waiting for GOT IT, oldest first (server list), and whether any is past two minutes.
inline std::vector<const box::Order*> waiting() {
  std::vector<const box::Order*> out;
  for (int i = boxNow.orderCount - 1; i >= 0; i--) {
    const box::Order& o = boxNow.orders[i];
    if (!o.accepted && !o.settled()) out.push_back(&o);
  }
  return out;
}
inline bool anyWaiting() { return newPending || !waiting().empty(); }
inline bool escalated() {
  long now = boxEpoch();
  for (const box::Order* o : waiting()) if (box::shouldEscalate(*o, now)) return true;
  return false;
}

inline void glowTick(bool force = false) {
  int key; uint16_t c;
  if (anyWaiting()) {
    bool loud = escalated();
    int pct = 30 + (int)(70 * (0.5 + 0.5 * sin(millis() / (loud ? 120.0 : 260.0))));
    key = (loud ? 2000 : 1000) + pct / 5; c = loud ? rgb565(0xFF0000, pct) : rgb565(cfg.ledColor, pct);
  } else if (errorText.length()) { key = 1; c = C_RED; }
  else { key = 0; c = C_BG; }
  if (key == glowShown && !force) return;
  glowShown = key;
  drawEdge(c);
}

// ---- full-screen message
inline void bigMessage(const String& big, const String& small, uint16_t color, uint16_t textCol = C_WHITE) {
  if (!screenReady) return;
  gfx->fillScreen(color);
  textC(big, SH / 2 - 10, &FreeSansBold24pt7b, textCol);
  if (textW(small, &FreeSans18pt7b) <= SW - 2 * M) textC(small, SH / 2 + 50, &FreeSans18pt7b, textCol);
  else textC(fit(small, SW - 2 * M, &FreeSans12pt7b), SH / 2 + 46, &FreeSans12pt7b, textCol);
  glowShown = -1;
}
inline void uiNote(const String& big, const String& small, uint16_t color, unsigned long ms = 2000) {
  noteBig = big; noteSmall = small; noteColor = color; noteUntil = millis() + ms;
  uiScreen = S_NOTE; uiDirty = true;
}
/** Show "Sending..." at once (the call takes a second), then the outcome. */
inline void sending() { if (screenReady) bigMessage("Sending...", "", C_NAVY); }
inline void outcome(bool ok, const String& okBig, const String& okSmall, Screen after = S_HOME) {
  if (ok) uiNote(okBig, okSmall, C_GREEN);
  else uiNote("NOT SENT", boxError.length() ? boxError : String("Check the internet and try again"), C_RED, 3500);
  if (ok) uiScreen = S_NOTE;
  (void)after;
}

// ---- header: PFD, the restaurant, clock, and what state the store is in
inline String untilText(long epoch) { return clockText((time_t)epoch); }

inline void drawHeader() {
  gfx->fillRect(EDGE, EDGE, SW - 2 * EDGE, 100, C_CARD);
  text("PFD", M + 4, EDGE + 48, &FreeSansBold24pt7b, C_WHITE);
  String clock = clockText((time_t)boxEpoch());
  if (clock.length()) textR(clock, SW - M - 4, EDGE + 48, &FreeSansBold18pt7b, C_WHITE);
  if (boxNow.name.size()) text(fit(S(boxNow.name), 230, &FreeSans12pt7b), M + 110, EDGE + 46, &FreeSans12pt7b, C_GREY);
  String st; uint16_t sc;
  long now = boxEpoch();
  if (errorText.length()) { st = errorText; sc = C_RED; }
  else if (!WiFi.isConnected()) { st = "No internet"; sc = C_RED; }
  else if (cfg.key.isEmpty()) { st = "Not paired yet"; sc = C_AMBER; }
  else if (boxNow.pausedUntil > now) { st = "PAUSED until " + untilText(boxNow.pausedUntil); sc = C_RED; }
  else if (boxNow.busyMin > 0 && boxNow.busyUntil > now) { st = "BUSY +" + String(boxNow.busyMin) + " min until " + untilText(boxNow.busyUntil); sc = C_AMBER; }
  else if (pollingHealthy()) { st = boxLink == "backup" ? "Online (backup internet)" : "Online"; sc = boxLink == "backup" ? C_AMBER : C_GREEN; }
  else { st = "Reaching PFD"; sc = C_AMBER; }
  gfx->fillCircle(M + 10, EDGE + 80, 7, sc);
  text(fit(st, SW - 2 * M - 40, &FreeSansBold12pt7b), M + 26, EDGE + 88, &FreeSansBold12pt7b, sc);
}

// ---- setup screens (unchanged from 1.0)
inline void drawSetup() {
  gfx->fillScreen(C_BG);
  drawHeader();
  textC("Connect to WiFi", 230, &FreeSansBold24pt7b, C_WHITE);
  textC("On your phone, join this WiFi:", 300, &FreeSans12pt7b, C_GREY);
  gfx->fillRoundRect(M, 330, SW - 2 * M, 100, 16, C_CARD);
  textC(apName, 395, &FreeSansBold24pt7b, C_GREEN);
  textC("A page opens. Pick the store", 490, &FreeSans18pt7b, C_WHITE);
  textC("WiFi, type the password, Save.", 530, &FreeSans18pt7b, C_WHITE);
  textC("No page? Go to 192.168.4.1", 620, &FreeSans12pt7b, C_GREY);
}
inline void drawConnecting() {
  gfx->fillScreen(C_BG);
  drawHeader();
  textC("Joining WiFi", 360, &FreeSansBold24pt7b, C_WHITE);
  textC(fit(cfg.ssid, SW - 2 * M, &FreeSans18pt7b), 420, &FreeSans18pt7b, C_GREY);
}
inline void drawPair() {
  gfx->fillScreen(C_BG);
  drawHeader();
  textC("Pair this box", 220, &FreeSansBold24pt7b, C_WHITE);
  if (pairCode.length() == 6) {
    gfx->fillRoundRect(M, 270, SW - 2 * M, 170, 18, C_CARD);
    textC(pairCode.substring(0, 3) + " " + pairCode.substring(3), 395, &FreeSansBold24pt7b, C_GREEN, 2);
    textC("In the CRM:", 510, &FreeSans18pt7b, C_GREY);
    textC("Equipment, Add printer", 555, &FreeSansBold18pt7b, C_WHITE);
    textC("and type this code.", 600, &FreeSans18pt7b, C_GREY);
  } else {
    textC("Getting a code from PFD...", 380, &FreeSans18pt7b, C_GREY);
  }
}

// ---- one order as a card on the home list
inline String sourceLabel(const box::Order& o) {
  if (o.source == "ubereats") return "UBER EATS";
  if (o.source == "phone") return "PHONE";
  if (o.source == "ezcater") return "EZCATER";
  return "PFD";
}
inline String typeLabel(const box::Order& o) { return o.type == "delivery" ? "Delivery" : o.type == "pickup" ? "Pickup" : S(o.type); }

inline void drawTimerChip(const box::Order& o, int right, int baseline) {
  long now = boxEpoch();
  String t; uint16_t bg, fg = C_BLACK;
  if (o.readyAt) { t = "READY"; bg = C_GREEN; }
  else if (!o.accepted) { t = "TAP GOT IT"; bg = C_AMBER; }
  else if (o.readyBy) {
    long left = o.readyBy - now;
    t = S(box::minutesLeft(left));
    int tone = box::timerTone(left);
    bg = tone == 2 ? C_RED : tone == 1 ? C_AMBER : C_BTN; fg = tone == 0 ? C_WHITE : C_BLACK;
  } else { t = "in kitchen"; bg = C_BTN; fg = C_WHITE; }
  int w = textW(t, &FreeSansBold12pt7b) + 24;
  gfx->fillRoundRect(right - w, baseline - 26, w, 36, 18, bg);
  text(t, right - w + 12, baseline, &FreeSansBold12pt7b, fg);
}

inline void drawOrderRow(const box::Order& o, int y, int h, int id) {
  long now = boxEpoch();
  bool done = o.settled() || o.readyAt;
  gfx->fillRoundRect(M, y, SW - 2 * M, h, 14, done ? C_BG : C_CARD);
  if (!done) gfx->drawRoundRect(M, y, SW - 2 * M, h, 14, C_LINE);
  if (o.isUber()) gfx->fillRect(M, y + 10, 6, h - 20, C_UBER);
  text("#" + S(o.number), M + 18, y + 40, &FreeSansBold18pt7b, done ? C_GREY : C_WHITE);
  text(sourceLabel(o), M + 18 + textW("#" + S(o.number), &FreeSansBold18pt7b) + 12, y + 38, &FreeSansBold9pt7b, C_GREY);
  if (o.denied) { textR("DENIED", SW - M - 16, y + 40, &FreeSansBold12pt7b, C_RED); }
  else if (o.status == "completed") { textR("Done", SW - M - 16, y + 40, &FreeSansBold12pt7b, C_GREY); }
  else drawTimerChip(o, SW - M - 14, y + 42);
  String sub = typeLabel(o) + (o.customer.size() ? "  " + S(o.customer) : String()) + (o.items ? "  " + String(o.items) + (o.items == 1 ? " item" : " items") : String());
  text(fit(sub, SW - 2 * M - 36, &FreeSans12pt7b), M + 18, y + 76, &FreeSans12pt7b, C_GREY);
  std::string d = box::driverLine(o, now);
  if (!d.empty() && h > 100) text(fit(S(d), SW - 2 * M - 36, &FreeSansBold12pt7b), M + 18, y + 108, &FreeSansBold12pt7b, o.driverStatus == "at_pickup" ? C_GREEN : C_AMBER);
  addBtn(M, y, SW - 2 * M, h, id);
}

// Toolbar ids
static const int B_BUSY = 10, B_PAUSE = 11, B_MSGS = 12, B_MENU = 13, B_TODAY = 14;

inline void drawToolbar() {
  int y = SH - EDGE - 96, w = (SW - 2 * M - 4 * 8) / 5, h = 84;
  const char* labels[] = {"Busy", "Pause", "Msgs", "86", "Today"};
  int ids[] = {B_BUSY, B_PAUSE, B_MSGS, B_MENU, B_TODAY};
  long now = boxEpoch();
  for (int i = 0; i < 5; i++) {
    int x = M + i * (w + 8);
    uint16_t bg = C_BTN, fg = C_WHITE;
    if (ids[i] == B_BUSY && boxNow.busyMin > 0 && boxNow.busyUntil > now) { bg = C_AMBER; fg = C_BLACK; }
    if (ids[i] == B_PAUSE && boxNow.pausedUntil > now) { bg = C_RED; }
    button(x, y, w, h, labels[i], bg, fg, ids[i], &FreeSansBold9pt7b);
    if (ids[i] == B_MSGS && boxNow.unread > 0) { gfx->fillCircle(x + w - 14, y + 14, 13, C_RED); text(String(boxNow.unread), x + w - 19, y + 21, &FreeSansBold9pt7b, C_WHITE); }
  }
}

inline void drawHome() {
  gfx->fillScreen(C_BG);
  drawHeader();
  clearBtns();
  int open = boxNow.openCount();
  text(open ? "Open orders" : "All caught up", M + 4, 160, &FreeSansBold18pt7b, C_WHITE);
  textR(String(boxNow.todayOrders) + " today", SW - M - 4, 160, &FreeSans18pt7b, C_GREY);
  int y = 180, bottom = SH - EDGE - 110;
  if (!boxHaveSync) {
    // Before the first Sync: the local tickets, as in 1.0.
    for (int i = orderCount - 1, shown = 0; i >= 0 && shown < 5; i--, shown++) {
      gfx->fillRoundRect(M, y, SW - 2 * M, 88, 12, C_CARD);
      text("#" + orders[i].number, M + 16, y + 38, &FreeSansBold18pt7b, C_WHITE);
      textR(clockText(orders[i].at), SW - M - 16, y + 38, &FreeSans18pt7b, C_GREY);
      text(fit(orders[i].type + "  " + orders[i].name, SW - 2 * M - 40, &FreeSans12pt7b), M + 16, y + 72, &FreeSans12pt7b, C_GREY);
      y += 98;
    }
    if (!orderCount) textC("Orders show up here.", 420, &FreeSans18pt7b, C_GREY);
  } else {
    // Open ones first (oldest at the top - that's the next one out), then today's finished ones.
    std::vector<int> idx;
    for (int i = boxNow.orderCount - 1; i >= 0; i--) if (boxNow.orders[i].open()) idx.push_back(i);
    for (int i = 0; i < boxNow.orderCount; i++) if (!boxNow.orders[i].open()) idx.push_back(i);
    for (int k : idx) {
      const box::Order& o = boxNow.orders[k];
      int h = (!box::driverLine(o, boxEpoch()).empty() && o.open()) ? 124 : 92;
      if (y + h > bottom) break;
      drawOrderRow(o, y, h, 100 + k);
      y += h + 10;
    }
    if (boxNow.orderCount == 0) textC("No orders yet today.", 420, &FreeSans18pt7b, C_GREY);
  }
  drawToolbar();
}

inline const box::Order* selOrder() { return uiOrder.empty() ? nullptr : boxNow.find(uiOrder); }

// ---- an order waiting for GOT IT
inline void drawNew() {
  std::vector<const box::Order*> w = waiting();
  bool loud = escalated();
  gfx->fillScreen(loud ? C_DKRED : C_BG);
  clearBtns();
  uint16_t band = loud ? C_RED : rgb565(cfg.ledColor);
  gfx->fillRect(EDGE, EDGE, SW - 2 * EDGE, 120, band);
  if (w.empty()) {
    // The ticket printed; the server's copy (with its id) arrives on the next Sync.
    textC("NEW ORDER", EDGE + 80, &FreeSansBold24pt7b, C_BLACK);
    int i = orderCount - 1;
    if (i >= 0) {
      textC("#" + orders[i].number, 330, &FreeSansBold24pt7b, C_WHITE, 2);
      textC(fit(orders[i].name, SW - 2 * M, &FreeSansBold18pt7b), 410, &FreeSansBold18pt7b, C_WHITE);
      textC(orders[i].type + "   " + orders[i].total, 460, &FreeSans18pt7b, C_GREY);
    }
    textC("The ticket is printing.", 540, &FreeSans12pt7b, C_GREY);
    button(M, SH - 200, SW - 2 * M, 150, "GOT IT", C_GREEN, C_BLACK, 1, &FreeSansBold24pt7b);
    return;
  }
  const box::Order& o = *w[0];
  uiOrder = o.id;
  long waited = boxEpoch() - o.received;
  textC(loud ? "WAITING " + String(waited / 60) + " MIN" : o.isUber() ? String("UBER EATS ORDER") : String("NEW ORDER"), EDGE + 80, &FreeSansBold24pt7b, C_BLACK);
  gfx->fillRoundRect(M, 160, SW - 2 * M, 300, 18, C_CARD);
  textC("#" + S(o.number), 270, &FreeSansBold24pt7b, C_WHITE, o.number.size() <= 5 ? 2 : 1);
  textC(fit(o.customer.size() ? S(o.customer) : String("No name"), SW - 2 * M - 30, &FreeSansBold18pt7b), 340, &FreeSansBold18pt7b, C_WHITE);
  textC(typeLabel(o) + "   " + String(o.items) + (o.items == 1 ? " item" : " items"), 390, &FreeSans18pt7b, C_GREY);
  textC(sourceLabel(o), 435, &FreeSansBold12pt7b, o.isUber() ? C_GREEN : C_GREY);
  if (w.size() > 1) textC("+" + String((int)w.size() - 1) + " more waiting", 510, &FreeSansBold18pt7b, C_AMBER);
  if (loud) textC("Customer is waiting - tap now", 560, &FreeSansBold12pt7b, C_WHITE);
  if (o.isUber()) {
    int bw = (SW - 2 * M - 16) / 3;
    button(M, SH - 200, bw * 2, 150, "ACCEPT", C_GREEN, C_BLACK, 1, &FreeSansBold24pt7b);
    button(M + bw * 2 + 16, SH - 200, bw, 150, "Deny", C_DIM, C_WHITE, 5);
  } else {
    button(M, SH - 200, SW - 2 * M, 150, "GOT IT", C_GREEN, C_BLACK, 1, &FreeSansBold24pt7b);
  }
  textC("Ready in " + String(boxNow.prep) + " min. Change it on the order.", SH - 30, &FreeSans12pt7b, C_GREY);
}

static const int PREP_STEPS[] = {10, 15, 20, 25, 30, 45};
inline void drawPrep() {
  gfx->fillScreen(C_BG);
  clearBtns();
  const box::Order* o = selOrder();
  textC("Ready in how long?", 110, &FreeSansBold18pt7b, C_WHITE);
  if (o) textC("#" + S(o->number) + (o->customer.size() ? "  " + S(o->customer) : String()), 160, &FreeSans18pt7b, C_GREY);
  int bw = (SW - 2 * M - 20) / 2, bh = 110, y = 200;
  for (int k = 0; k < 6; k++) {
    int x = M + (k % 2) * (bw + 20);
    bool def = PREP_STEPS[k] == boxNow.prep;
    button(x, y + (k / 2) * (bh + 18), bw, bh, String(PREP_STEPS[k]) + " min", def ? C_GREEN : C_BTN, def ? C_BLACK : C_WHITE, 200 + PREP_STEPS[k]);
  }
  button(M, SH - 150, SW - 2 * M, 100, "Back", C_DIM, C_WHITE, 2);
}

// ---- one order
static const int B_READY = 20, B_LATE5 = 21, B_LATE10 = 22, B_TIME = 23, B_REPRINT = 24, B_MISSING = 25, B_CUSTHERE = 26, B_WHERE = 27;
inline void drawOrder() {
  gfx->fillScreen(C_BG);
  clearBtns();
  const box::Order* o = selOrder();
  if (!o) { uiScreen = S_HOME; drawHome(); return; }
  long now = boxEpoch();
  gfx->fillRoundRect(M, 30, SW - 2 * M, 250, 18, C_CARD);
  text("#" + S(o->number), M + 20, 100, &FreeSansBold24pt7b, C_WHITE);
  textR(sourceLabel(*o), SW - M - 20, 96, &FreeSansBold12pt7b, o->isUber() ? C_GREEN : C_GREY);
  text(fit(typeLabel(*o) + (o->customer.size() ? "  " + S(o->customer) : String()), SW - 2 * M - 40, &FreeSansBold18pt7b), M + 20, 150, &FreeSansBold18pt7b, C_WHITE);
  text(String(o->items) + (o->items == 1 ? " item" : " items") + "   in at " + clockText((time_t)o->received), M + 20, 190, &FreeSans12pt7b, C_GREY);
  drawTimerChip(*o, SW - M - 20, 236);
  std::string d = box::driverLine(*o, now);
  text(d.empty() ? String("No driver yet") : S(d), M + 20, 236, &FreeSansBold12pt7b, d.empty() ? C_GREY : C_AMBER);

  int y = 296, w2 = (SW - 2 * M - 16) / 2;
  bool canTime = o->accepted && !o->readyAt && !o->settled();
  if (!o->settled() && !o->readyAt) { button(M, y, SW - 2 * M, 104, "READY", C_GREEN, C_BLACK, B_READY, &FreeSansBold24pt7b); y += 116; }
  if (canTime) {
    button(M, y, w2, 76, "+5 min", C_AMBER, C_BLACK, B_LATE5);
    button(M + w2 + 16, y, w2, 76, "+10 min", C_AMBER, C_BLACK, B_LATE10);
    y += 88;
  }
  button(M, y, w2, 70, "Change time", C_BTN, C_WHITE, B_TIME, &FreeSansBold12pt7b);
  button(M + w2 + 16, y, w2, 70, "Reprint", C_BTN, C_WHITE, B_REPRINT, &FreeSansBold12pt7b);
  y += 82;
  int w3 = (SW - 2 * M - 2 * 12) / 3;
  text("Tell dispatch:", M + 4, y + 16, &FreeSansBold9pt7b, C_GREY);
  y += 26;
  button(M, y, w3, 66, "Missing item", C_BTN, C_WHITE, B_MISSING, &FreeSansBold9pt7b);
  button(M + w3 + 12, y, w3, 66, "Pickup here", C_BTN, C_WHITE, B_CUSTHERE, &FreeSansBold9pt7b);
  button(M + 2 * (w3 + 12), y, w3, 66, "Driver?", C_BTN, C_WHITE, B_WHERE, &FreeSansBold9pt7b);
  button(M, SH - 104, SW - 2 * M, 80, "Back", C_DIM, C_WHITE, 2);
}

// ---- deny an Uber Eats order
inline void drawDeny() {
  gfx->fillScreen(C_BG);
  clearBtns();
  const box::Order* o = selOrder();
  textC("Why can't you take it?", 110, &FreeSansBold18pt7b, C_WHITE);
  if (o) textC("Uber Eats #" + S(o->number), 160, &FreeSans18pt7b, C_GREY);
  const char* labels[] = {"Too busy", "Item is out", "Closing", "Other"};
  for (int i = 0; i < 4; i++) button(M, 200 + i * 110, SW - 2 * M, 96, labels[i], C_BTN, C_WHITE, 60 + i);
  button(M, SH - 120, SW - 2 * M, 90, "Back - don't deny", C_DIM, C_WHITE, 3);
  textC("Uber tells the customer.", SH - 150, &FreeSans12pt7b, C_GREY);
}

// ---- busy
inline void drawBusy() {
  gfx->fillScreen(C_BG);
  clearBtns();
  long now = boxEpoch();
  textC("Busy", 100, &FreeSansBold24pt7b, C_WHITE);
  if (boxNow.busyMin > 0 && boxNow.busyUntil > now) {
    textC("+" + String(boxNow.busyMin) + " min on every order", 220, &FreeSansBold18pt7b, C_AMBER);
    textC("until " + untilText(boxNow.busyUntil), 270, &FreeSans18pt7b, C_GREY);
    textC("New orders get " + String(boxNow.prep) + " min.", 330, &FreeSans18pt7b, C_GREY);
    button(M, 420, SW - 2 * M, 130, "End busy", C_GREEN, C_BLACK, 70, &FreeSansBold24pt7b);
  } else if (!busyAdd) {
    textC("Add time to every new order:", 170, &FreeSans18pt7b, C_GREY);
    const int adds[] = {10, 15, 20, 30};
    int bw = (SW - 2 * M - 20) / 2;
    for (int i = 0; i < 4; i++) button(M + (i % 2) * (bw + 20), 210 + (i / 2) * 140, bw, 120, "+" + String(adds[i]) + " min", C_AMBER, C_BLACK, 400 + adds[i]);
  } else {
    textC("+" + String(busyAdd) + " min. For how long?", 170, &FreeSans18pt7b, C_GREY);
    const int lens[] = {30, 60, 120};
    const char* names[] = {"30 minutes", "1 hour", "2 hours"};
    for (int i = 0; i < 3; i++) button(M, 210 + i * 140, SW - 2 * M, 120, names[i], C_BTN, C_WHITE, 500 + lens[i]);
  }
  textC("Dispatch sees it right away.", SH - 150, &FreeSans12pt7b, C_GREY);
  button(M, SH - 120, SW - 2 * M, 90, "Back", C_DIM, C_WHITE, 2);
}

// ---- pause online orders
inline void drawPause() {
  gfx->fillScreen(C_BG);
  clearBtns();
  long now = boxEpoch();
  textC("Pause online orders", 100, &FreeSansBold18pt7b, C_WHITE);
  if (boxNow.pausedUntil > now) {
    textC("PAUSED", 230, &FreeSansBold24pt7b, C_RED);
    textC("until " + untilText(boxNow.pausedUntil), 290, &FreeSans18pt7b, C_GREY);
    button(M, 380, SW - 2 * M, 140, "Turn orders back on", C_GREEN, C_BLACK, 90);
  } else {
    const char* keys[] = {"15", "30", "60", "120", "today"};
    const char* names[] = {"15 minutes", "30 minutes", "1 hour", "2 hours", "Rest of today"};
    for (int i = 0; i < 5; i++) button(M, 140 + i * 98, SW - 2 * M, 86, names[i], i == 4 ? C_DKRED : C_BTN, C_WHITE, 91 + i);
    (void)keys;
  }
  textC("Stops new online orders everywhere.", SH - 150, &FreeSans12pt7b, C_GREY);
  button(M, SH - 120, SW - 2 * M, 90, "Back", C_DIM, C_WHITE, 2);
}
static const char* PAUSE_KEYS[] = {"15", "30", "60", "120", "today"};

// ---- dispatch messages
inline void drawMsgs() {
  gfx->fillScreen(C_BG);
  clearBtns();
  textC("Dispatch", 90, &FreeSansBold24pt7b, C_WHITE);
  int y = 130;
  if (!boxNow.msgCount) { textC("No messages from dispatch.", 220, &FreeSans18pt7b, C_GREY); y = 260; }
  for (int i = 0; i < boxNow.msgCount; i++) {
    const box::Msg& m = boxNow.msgs[i];
    gfx->fillRoundRect(M, y, SW - 2 * M, 110, 14, C_CARD);
    text(S(m.from) + "  " + clockText((time_t)m.at), M + 16, y + 30, &FreeSansBold12pt7b, m.read ? C_GREY : C_GREEN);
    // two lines of the body
    String b = S(m.body), l1 = fit(b, SW - 2 * M - 32, &FreeSans12pt7b), l2;
    if (l1.endsWith("...")) { int cut = l1.length() - 3; int sp = b.lastIndexOf(' ', cut); if (sp < 10) sp = cut; l1 = b.substring(0, sp); l2 = fit(b.substring(sp + 1), SW - 2 * M - 32, &FreeSans12pt7b); }
    text(l1, M + 16, y + 64, &FreeSans12pt7b, C_WHITE);
    if (l2.length()) text(l2, M + 16, y + 94, &FreeSans12pt7b, C_WHITE);
    y += 122;
  }
  text("Send to dispatch:", M + 4, SH - 380, &FreeSansBold12pt7b, C_GREY);
  button(M, SH - 360, SW - 2 * M, 72, "Where's my driver?", C_BTN, C_WHITE, 30, &FreeSansBold12pt7b);
  button(M, SH - 278, SW - 2 * M, 72, "We're running behind", C_BTN, C_WHITE, 31, &FreeSansBold12pt7b);
  button(M, SH - 196, SW - 2 * M, 72, "Please call us", C_BTN, C_WHITE, 32, &FreeSansBold12pt7b);
  button(M, SH - 110, SW - 2 * M, 80, "Back", C_DIM, C_WHITE, 2);
}

// ---- 86
static const int MENU_ROWS = 6;
inline void drawMenu() {
  gfx->fillScreen(C_BG);
  clearBtns();
  textC("86 an item", 80, &FreeSansBold18pt7b, C_WHITE);
  textC("Tap: sold out today. Tap again: back on.", 115, &FreeSans12pt7b, C_GREY);
  if (!menuLoaded) { textC(boxError.length() ? boxError : String("No menu on file."), 380, &FreeSans18pt7b, C_GREY); button(M, SH - 110, SW - 2 * M, 80, "Back", C_DIM, C_WHITE, 2); return; }
  int n = (int)boxMenuItems.size(), pages = max(1, (n + MENU_ROWS - 1) / MENU_ROWS);
  menuPage = constrain(menuPage, 0, pages - 1);
  int y = 140;
  std::string lastCat;
  for (int i = menuPage * MENU_ROWS; i < min(n, (menuPage + 1) * MENU_ROWS); i++) {
    const box::MenuItem& it = boxMenuItems[i];
    bool out = !it.available;
    gfx->fillRoundRect(M, y, SW - 2 * M, 76, 12, out ? C_DKRED : C_CARD);
    if (it.category != lastCat) { text(fit(S(it.category), 200, &FreeSansBold9pt7b), M + 14, y + 22, &FreeSansBold9pt7b, C_GREY); lastCat = it.category; }
    text(fit(S(it.name), SW - 2 * M - 150, &FreeSansBold12pt7b), M + 14, y + 56, &FreeSansBold12pt7b, C_WHITE);
    textR(it.pending ? "Sent" : out ? "86'd" : "On", SW - M - 16, y + 50, &FreeSansBold12pt7b, it.pending ? C_AMBER : out ? C_RED : C_GREEN);
    addBtn(M, y, SW - 2 * M, 76, 1000 + i);
    y += 84;
  }
  int bw = (SW - 2 * M - 32) / 3;
  button(M, SH - 110, bw, 80, "<", C_BTN, C_WHITE, 40);
  button(M + bw + 16, SH - 110, bw, 80, "Back", C_DIM, C_WHITE, 2);
  button(M + 2 * (bw + 16), SH - 110, bw, 80, ">", C_BTN, C_WHITE, 41);
  textC(String(menuPage + 1) + " / " + String(pages), SH - 125, &FreeSans12pt7b, C_GREY);
}

// ---- today's numbers
inline void drawToday() {
  gfx->fillScreen(C_BG);
  clearBtns();
  textC("Today", 90, &FreeSansBold24pt7b, C_WHITE);
  struct { String big, small; } tiles[] = {
    {String(boxNow.todayOrders), "orders"},
    {S(box::dollars(boxNow.todaySalesCents)), "food sales"},
    {S(box::dollars(boxNow.todayAvgCents)), "average order"},
  };
  int y = 140;
  for (auto& t : tiles) {
    gfx->fillRoundRect(M, y, SW - 2 * M, 122, 18, C_CARD);
    textC(t.big, y + 76, &FreeSansBold24pt7b, C_WHITE, t.big.length() <= 6 ? 2 : 1);
    textC(t.small, y + 108, &FreeSans12pt7b, C_GREY);
    y += 134;
  }
  if (boxNow.topItem.size()) {
    textC("Most ordered", y + 30, &FreeSans12pt7b, C_GREY);
    textC(fit(S(boxNow.topItem), SW - 2 * M, &FreeSansBold18pt7b), y + 70, &FreeSansBold18pt7b, C_GREEN);
  }
  button(M, SH - 120, SW - 2 * M, 90, "Back", C_DIM, C_WHITE, 2);
}

// ---- idle: nothing open, nobody touching
inline void drawIdle() {
  gfx->fillScreen(C_BLACK);
  clearBtns();
  String clock = clockText((time_t)boxEpoch());
  textC(clock.length() ? clock : String("PFD"), 260, &FreeSansBold24pt7b, C_WHITE, 2);
  if (boxNow.name.size()) textC(fit(S(boxNow.name), SW - 2 * M, &FreeSansBold18pt7b), 330, &FreeSansBold18pt7b, C_GREY);
  textC(String(boxNow.todayOrders) + (boxNow.todayOrders == 1 ? " order today" : " orders today"), 420, &FreeSans18pt7b, C_GREEN);
  if (boxNow.promo.size()) {
    gfx->fillRoundRect(M, 500, SW - 2 * M, 120, 18, C_CARD);
    textC(fit(S(boxNow.promo), SW - 2 * M - 30, &FreeSansBold12pt7b), 568, &FreeSansBold12pt7b, C_WHITE);
  }
  textC("Powered by Premium Food Delivery", SH - 60, &FreeSans12pt7b, C_DIM);
  addBtn(0, 0, SW, SH, 2);
}

inline void uiDraw() {
  if (!screenReady) return;
  clearBtns();
  bool setup = apOn && !WiFi.isConnected();
  if (uiScreen == S_NOTE) bigMessage(noteBig, noteSmall, noteColor, noteColor == C_GREEN || noteColor == C_AMBER ? C_BLACK : C_WHITE);
  else if (setup) drawSetup();
  else if (!WiFi.isConnected() && !cfg.ssid.isEmpty() && cfg.key.isEmpty()) drawConnecting();
  else if (cfg.key.isEmpty()) drawPair();
  else if (uiScreen == S_NEW) drawNew();
  else if (uiScreen == S_PREP) drawPrep();
  else if (uiScreen == S_ORDER) drawOrder();
  else if (uiScreen == S_DENY) drawDeny();
  else if (uiScreen == S_BUSY) drawBusy();
  else if (uiScreen == S_PAUSE) drawPause();
  else if (uiScreen == S_MSGS) drawMsgs();
  else if (uiScreen == S_MENU) drawMenu();
  else if (uiScreen == S_TODAY) drawToday();
  else if (uiScreen == S_IDLE) drawIdle();
  else drawHome();
  if (uiScreen != S_IDLE && uiScreen != S_NOTE) glowTick(true);
  uiDirty = false;
}

/** A ticket printed, or a Sync found an order nobody has acknowledged. */
inline void uiNewOrder() {
  newPending = true;
  uiScreen = S_NEW;
  uiDirty = true;
  beep(250);
  nextBeepAt = cfg.flashSec > 0 ? millis() + (unsigned long)cfg.flashSec * 1000 : 0;
  boxSyncSoon();
}

inline void afterWaiting() {
  newPending = false;
  if (!waiting().empty()) { uiScreen = S_NEW; return; }
  nextBeepAt = 0;
}

inline void uiTap(int id) {
  const box::Order* o = selOrder();
  if (id == 1) {  // GOT IT / ACCEPT
    if (uiOrder.empty() || !boxNow.find(uiOrder)) { newPending = false; uiScreen = S_HOME; boxSyncSoon(); uiDirty = true; return; }
    sending();
    bool ok = boxAck(uiOrder, 0);
    const box::Order* a = boxNow.find(uiOrder);
    if (ok) const_cast<box::Order*>(a)->accepted = true;
    afterWaiting();
    outcome(ok, "GOT IT", "Ready in " + String(boxNow.prep) + " min");
    return;
  }
  if (id == 2) { uiScreen = S_HOME; busyAdd = 0; uiDirty = true; return; }
  if (id == 3) { uiScreen = newPending || !waiting().empty() ? S_NEW : S_ORDER; uiDirty = true; return; }
  if (id == 5) { uiScreen = S_DENY; uiDirty = true; return; }
  if (id >= 100 && id < 100 + box::MAX_ORDERS) { uiOrder = boxNow.orders[id - 100].id; uiScreen = boxNow.orders[id - 100].accepted || boxNow.orders[id - 100].settled() ? S_ORDER : S_NEW; uiDirty = true; return; }
  if (id >= 200 && id < 300 && o) { sending(); bool ok = boxPrep(uiOrder, id - 200); outcome(ok, "SENT", "Ready in " + String(id - 200) + " min"); return; }
  if (id >= 60 && id < 64 && o) {
    const char* codes[] = {"CAPACITY", "ITEM_AVAILABILITY", "STORE_CLOSED", "OTHER"};
    sending(); bool ok = boxDeny(uiOrder, codes[id - 60]);
    if (ok) const_cast<box::Order*>(boxNow.find(uiOrder))->denied = true;
    afterWaiting();
    outcome(ok, "DENIED", "Uber Eats is telling the customer"); return;
  }
  switch (id) {
    case B_BUSY: busyAdd = 0; uiScreen = S_BUSY; break;
    case B_PAUSE: uiScreen = S_PAUSE; break;
    case B_MSGS: uiScreen = S_MSGS; if (boxNow.unread) { boxRead(); boxNow.unread = 0; for (int i = 0; i < boxNow.msgCount; i++) boxNow.msgs[i].read = true; } break;
    case B_MENU: bigMessage("Loading menu...", "", C_NAVY); menuLoaded = boxLoadMenu(); menuPage = 0; uiScreen = S_MENU; break;
    case B_TODAY: uiScreen = S_TODAY; break;
    case B_READY: if (o) { sending(); bool ok = boxReady(uiOrder); outcome(ok, "READY", "Dispatch and the driver know"); } return;
    case B_LATE5: case B_LATE10: if (o) { int add = id == B_LATE5 ? 5 : 10; sending(); bool ok = boxLate(uiOrder, add); outcome(ok, "+" + String(add) + " MIN", "Dispatch and the driver see the new time"); } return;
    case B_TIME: uiScreen = S_PREP; break;
    case B_REPRINT:
      if (o) {
        int local = -1;
        for (int i = orderCount - 1; i >= 0; i--) if (orders[i].number == S(o->number)) { local = i; break; }
        if (local >= 0 && ordersReprint(local)) uiNote("REPRINTING", "#" + S(o->number), C_NAVY);
        else { sending(); bool ok = boxReprintServer(uiOrder); outcome(ok, "REPRINTING", "#" + S(o->number)); }
      }
      return;
    case B_MISSING: case B_CUSTHERE: case B_WHERE: {
      const char* k = id == B_MISSING ? "missing_item" : id == B_CUSTHERE ? "customer_here" : "wheres_driver";
      sending(); bool ok = boxMsg(k, uiOrder); outcome(ok, "SENT", "Dispatch has it"); return;
    }
    case 30: case 31: case 32: {
      const char* k = id == 30 ? "wheres_driver" : id == 31 ? "running_behind" : "call_me";
      sending(); bool ok = boxMsg(k, ""); outcome(ok, "SENT", "Dispatch has it"); return;
    }
    case 70: { sending(); bool ok = boxBusyEnd(); if (ok) boxNow.busyMin = 0; outcome(ok, "BUSY OFF", "Back to normal times"); return; }
    case 90: { sending(); bool ok = boxPauseEnd(); if (ok) boxNow.pausedUntil = 0; outcome(ok, "ORDERS ON", "Taking online orders again"); return; }
    case 40: menuPage--; break;
    case 41: menuPage++; break;
    default:
      if (id >= 400 && id < 500) { busyAdd = id - 400; break; }
      if (id >= 500 && id < 700 && busyAdd) { int len = id - 500; sending(); bool ok = boxBusy(busyAdd, len); if (ok) boxNow.busyMin = busyAdd; busyAdd = 0; outcome(ok, "BUSY", "New orders get more time"); return; }
      if (id >= 91 && id <= 95) { sending(); bool ok = boxPause(PAUSE_KEYS[id - 91]); outcome(ok, "PAUSED", "Dispatch is pausing every site"); return; }
      if (id >= 1000 && id < 1000 + (int)boxMenuItems.size()) {
        box::MenuItem& it = boxMenuItems[id - 1000];
        if (it.pending) { uiNote("ALREADY SENT", "Dispatch is updating it", C_AMBER); return; }
        bigMessage("Sending...", "", C_NAVY);
        bool ok = boxItem86(it.ref, it.available);
        if (ok) { it.pending = true; uiNote(it.available ? "86'D" : "BACK ON", S(it.name), C_GREEN); uiScreen = S_NOTE; }
        else uiNote("NOT SENT", boxError, C_RED, 3500);
        return;
      }
  }
  uiDirty = true;
}

inline Screen noteReturn = S_HOME;

inline void uiTick() {
  if (!screenReady) return;
  static bool down = false;
  static unsigned long lastPoll = 0;
  if (millis() - lastPoll >= 20) {
    lastPoll = millis();
    int x, y;
    bool now = touchGet(x, y);
    if (now && !down) {
      lastTouchAt = millis();
      for (int i = btnCount - 1; i >= 0; i--) {
        const Btn& b = btns[i];
        if (x >= b.x && x < b.x + b.w && y >= b.y && y < b.y + b.h) {
          beep(25);
          Screen was = uiScreen;
          uiTap(b.id);
          if (uiScreen == S_NOTE) noteReturn = (was == S_MENU) ? S_MENU : (anyWaiting() ? S_NEW : (was == S_ORDER || was == S_PREP) ? S_ORDER : S_HOME);
          break;
        }
      }
    }
    down = now;
  }
  if (uiScreen == S_NOTE && (long)(millis() - noteUntil) >= 0) { uiScreen = anyWaiting() ? S_NEW : noteReturn; noteReturn = S_HOME; uiDirty = true; }

  // Waiting for GOT IT: beep every flashSec; past two minutes, every two seconds and say so every 30.
  if (anyWaiting()) {
    if (uiScreen == S_HOME || uiScreen == S_IDLE) { uiScreen = S_NEW; uiDirty = true; }
    bool loud = escalated();
    unsigned long gap = loud ? 2000 : (unsigned long)max(2, cfg.flashSec) * 1000;
    if (!nextBeepAt || (long)(millis() - nextBeepAt) >= 0) { beep(loud ? 400 : 250); nextBeepAt = millis() + gap; }
    if (loud && (long)(millis() - nextNagAt) >= 0) { nextNagAt = millis() + 30000; uiDirty = true; }
  }

  // Idle screen: nothing open, nobody touching for idleMin minutes.
  if (uiScreen == S_HOME && cfg.idleMin > 0 && boxHaveSync && boxNow.openCount() == 0 && millis() - lastTouchAt > (unsigned long)cfg.idleMin * 60000UL) { uiScreen = S_IDLE; uiDirty = true; }

  // Timers, ETAs and the clock move once a minute; a Sync redraws too (box.h).
  time_t t = (time_t)boxEpoch();
  if (t > 1600000000) {
    struct tm tm; localtime_r(&t, &tm);
    if (tm.tm_min != uiMinute) { uiMinute = tm.tm_min; if (uiScreen == S_HOME || uiScreen == S_IDLE || uiScreen == S_ORDER || uiScreen == S_NEW) uiDirty = true; }
  }
  static String shownCode; static bool shownWifi = false, shownAp = false;
  if (pairCode != shownCode || WiFi.isConnected() != shownWifi || apOn != shownAp) {
    shownCode = pairCode; shownWifi = WiFi.isConnected(); shownAp = apOn; uiDirty = true;
  }
  if (uiDirty) uiDraw();
  if (uiScreen != S_IDLE && uiScreen != S_NOTE) glowTick();
  beepTick();
}
