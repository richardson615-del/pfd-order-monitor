// Host tests for src/logic.h: g++ -std=c++17 test/host_test.cpp && ./a.out
#include <cassert>
#include <cstdio>
#include <cstring>
#include "../src/logic.h"
using namespace box;

static int passed = 0, failed = 0;
#define CHECK(c) do { if (c) passed++; else { failed++; printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #c); } } while (0)

static const char* REPLY =
  "ok=1\nnow=1764093600\nname=Joe's Grill\nprep=35\nbusy=15|1764097200\npaused=0\nunread=1\n"
  "today=2|4850|2425|Brisket Plate\npromo=Try the brisket\ncmd=screenshot\n"
  "msg=1764093540|0|Forrest|Driver is 5 min out | sorry\n"
  "o=aaaaaaaa-0000-4000-8000-000000000002|2|ubereats|pickup|printed|0|0|0|||0|0|Dana|3|1764093540|0\n"
  "o=aaaaaaaa-0000-4000-8000-000000000001|1|zuppler|delivery|printed|1|1764094800|0|Mike|assigned|1764093960|0|Sam|2|1764093420|0\n"
  "o=bad|line\n";

int main() {
  Sync s = parseSync(REPLY);
  CHECK(s.ok);
  CHECK(s.now == 1764093600);
  CHECK(s.name == "Joe's Grill");
  CHECK(s.prep == 35 && s.busyMin == 15 && s.busyUntil == 1764097200);
  CHECK(s.pausedUntil == 0 && s.unread == 1);
  CHECK(s.todayOrders == 2 && s.todaySalesCents == 4850 && s.todayAvgCents == 2425 && s.topItem == "Brisket Plate");
  CHECK(s.promo == "Try the brisket" && s.cmd == "screenshot");
  CHECK(s.msgCount == 1 && s.msgs[0].from == "Forrest" && !s.msgs[0].read);
  CHECK(s.orderCount == 2);  // the bad line is dropped
  const Order& u = s.orders[0];
  CHECK(u.isUber() && !u.accepted && u.items == 3 && u.customer == "Dana" && u.open());
  const Order& d = s.orders[1];
  CHECK(d.accepted && d.driver == "Mike" && d.driverStatus == "assigned" && d.readyBy == 1764094800);
  CHECK(field(REPLY, "prep") == "35" && field(REPLY, "nope") == "");
  CHECK(field("ok=0\nerror=Order not found\n", "error") == "Order not found");

  // new arrivals: only unaccepted ones the box hadn't seen
  Sync before = parseSync("ok=1\nnow=1764093500\n");
  std::vector<const Order*> n = newArrivals(before, s, false);
  CHECK(n.size() == 1 && n[0]->number == "2");
  CHECK(newArrivals(s, s, false).empty());
  CHECK(newArrivals(before, s, true).size() == 1);

  // timers and words
  CHECK(minutesLeft(600) == "10 min" && minutesLeft(61) == "2 min" && minutesLeft(30) == "1 min" && minutesLeft(0) == "now" && minutesLeft(-200) == "4 min late");
  CHECK(timerTone(400) == 0 && timerTone(120) == 1 && timerTone(-1) == 2);
  CHECK(driverLine(d, s.now) == "Mike, 6 min away");
  Order here = d; here.driverStatus = "at_pickup";
  CHECK(driverLine(here, s.now) == "Mike is here");
  Order none = d; none.driver = "";
  CHECK(driverLine(none, s.now) == "");
  CHECK(dollars(4850) == "$49" && dollars(123456789) == "$1,234,568" && dollars(0) == "$0");
  CHECK(shouldEscalate(u, u.received + 120) && !shouldEscalate(u, u.received + 60) && !shouldEscalate(d, d.received + 999));

  // menu
  std::vector<MenuItem> m = parseMenu("ok=1\nmenu=1\ncat=Mains\nitem=itm_1|1|0|Brisket Plate\nitem=itm_2|0|1|Ribs | Half\ncat=Sides\nitem=itm_3|1|0|Slaw\n");
  CHECK(m.size() == 3 && m[1].name == "Ribs   Half" && !m[1].available && m[1].pending && m[2].category == "Sides");

  // screenshots: RLE matches the server's format, and rotation lands right
  uint16_t px[600];
  for (int i = 0; i < 600; i++) px[i] = i < 300 ? 0xF800 : 0x001F;
  std::vector<uint8_t> out;
  size_t bytes = rleEncode(px, 600, [&](const uint8_t* p, size_t k) { out.insert(out.end(), p, p + k); });
  CHECK(bytes == out.size() && out.size() == 12);  // 255+45 red, 255+45 blue
  CHECK(out[0] == 255 && out[1] == 0x00 && out[2] == 0xF8 && out[3] == 45);
  static uint16_t fb[800 * 480], half[400 * 240];
  for (int y = 0; y < 480; y++) for (int x = 0; x < 800; x++) fb[y * 800 + x] = (uint16_t)((x < 400 ? 1 : 2) | (y < 240 ? 0x10 : 0x20));
  int w, h;
  downsample(fb, 800, 480, 0, half, w, h);
  CHECK(w == 400 && h == 240 && half[0] == 0x11 && half[399] == 0x12);
  downsample(fb, 800, 480, 1, half, w, h);
  CHECK(w == 240 && h == 400);
  // rotation 1: screen top-left is the native top-right (Arduino_RGB_Display rotation 1)
  CHECK(half[0] == 0x12);
  CHECK(half[399 * 240 + 239] == 0x21);  // and bottom-right the native bottom-left
  downsample(fb, 800, 480, 3, half, w, h);
  CHECK(half[0] == 0x21);  // rotation 3: native bottom-left

  // backup internet
  CHECK(linkDecision(false, false, true, 30, 30, false) == STAY);
  CHECK(linkDecision(false, false, true, 61, 61, false) == TO_BACKUP);
  CHECK(linkDecision(false, false, false, 600, 600, false) == STAY);
  CHECK(linkDecision(true, true, true, 0, 100, true) == STAY);
  CHECK(linkDecision(true, true, true, 0, 301, true) == TO_PRIMARY);
  CHECK(linkDecision(true, true, true, 0, 301, false) == STAY);
  CHECK(linkDecision(true, false, true, 61, 61, false) == TO_PRIMARY);
  CHECK(linkDecision(true, true, false, 0, 0, false) == TO_PRIMARY);

  // printer status (DLE EOT replies)
  CHECK(strcmp(printerState(0x12, 0x12), "ok") == 0);
  CHECK(strcmp(printerState(0x12 | 0x0C, 0x12), "paper_low") == 0);
  CHECK(strcmp(printerState(0x12 | 0x60, 0x12), "paper_out") == 0);
  CHECK(strcmp(printerState(0x12, 0x12 | 0x04), "cover_open") == 0);
  CHECK(strcmp(printerState(-1, -1), "offline") == 0);
  CHECK(strcmp(printerState(0xFF, -1), "ok") == 0);  // a garbled byte is not a paper fault

  printf("%d passed, %d failed\n", passed, failed);
  return failed ? 1 : 0;
}
